var ii = Object.defineProperty
var oi = (de, ue, pe) =>
  ue in de
    ? ii(de, ue, { enumerable: !0, configurable: !0, writable: !0, value: pe })
    : (de[ue] = pe)
var mr = (de, ue, pe) => oi(de, typeof ue != 'symbol' ? ue + '' : ue, pe)
import { c as ai, g as ui } from './Cpj98o6Y.js'
var Ln = { exports: {} },
  si = Ln.exports,
  gr
function ci () {
  return (
    gr ||
      ((gr = 1),
      (function (de, ue) {
        ;(function (pe, C) {
          de.exports = C()
        })(si, function () {
          var pe = function (e, n) {
              return (pe =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (t, r) {
                    t.__proto__ = r
                  }) ||
                function (t, r) {
                  for (var i in r)
                    Object.prototype.hasOwnProperty.call(r, i) && (t[i] = r[i])
                })(e, n)
            },
            C = function () {
              return (C =
                Object.assign ||
                function (e) {
                  for (var n, t = 1, r = arguments.length; t < r; t++)
                    for (var i in (n = arguments[t]))
                      Object.prototype.hasOwnProperty.call(n, i) &&
                        (e[i] = n[i])
                  return e
                }).apply(this, arguments)
            }
          function fn (e, n, t) {
            for (var r, i = 0, o = n.length; i < o; i++)
              (!r && i in n) ||
                ((r = r || Array.prototype.slice.call(n, 0, i))[i] = n[i])
            return e.concat(r || Array.prototype.slice.call(n))
          }
          var $ =
              typeof globalThis < 'u'
                ? globalThis
                : typeof self < 'u'
                ? self
                : typeof window < 'u'
                ? window
                : ai,
            V = Object.keys,
            L = Array.isArray
          function Z (e, n) {
            return (
              typeof n != 'object' ||
                V(n).forEach(function (t) {
                  e[t] = n[t]
                }),
              e
            )
          }
          typeof Promise > 'u' || $.Promise || ($.Promise = Promise)
          var Ie = Object.getPrototypeOf,
            wr = {}.hasOwnProperty
          function J (e, n) {
            return wr.call(e, n)
          }
          function Be (e, n) {
            typeof n == 'function' && (n = n(Ie(e))),
              (typeof Reflect > 'u' ? V : Reflect.ownKeys)(n).forEach(function (
                t
              ) {
                ye(e, t, n[t])
              })
          }
          var At = Object.defineProperty
          function ye (e, n, t, r) {
            At(
              e,
              n,
              Z(
                t && J(t, 'get') && typeof t.get == 'function'
                  ? { get: t.get, set: t.set, configurable: !0 }
                  : { value: t, configurable: !0, writable: !0 },
                r
              )
            )
          }
          function Re (e) {
            return {
              from: function (n) {
                return (
                  (e.prototype = Object.create(n.prototype)),
                  ye(e.prototype, 'constructor', e),
                  { extend: Be.bind(null, e.prototype) }
                )
              }
            }
          }
          var _r = Object.getOwnPropertyDescriptor,
            xr = [].slice
          function hn (e, n, t) {
            return xr.call(e, n, t)
          }
          function Ct (e, n) {
            return n(e)
          }
          function Ge (e) {
            if (!e) throw new Error('Assertion Failed')
          }
          function Dt (e) {
            $.setImmediate ? setImmediate(e) : setTimeout(e, 0)
          }
          function se (e, n) {
            if (typeof n == 'string' && J(e, n)) return e[n]
            if (!n) return e
            if (typeof n != 'string') {
              for (var t = [], r = 0, i = n.length; r < i; ++r) {
                var o = se(e, n[r])
                t.push(o)
              }
              return t
            }
            var a = n.indexOf('.')
            if (a !== -1) {
              var u = e[n.substr(0, a)]
              return u == null ? void 0 : se(u, n.substr(a + 1))
            }
          }
          function ee (e, n, t) {
            if (
              e &&
              n !== void 0 &&
              !('isFrozen' in Object && Object.isFrozen(e))
            )
              if (typeof n != 'string' && 'length' in n) {
                Ge(typeof t != 'string' && 'length' in t)
                for (var r = 0, i = n.length; r < i; ++r) ee(e, n[r], t[r])
              } else {
                var o,
                  a,
                  u = n.indexOf('.')
                u !== -1
                  ? ((o = n.substr(0, u)),
                    (a = n.substr(u + 1)) === ''
                      ? t === void 0
                        ? L(e) && !isNaN(parseInt(o))
                          ? e.splice(o, 1)
                          : delete e[o]
                        : (e[o] = t)
                      : ee(
                          (u = !(u = e[o]) || !J(e, o) ? (e[o] = {}) : u),
                          a,
                          t
                        ))
                  : t === void 0
                  ? L(e) && !isNaN(parseInt(n))
                    ? e.splice(n, 1)
                    : delete e[n]
                  : (e[n] = t)
              }
          }
          function qt (e) {
            var n,
              t = {}
            for (n in e) J(e, n) && (t[n] = e[n])
            return t
          }
          var kr = [].concat
          function Tt (e) {
            return kr.apply([], e)
          }
          var fe =
              'BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey'
                .split(',')
                .concat(
                  Tt(
                    [8, 16, 32, 64].map(function (e) {
                      return ['Int', 'Uint', 'Float'].map(function (n) {
                        return n + e + 'Array'
                      })
                    })
                  )
                )
                .filter(function (e) {
                  return $[e]
                }),
            It = new Set(
              fe.map(function (e) {
                return $[e]
              })
            ),
            Qe = null
          function ke (e) {
            return (
              (Qe = new WeakMap()),
              (e = (function n (t) {
                if (!t || typeof t != 'object') return t
                var r = Qe.get(t)
                if (r) return r
                if (L(t)) {
                  ;(r = []), Qe.set(t, r)
                  for (var i = 0, o = t.length; i < o; ++i) r.push(n(t[i]))
                } else if (It.has(t.constructor)) r = t
                else {
                  var a,
                    u = Ie(t)
                  for (a in ((r =
                    u === Object.prototype ? {} : Object.create(u)),
                  Qe.set(t, r),
                  t))
                    J(t, a) && (r[a] = n(t[a]))
                }
                return r
              })(e)),
              (Qe = null),
              e
            )
          }
          var Or = {}.toString
          function Un (e) {
            return Or.call(e).slice(8, -1)
          }
          var zn = typeof Symbol < 'u' ? Symbol.iterator : '@@iterator',
            Pr =
              typeof zn == 'symbol'
                ? function (e) {
                    var n
                    return e != null && (n = e[zn]) && n.apply(e)
                  }
                : function () {
                    return null
                  }
          function Oe (e, n) {
            return (n = e.indexOf(n)), 0 <= n && e.splice(n, 1), 0 <= n
          }
          var Me = {}
          function ce (e) {
            var n, t, r, i
            if (arguments.length === 1) {
              if (L(e)) return e.slice()
              if (this === Me && typeof e == 'string') return [e]
              if ((i = Pr(e))) {
                for (t = []; !(r = i.next()).done; ) t.push(r.value)
                return t
              }
              if (e == null) return [e]
              if (typeof (n = e.length) != 'number') return [e]
              for (t = new Array(n); n--; ) t[n] = e[n]
              return t
            }
            for (n = arguments.length, t = new Array(n); n--; )
              t[n] = arguments[n]
            return t
          }
          var Vn =
              typeof Symbol < 'u'
                ? function (e) {
                    return e[Symbol.toStringTag] === 'AsyncFunction'
                  }
                : function () {
                    return !1
                  },
            Je = [
              'Unknown',
              'Constraint',
              'Data',
              'TransactionInactive',
              'ReadOnly',
              'Version',
              'NotFound',
              'InvalidState',
              'InvalidAccess',
              'Abort',
              'Timeout',
              'QuotaExceeded',
              'Syntax',
              'DataClone'
            ],
            re = [
              'Modify',
              'Bulk',
              'OpenFailed',
              'VersionChange',
              'Schema',
              'Upgrade',
              'InvalidTable',
              'MissingAPI',
              'NoSuchDatabase',
              'InvalidArgument',
              'SubTransaction',
              'Unsupported',
              'Internal',
              'DatabaseClosed',
              'PrematureCommit',
              'ForeignAwait'
            ].concat(Je),
            Kr = {
              VersionChanged:
                'Database version changed by other database connection',
              DatabaseClosed: 'Database has been closed',
              Abort: 'Transaction aborted',
              TransactionInactive:
                'Transaction has already completed or failed',
              MissingAPI:
                'IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb'
            }
          function Fe (e, n) {
            ;(this.name = e), (this.message = n)
          }
          function Bt (e, n) {
            return (
              e +
              '. Errors: ' +
              Object.keys(n)
                .map(function (t) {
                  return n[t].toString()
                })
                .filter(function (t, r, i) {
                  return i.indexOf(t) === r
                }).join(`
`)
            )
          }
          function dn (e, n, t, r) {
            ;(this.failures = n),
              (this.failedKeys = r),
              (this.successCount = t),
              (this.message = Bt(e, n))
          }
          function Ne (e, n) {
            ;(this.name = 'BulkError'),
              (this.failures = Object.keys(n).map(function (t) {
                return n[t]
              })),
              (this.failuresByPos = n),
              (this.message = Bt(e, this.failures))
          }
          Re(Fe)
            .from(Error)
            .extend({
              toString: function () {
                return this.name + ': ' + this.message
              }
            }),
            Re(dn).from(Fe),
            Re(Ne).from(Fe)
          var Wn = re.reduce(function (e, n) {
              return (e[n] = n + 'Error'), e
            }, {}),
            Er = Fe,
            A = re.reduce(function (e, n) {
              var t = n + 'Error'
              function r (i, o) {
                ;(this.name = t),
                  i
                    ? typeof i == 'string'
                      ? ((this.message = ''.concat(i).concat(
                          o
                            ? `
 ` + o
                            : ''
                        )),
                        (this.inner = o || null))
                      : typeof i == 'object' &&
                        ((this.message = ''
                          .concat(i.name, ' ')
                          .concat(i.message)),
                        (this.inner = i))
                    : ((this.message = Kr[n] || t), (this.inner = null))
              }
              return Re(r).from(Er), (e[n] = r), e
            }, {})
          ;(A.Syntax = SyntaxError),
            (A.Type = TypeError),
            (A.Range = RangeError)
          var Rt = Je.reduce(function (e, n) {
              return (e[n + 'Error'] = A[n]), e
            }, {}),
            pn = re.reduce(function (e, n) {
              return (
                ['Syntax', 'Type', 'Range'].indexOf(n) === -1 &&
                  (e[n + 'Error'] = A[n]),
                e
              )
            }, {})
          function M () {}
          function Xe (e) {
            return e
          }
          function Sr (e, n) {
            return e == null || e === Xe
              ? n
              : function (t) {
                  return n(e(t))
                }
          }
          function Pe (e, n) {
            return function () {
              e.apply(this, arguments), n.apply(this, arguments)
            }
          }
          function jr (e, n) {
            return e === M
              ? n
              : function () {
                  var t = e.apply(this, arguments)
                  t !== void 0 && (arguments[0] = t)
                  var r = this.onsuccess,
                    i = this.onerror
                  ;(this.onsuccess = null), (this.onerror = null)
                  var o = n.apply(this, arguments)
                  return (
                    r &&
                      (this.onsuccess = this.onsuccess
                        ? Pe(r, this.onsuccess)
                        : r),
                    i &&
                      (this.onerror = this.onerror ? Pe(i, this.onerror) : i),
                    o !== void 0 ? o : t
                  )
                }
          }
          function Ar (e, n) {
            return e === M
              ? n
              : function () {
                  e.apply(this, arguments)
                  var t = this.onsuccess,
                    r = this.onerror
                  ;(this.onsuccess = this.onerror = null),
                    n.apply(this, arguments),
                    t &&
                      (this.onsuccess = this.onsuccess
                        ? Pe(t, this.onsuccess)
                        : t),
                    r && (this.onerror = this.onerror ? Pe(r, this.onerror) : r)
                }
          }
          function Cr (e, n) {
            return e === M
              ? n
              : function (t) {
                  var r = e.apply(this, arguments)
                  Z(t, r)
                  var i = this.onsuccess,
                    o = this.onerror
                  return (
                    (this.onsuccess = null),
                    (this.onerror = null),
                    (t = n.apply(this, arguments)),
                    i &&
                      (this.onsuccess = this.onsuccess
                        ? Pe(i, this.onsuccess)
                        : i),
                    o &&
                      (this.onerror = this.onerror ? Pe(o, this.onerror) : o),
                    r === void 0 ? (t === void 0 ? void 0 : t) : Z(r, t)
                  )
                }
          }
          function Dr (e, n) {
            return e === M
              ? n
              : function () {
                  return (
                    n.apply(this, arguments) !== !1 && e.apply(this, arguments)
                  )
                }
          }
          function Yn (e, n) {
            return e === M
              ? n
              : function () {
                  var t = e.apply(this, arguments)
                  if (t && typeof t.then == 'function') {
                    for (
                      var r = this, i = arguments.length, o = new Array(i);
                      i--;

                    )
                      o[i] = arguments[i]
                    return t.then(function () {
                      return n.apply(r, o)
                    })
                  }
                  return n.apply(this, arguments)
                }
          }
          ;(pn.ModifyError = dn), (pn.DexieError = Fe), (pn.BulkError = Ne)
          var ie =
            typeof location < 'u' &&
            /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href)
          function Mt (e) {
            ie = e
          }
          var He = {},
            Ft = 100,
            fe =
              typeof Promise > 'u'
                ? []
                : (function () {
                    var e = Promise.resolve()
                    if (typeof crypto > 'u' || !crypto.subtle)
                      return [e, Ie(e), e]
                    var n = crypto.subtle.digest('SHA-512', new Uint8Array([0]))
                    return [n, Ie(n), e]
                  })(),
            Je = fe[0],
            re = fe[1],
            fe = fe[2],
            re = re && re.then,
            Ke = Je && Je.constructor,
            $n = !!fe,
            Ze = function (e, n) {
              en.push([e, n]), yn && (queueMicrotask(Tr), (yn = !1))
            },
            Gn = !0,
            yn = !0,
            Ee = [],
            vn = [],
            Qn = Xe,
            ve = {
              id: 'global',
              global: !0,
              ref: 0,
              unhandleds: [],
              onunhandled: M,
              pgp: !1,
              env: {},
              finalize: M
            },
            j = ve,
            en = [],
            Se = 0,
            mn = []
          function E (e) {
            if (typeof this != 'object')
              throw new TypeError('Promises must be constructed via new')
            ;(this._listeners = []), (this._lib = !1)
            var n = (this._PSD = j)
            if (typeof e != 'function') {
              if (e !== He) throw new TypeError('Not a function')
              return (
                (this._state = arguments[1]),
                (this._value = arguments[2]),
                void (this._state === !1 && Hn(this, this._value))
              )
            }
            ;(this._state = null),
              (this._value = null),
              ++n.ref,
              (function t (r, i) {
                try {
                  i(function (o) {
                    if (r._state === null) {
                      if (o === r)
                        throw new TypeError(
                          'A promise cannot be resolved with itself.'
                        )
                      var a = r._lib && Le()
                      o && typeof o.then == 'function'
                        ? t(r, function (u, c) {
                            o instanceof E ? o._then(u, c) : o.then(u, c)
                          })
                        : ((r._state = !0), (r._value = o), Lt(r)),
                        a && Ue()
                    }
                  }, Hn.bind(null, r))
                } catch (o) {
                  Hn(r, o)
                }
              })(this, e)
          }
          var Xn = {
            get: function () {
              var e = j,
                n = _n
              function t (r, i) {
                var o = this,
                  a = !e.global && (e !== j || n !== _n),
                  u = a && !ge(),
                  c = new E(function (f, p) {
                    Jn(o, new Nt(zt(r, e, a, u), zt(i, e, a, u), f, p, e))
                  })
                return (
                  this._consoleTask && (c._consoleTask = this._consoleTask), c
                )
              }
              return (t.prototype = He), t
            },
            set: function (e) {
              ye(
                this,
                'then',
                e && e.prototype === He
                  ? Xn
                  : {
                      get: function () {
                        return e
                      },
                      set: Xn.set
                    }
              )
            }
          }
          function Nt (e, n, t, r, i) {
            ;(this.onFulfilled = typeof e == 'function' ? e : null),
              (this.onRejected = typeof n == 'function' ? n : null),
              (this.resolve = t),
              (this.reject = r),
              (this.psd = i)
          }
          function Hn (e, n) {
            var t, r
            vn.push(n),
              e._state === null &&
                ((t = e._lib && Le()),
                (n = Qn(n)),
                (e._state = !1),
                (e._value = n),
                (r = e),
                Ee.some(function (i) {
                  return i._value === r._value
                }) || Ee.push(r),
                Lt(e),
                t && Ue())
          }
          function Lt (e) {
            var n = e._listeners
            e._listeners = []
            for (var t = 0, r = n.length; t < r; ++t) Jn(e, n[t])
            var i = e._PSD
            --i.ref || i.finalize(),
              Se === 0 &&
                (++Se,
                Ze(function () {
                  --Se == 0 && Zn()
                }, []))
          }
          function Jn (e, n) {
            if (e._state !== null) {
              var t = e._state ? n.onFulfilled : n.onRejected
              if (t === null) return (e._state ? n.resolve : n.reject)(e._value)
              ++n.psd.ref, ++Se, Ze(qr, [t, e, n])
            } else e._listeners.push(n)
          }
          function qr (e, n, t) {
            try {
              var r,
                i = n._value
              !n._state && vn.length && (vn = []),
                (r =
                  ie && n._consoleTask
                    ? n._consoleTask.run(function () {
                        return e(i)
                      })
                    : e(i)),
                n._state ||
                  vn.indexOf(i) !== -1 ||
                  (function (o) {
                    for (var a = Ee.length; a; )
                      if (Ee[--a]._value === o._value) return Ee.splice(a, 1)
                  })(n),
                t.resolve(r)
            } catch (o) {
              t.reject(o)
            } finally {
              --Se == 0 && Zn(), --t.psd.ref || t.psd.finalize()
            }
          }
          function Tr () {
            je(ve, function () {
              Le() && Ue()
            })
          }
          function Le () {
            var e = Gn
            return (yn = Gn = !1), e
          }
          function Ue () {
            var e, n, t
            do
              for (; 0 < en.length; )
                for (e = en, en = [], t = e.length, n = 0; n < t; ++n) {
                  var r = e[n]
                  r[0].apply(null, r[1])
                }
            while (0 < en.length)
            yn = Gn = !0
          }
          function Zn () {
            var e = Ee
            ;(Ee = []),
              e.forEach(function (r) {
                r._PSD.onunhandled.call(null, r._value, r)
              })
            for (var n = mn.slice(0), t = n.length; t; ) n[--t]()
          }
          function gn (e) {
            return new E(He, !1, e)
          }
          function N (e, n) {
            var t = j
            return function () {
              var r = Le(),
                i = j
              try {
                return be(t, !0), e.apply(this, arguments)
              } catch (o) {
                n && n(o)
              } finally {
                be(i, !1), r && Ue()
              }
            }
          }
          Be(E.prototype, {
            then: Xn,
            _then: function (e, n) {
              Jn(this, new Nt(null, null, e, n, j))
            },
            catch: function (e) {
              if (arguments.length === 1) return this.then(null, e)
              var n = e,
                t = arguments[1]
              return typeof n == 'function'
                ? this.then(null, function (r) {
                    return (r instanceof n ? t : gn)(r)
                  })
                : this.then(null, function (r) {
                    return (r && r.name === n ? t : gn)(r)
                  })
            },
            finally: function (e) {
              return this.then(
                function (n) {
                  return E.resolve(e()).then(function () {
                    return n
                  })
                },
                function (n) {
                  return E.resolve(e()).then(function () {
                    return gn(n)
                  })
                }
              )
            },
            timeout: function (e, n) {
              var t = this
              return e < 1 / 0
                ? new E(function (r, i) {
                    var o = setTimeout(function () {
                      return i(new A.Timeout(n))
                    }, e)
                    t.then(r, i).finally(clearTimeout.bind(null, o))
                  })
                : this
            }
          }),
            typeof Symbol < 'u' &&
              Symbol.toStringTag &&
              ye(E.prototype, Symbol.toStringTag, 'Dexie.Promise'),
            (ve.env = Ut()),
            Be(E, {
              all: function () {
                var e = ce.apply(null, arguments).map(xn)
                return new E(function (n, t) {
                  e.length === 0 && n([])
                  var r = e.length
                  e.forEach(function (i, o) {
                    return E.resolve(i).then(function (a) {
                      ;(e[o] = a), --r || n(e)
                    }, t)
                  })
                })
              },
              resolve: function (e) {
                return e instanceof E
                  ? e
                  : e && typeof e.then == 'function'
                  ? new E(function (n, t) {
                      e.then(n, t)
                    })
                  : new E(He, !0, e)
              },
              reject: gn,
              race: function () {
                var e = ce.apply(null, arguments).map(xn)
                return new E(function (n, t) {
                  e.map(function (r) {
                    return E.resolve(r).then(n, t)
                  })
                })
              },
              PSD: {
                get: function () {
                  return j
                },
                set: function (e) {
                  return (j = e)
                }
              },
              totalEchoes: {
                get: function () {
                  return _n
                }
              },
              newPSD: me,
              usePSD: je,
              scheduler: {
                get: function () {
                  return Ze
                },
                set: function (e) {
                  Ze = e
                }
              },
              rejectionMapper: {
                get: function () {
                  return Qn
                },
                set: function (e) {
                  Qn = e
                }
              },
              follow: function (e, n) {
                return new E(function (t, r) {
                  return me(
                    function (i, o) {
                      var a = j
                      ;(a.unhandleds = []),
                        (a.onunhandled = o),
                        (a.finalize = Pe(function () {
                          var u,
                            c = this
                          ;(u = function () {
                            c.unhandleds.length === 0 ? i() : o(c.unhandleds[0])
                          }),
                            mn.push(function f () {
                              u(), mn.splice(mn.indexOf(f), 1)
                            }),
                            ++Se,
                            Ze(function () {
                              --Se == 0 && Zn()
                            }, [])
                        }, a.finalize)),
                        e()
                    },
                    n,
                    t,
                    r
                  )
                })
              }
            }),
            Ke &&
              (Ke.allSettled &&
                ye(E, 'allSettled', function () {
                  var e = ce.apply(null, arguments).map(xn)
                  return new E(function (n) {
                    e.length === 0 && n([])
                    var t = e.length,
                      r = new Array(t)
                    e.forEach(function (i, o) {
                      return E.resolve(i)
                        .then(
                          function (a) {
                            return (r[o] = { status: 'fulfilled', value: a })
                          },
                          function (a) {
                            return (r[o] = { status: 'rejected', reason: a })
                          }
                        )
                        .then(function () {
                          return --t || n(r)
                        })
                    })
                  })
                }),
              Ke.any &&
                typeof AggregateError < 'u' &&
                ye(E, 'any', function () {
                  var e = ce.apply(null, arguments).map(xn)
                  return new E(function (n, t) {
                    e.length === 0 && t(new AggregateError([]))
                    var r = e.length,
                      i = new Array(r)
                    e.forEach(function (o, a) {
                      return E.resolve(o).then(
                        function (u) {
                          return n(u)
                        },
                        function (u) {
                          ;(i[a] = u), --r || t(new AggregateError(i))
                        }
                      )
                    })
                  })
                }),
              Ke.withResolvers && (E.withResolvers = Ke.withResolvers))
          var W = { awaits: 0, echoes: 0, id: 0 },
            Ir = 0,
            bn = [],
            wn = 0,
            _n = 0,
            Br = 0
          function me (e, n, t, r) {
            var i = j,
              o = Object.create(i)
            return (
              (o.parent = i),
              (o.ref = 0),
              (o.global = !1),
              (o.id = ++Br),
              ve.env,
              (o.env = $n
                ? {
                    Promise: E,
                    PromiseProp: { value: E, configurable: !0, writable: !0 },
                    all: E.all,
                    race: E.race,
                    allSettled: E.allSettled,
                    any: E.any,
                    resolve: E.resolve,
                    reject: E.reject
                  }
                : {}),
              n && Z(o, n),
              ++i.ref,
              (o.finalize = function () {
                --this.parent.ref || this.parent.finalize()
              }),
              (r = je(o, e, t, r)),
              o.ref === 0 && o.finalize(),
              r
            )
          }
          function ze () {
            return W.id || (W.id = ++Ir), ++W.awaits, (W.echoes += Ft), W.id
          }
          function ge () {
            return (
              !!W.awaits &&
              (--W.awaits == 0 && (W.id = 0), (W.echoes = W.awaits * Ft), !0)
            )
          }
          function xn (e) {
            return W.echoes && e && e.constructor === Ke
              ? (ze(),
                e.then(
                  function (n) {
                    return ge(), n
                  },
                  function (n) {
                    return ge(), U(n)
                  }
                ))
              : e
          }
          function Rr () {
            var e = bn[bn.length - 1]
            bn.pop(), be(e, !1)
          }
          function be (e, n) {
            var t,
              r = j
            ;(n ? !W.echoes || (wn++ && e === j) : !wn || (--wn && e === j)) ||
              queueMicrotask(
                n
                  ? function (i) {
                      ++_n,
                        (W.echoes && --W.echoes != 0) ||
                          (W.echoes = W.awaits = W.id = 0),
                        bn.push(j),
                        be(i, !0)
                    }.bind(null, e)
                  : Rr
              ),
              e !== j &&
                ((j = e),
                r === ve && (ve.env = Ut()),
                $n &&
                  ((t = ve.env.Promise),
                  (n = e.env),
                  (r.global || e.global) &&
                    (Object.defineProperty($, 'Promise', n.PromiseProp),
                    (t.all = n.all),
                    (t.race = n.race),
                    (t.resolve = n.resolve),
                    (t.reject = n.reject),
                    n.allSettled && (t.allSettled = n.allSettled),
                    n.any && (t.any = n.any))))
          }
          function Ut () {
            var e = $.Promise
            return $n
              ? {
                  Promise: e,
                  PromiseProp: Object.getOwnPropertyDescriptor($, 'Promise'),
                  all: e.all,
                  race: e.race,
                  allSettled: e.allSettled,
                  any: e.any,
                  resolve: e.resolve,
                  reject: e.reject
                }
              : {}
          }
          function je (e, n, t, r, i) {
            var o = j
            try {
              return be(e, !0), n(t, r, i)
            } finally {
              be(o, !1)
            }
          }
          function zt (e, n, t, r) {
            return typeof e != 'function'
              ? e
              : function () {
                  var i = j
                  t && ze(), be(n, !0)
                  try {
                    return e.apply(this, arguments)
                  } finally {
                    be(i, !1), r && queueMicrotask(ge)
                  }
                }
          }
          function et (e) {
            Promise === Ke && W.echoes === 0
              ? wn === 0
                ? e()
                : enqueueNativeMicroTask(e)
              : setTimeout(e, 0)
          }
          ;('' + re).indexOf('[native code]') === -1 && (ze = ge = M)
          var U = E.reject,
            Ae = '￿',
            le =
              'Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.',
            Vt = 'String expected.',
            Ve = [],
            kn = '__dbnames',
            nt = 'readonly',
            tt = 'readwrite'
          function Ce (e, n) {
            return e
              ? n
                ? function () {
                    return e.apply(this, arguments) && n.apply(this, arguments)
                  }
                : e
              : n
          }
          var Wt = {
            type: 3,
            lower: -1 / 0,
            lowerOpen: !1,
            upper: [[]],
            upperOpen: !1
          }
          function On (e) {
            return typeof e != 'string' || /\./.test(e)
              ? function (n) {
                  return n
                }
              : function (n) {
                  return n[e] === void 0 && e in n && delete (n = ke(n))[e], n
                }
          }
          function Yt () {
            throw A.Type()
          }
          function B (e, n) {
            try {
              var t = $t(e),
                r = $t(n)
              if (t !== r)
                return t === 'Array'
                  ? 1
                  : r === 'Array'
                  ? -1
                  : t === 'binary'
                  ? 1
                  : r === 'binary'
                  ? -1
                  : t === 'string'
                  ? 1
                  : r === 'string'
                  ? -1
                  : t === 'Date'
                  ? 1
                  : r !== 'Date'
                  ? NaN
                  : -1
              switch (t) {
                case 'number':
                case 'Date':
                case 'string':
                  return n < e ? 1 : e < n ? -1 : 0
                case 'binary':
                  return (function (i, o) {
                    for (
                      var a = i.length, u = o.length, c = a < u ? a : u, f = 0;
                      f < c;
                      ++f
                    )
                      if (i[f] !== o[f]) return i[f] < o[f] ? -1 : 1
                    return a === u ? 0 : a < u ? -1 : 1
                  })(Gt(e), Gt(n))
                case 'Array':
                  return (function (i, o) {
                    for (
                      var a = i.length, u = o.length, c = a < u ? a : u, f = 0;
                      f < c;
                      ++f
                    ) {
                      var p = B(i[f], o[f])
                      if (p !== 0) return p
                    }
                    return a === u ? 0 : a < u ? -1 : 1
                  })(e, n)
              }
            } catch {}
            return NaN
          }
          function $t (e) {
            var n = typeof e
            return n != 'object'
              ? n
              : ArrayBuffer.isView(e)
              ? 'binary'
              : ((e = Un(e)), e === 'ArrayBuffer' ? 'binary' : e)
          }
          function Gt (e) {
            return e instanceof Uint8Array
              ? e
              : ArrayBuffer.isView(e)
              ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength)
              : new Uint8Array(e)
          }
          var Qt =
            ((F.prototype._trans = function (e, n, t) {
              var r = this._tx || j.trans,
                i = this.name,
                o =
                  ie &&
                  typeof console < 'u' &&
                  console.createTask &&
                  console.createTask(
                    'Dexie: '
                      .concat(e === 'readonly' ? 'read' : 'write', ' ')
                      .concat(this.name)
                  )
              function a (f, p, s) {
                if (!s.schema[i])
                  throw new A.NotFound(
                    'Table ' + i + ' not part of transaction'
                  )
                return n(s.idbtrans, s)
              }
              var u = Le()
              try {
                var c =
                  r && r.db._novip === this.db._novip
                    ? r === j.trans
                      ? r._promise(e, a, t)
                      : me(
                          function () {
                            return r._promise(e, a, t)
                          },
                          { trans: r, transless: j.transless || j }
                        )
                    : (function f (p, s, v, l) {
                        if (
                          p.idbdb &&
                          (p._state.openComplete || j.letThrough || p._vip)
                        ) {
                          var d = p._createTransaction(s, v, p._dbSchema)
                          try {
                            d.create(), (p._state.PR1398_maxLoop = 3)
                          } catch (y) {
                            return y.name === Wn.InvalidState &&
                              p.isOpen() &&
                              0 < --p._state.PR1398_maxLoop
                              ? (console.warn('Dexie: Need to reopen db'),
                                p.close({ disableAutoOpen: !1 }),
                                p.open().then(function () {
                                  return f(p, s, v, l)
                                }))
                              : U(y)
                          }
                          return d
                            ._promise(s, function (y, h) {
                              return me(function () {
                                return (j.trans = d), l(y, h, d)
                              })
                            })
                            .then(function (y) {
                              if (s === 'readwrite')
                                try {
                                  d.idbtrans.commit()
                                } catch {}
                              return s === 'readonly'
                                ? y
                                : d._completion.then(function () {
                                    return y
                                  })
                            })
                        }
                        if (p._state.openComplete)
                          return U(new A.DatabaseClosed(p._state.dbOpenError))
                        if (!p._state.isBeingOpened) {
                          if (!p._state.autoOpen)
                            return U(new A.DatabaseClosed())
                          p.open().catch(M)
                        }
                        return p._state.dbReadyPromise.then(function () {
                          return f(p, s, v, l)
                        })
                      })(this.db, e, [this.name], a)
                return (
                  o &&
                    ((c._consoleTask = o),
                    (c = c.catch(function (f) {
                      return console.trace(f), U(f)
                    }))),
                  c
                )
              } finally {
                u && Ue()
              }
            }),
            (F.prototype.get = function (e, n) {
              var t = this
              return e && e.constructor === Object
                ? this.where(e).first(n)
                : e == null
                ? U(new A.Type('Invalid argument to Table.get()'))
                : this._trans('readonly', function (r) {
                    return t.core.get({ trans: r, key: e }).then(function (i) {
                      return t.hook.reading.fire(i)
                    })
                  }).then(n)
            }),
            (F.prototype.where = function (e) {
              if (typeof e == 'string') return new this.db.WhereClause(this, e)
              if (L(e))
                return new this.db.WhereClause(
                  this,
                  '['.concat(e.join('+'), ']')
                )
              var n = V(e)
              if (n.length === 1) return this.where(n[0]).equals(e[n[0]])
              var t = this.schema.indexes
                .concat(this.schema.primKey)
                .filter(function (u) {
                  if (
                    u.compound &&
                    n.every(function (f) {
                      return 0 <= u.keyPath.indexOf(f)
                    })
                  ) {
                    for (var c = 0; c < n.length; ++c)
                      if (n.indexOf(u.keyPath[c]) === -1) return !1
                    return !0
                  }
                  return !1
                })
                .sort(function (u, c) {
                  return u.keyPath.length - c.keyPath.length
                })[0]
              if (t && this.db._maxKey !== Ae) {
                var o = t.keyPath.slice(0, n.length)
                return this.where(o).equals(
                  o.map(function (c) {
                    return e[c]
                  })
                )
              }
              !t &&
                ie &&
                console.warn(
                  'The query '
                    .concat(JSON.stringify(e), ' on ')
                    .concat(this.name, ' would benefit from a ') +
                    'compound index ['.concat(n.join('+'), ']')
                )
              var r = this.schema.idxByName
              function i (u, c) {
                return B(u, c) === 0
              }
              var a = n.reduce(
                  function (s, c) {
                    var f = s[0],
                      p = s[1],
                      s = r[c],
                      v = e[c]
                    return [
                      f || s,
                      f || !s
                        ? Ce(
                            p,
                            s && s.multi
                              ? function (l) {
                                  return (
                                    (l = se(l, c)),
                                    L(l) &&
                                      l.some(function (d) {
                                        return i(v, d)
                                      })
                                  )
                                }
                              : function (l) {
                                  return i(v, se(l, c))
                                }
                          )
                        : p
                    ]
                  },
                  [null, null]
                ),
                o = a[0],
                a = a[1]
              return o
                ? this.where(o.name).equals(e[o.keyPath]).filter(a)
                : t
                ? this.filter(a)
                : this.where(n).equals('')
            }),
            (F.prototype.filter = function (e) {
              return this.toCollection().and(e)
            }),
            (F.prototype.count = function (e) {
              return this.toCollection().count(e)
            }),
            (F.prototype.offset = function (e) {
              return this.toCollection().offset(e)
            }),
            (F.prototype.limit = function (e) {
              return this.toCollection().limit(e)
            }),
            (F.prototype.each = function (e) {
              return this.toCollection().each(e)
            }),
            (F.prototype.toArray = function (e) {
              return this.toCollection().toArray(e)
            }),
            (F.prototype.toCollection = function () {
              return new this.db.Collection(new this.db.WhereClause(this))
            }),
            (F.prototype.orderBy = function (e) {
              return new this.db.Collection(
                new this.db.WhereClause(
                  this,
                  L(e) ? '['.concat(e.join('+'), ']') : e
                )
              )
            }),
            (F.prototype.reverse = function () {
              return this.toCollection().reverse()
            }),
            (F.prototype.mapToClass = function (e) {
              var n,
                t = this.db,
                r = this.name
              function i () {
                return (n !== null && n.apply(this, arguments)) || this
              }
              ;(this.schema.mappedClass = e).prototype instanceof Yt &&
                ((function (c, f) {
                  if (typeof f != 'function' && f !== null)
                    throw new TypeError(
                      'Class extends value ' +
                        String(f) +
                        ' is not a constructor or null'
                    )
                  function p () {
                    this.constructor = c
                  }
                  pe(c, f),
                    (c.prototype =
                      f === null
                        ? Object.create(f)
                        : ((p.prototype = f.prototype), new p()))
                })(i, (n = e)),
                Object.defineProperty(i.prototype, 'db', {
                  get: function () {
                    return t
                  },
                  enumerable: !1,
                  configurable: !0
                }),
                (i.prototype.table = function () {
                  return r
                }),
                (e = i))
              for (var o = new Set(), a = e.prototype; a; a = Ie(a))
                Object.getOwnPropertyNames(a).forEach(function (c) {
                  return o.add(c)
                })
              function u (c) {
                if (!c) return c
                var f,
                  p = Object.create(e.prototype)
                for (f in c)
                  if (!o.has(f))
                    try {
                      p[f] = c[f]
                    } catch {}
                return p
              }
              return (
                this.schema.readHook &&
                  this.hook.reading.unsubscribe(this.schema.readHook),
                (this.schema.readHook = u),
                this.hook('reading', u),
                e
              )
            }),
            (F.prototype.defineClass = function () {
              return this.mapToClass(function (e) {
                Z(this, e)
              })
            }),
            (F.prototype.add = function (e, n) {
              var t = this,
                r = this.schema.primKey,
                i = r.auto,
                o = r.keyPath,
                a = e
              return (
                o && i && (a = On(o)(e)),
                this._trans('readwrite', function (u) {
                  return t.core.mutate({
                    trans: u,
                    type: 'add',
                    keys: n != null ? [n] : null,
                    values: [a]
                  })
                })
                  .then(function (u) {
                    return u.numFailures
                      ? E.reject(u.failures[0])
                      : u.lastResult
                  })
                  .then(function (u) {
                    if (o)
                      try {
                        ee(e, o, u)
                      } catch {}
                    return u
                  })
              )
            }),
            (F.prototype.update = function (e, n) {
              return typeof e != 'object' || L(e)
                ? this.where(':id').equals(e).modify(n)
                : ((e = se(e, this.schema.primKey.keyPath)),
                  e === void 0
                    ? U(
                        new A.InvalidArgument(
                          'Given object does not contain its primary key'
                        )
                      )
                    : this.where(':id').equals(e).modify(n))
            }),
            (F.prototype.put = function (e, n) {
              var t = this,
                r = this.schema.primKey,
                i = r.auto,
                o = r.keyPath,
                a = e
              return (
                o && i && (a = On(o)(e)),
                this._trans('readwrite', function (u) {
                  return t.core.mutate({
                    trans: u,
                    type: 'put',
                    values: [a],
                    keys: n != null ? [n] : null
                  })
                })
                  .then(function (u) {
                    return u.numFailures
                      ? E.reject(u.failures[0])
                      : u.lastResult
                  })
                  .then(function (u) {
                    if (o)
                      try {
                        ee(e, o, u)
                      } catch {}
                    return u
                  })
              )
            }),
            (F.prototype.delete = function (e) {
              var n = this
              return this._trans('readwrite', function (t) {
                return n.core.mutate({ trans: t, type: 'delete', keys: [e] })
              }).then(function (t) {
                return t.numFailures ? E.reject(t.failures[0]) : void 0
              })
            }),
            (F.prototype.clear = function () {
              var e = this
              return this._trans('readwrite', function (n) {
                return e.core.mutate({
                  trans: n,
                  type: 'deleteRange',
                  range: Wt
                })
              }).then(function (n) {
                return n.numFailures ? E.reject(n.failures[0]) : void 0
              })
            }),
            (F.prototype.bulkGet = function (e) {
              var n = this
              return this._trans('readonly', function (t) {
                return n.core.getMany({ keys: e, trans: t }).then(function (r) {
                  return r.map(function (i) {
                    return n.hook.reading.fire(i)
                  })
                })
              })
            }),
            (F.prototype.bulkAdd = function (e, n, t) {
              var r = this,
                i = Array.isArray(n) ? n : void 0,
                o = (t = t || (i ? void 0 : n)) ? t.allKeys : void 0
              return this._trans('readwrite', function (a) {
                var f = r.schema.primKey,
                  u = f.auto,
                  f = f.keyPath
                if (f && i)
                  throw new A.InvalidArgument(
                    'bulkAdd(): keys argument invalid on tables with inbound keys'
                  )
                if (i && i.length !== e.length)
                  throw new A.InvalidArgument(
                    'Arguments objects and keys must have the same length'
                  )
                var c = e.length,
                  f = f && u ? e.map(On(f)) : e
                return r.core
                  .mutate({
                    trans: a,
                    type: 'add',
                    keys: i,
                    values: f,
                    wantResults: o
                  })
                  .then(function (d) {
                    var s = d.numFailures,
                      v = d.results,
                      l = d.lastResult,
                      d = d.failures
                    if (s === 0) return o ? v : l
                    throw new Ne(
                      ''
                        .concat(r.name, '.bulkAdd(): ')
                        .concat(s, ' of ')
                        .concat(c, ' operations failed'),
                      d
                    )
                  })
              })
            }),
            (F.prototype.bulkPut = function (e, n, t) {
              var r = this,
                i = Array.isArray(n) ? n : void 0,
                o = (t = t || (i ? void 0 : n)) ? t.allKeys : void 0
              return this._trans('readwrite', function (a) {
                var f = r.schema.primKey,
                  u = f.auto,
                  f = f.keyPath
                if (f && i)
                  throw new A.InvalidArgument(
                    'bulkPut(): keys argument invalid on tables with inbound keys'
                  )
                if (i && i.length !== e.length)
                  throw new A.InvalidArgument(
                    'Arguments objects and keys must have the same length'
                  )
                var c = e.length,
                  f = f && u ? e.map(On(f)) : e
                return r.core
                  .mutate({
                    trans: a,
                    type: 'put',
                    keys: i,
                    values: f,
                    wantResults: o
                  })
                  .then(function (d) {
                    var s = d.numFailures,
                      v = d.results,
                      l = d.lastResult,
                      d = d.failures
                    if (s === 0) return o ? v : l
                    throw new Ne(
                      ''
                        .concat(r.name, '.bulkPut(): ')
                        .concat(s, ' of ')
                        .concat(c, ' operations failed'),
                      d
                    )
                  })
              })
            }),
            (F.prototype.bulkUpdate = function (e) {
              var n = this,
                t = this.core,
                r = e.map(function (a) {
                  return a.key
                }),
                i = e.map(function (a) {
                  return a.changes
                }),
                o = []
              return this._trans('readwrite', function (a) {
                return t
                  .getMany({ trans: a, keys: r, cache: 'clone' })
                  .then(function (u) {
                    var c = [],
                      f = []
                    e.forEach(function (s, v) {
                      var l = s.key,
                        d = s.changes,
                        y = u[v]
                      if (y) {
                        for (var h = 0, m = Object.keys(d); h < m.length; h++) {
                          var g = m[h],
                            b = d[g]
                          if (g === n.schema.primKey.keyPath) {
                            if (B(b, l) !== 0)
                              throw new A.Constraint(
                                'Cannot update primary key in bulkUpdate()'
                              )
                          } else ee(y, g, b)
                        }
                        o.push(v), c.push(l), f.push(y)
                      }
                    })
                    var p = c.length
                    return t
                      .mutate({
                        trans: a,
                        type: 'put',
                        keys: c,
                        values: f,
                        updates: { keys: r, changeSpecs: i }
                      })
                      .then(function (s) {
                        var v = s.numFailures,
                          l = s.failures
                        if (v === 0) return p
                        for (var d = 0, y = Object.keys(l); d < y.length; d++) {
                          var h,
                            m = y[d],
                            g = o[Number(m)]
                          g != null && ((h = l[m]), delete l[m], (l[g] = h))
                        }
                        throw new Ne(
                          ''
                            .concat(n.name, '.bulkUpdate(): ')
                            .concat(v, ' of ')
                            .concat(p, ' operations failed'),
                          l
                        )
                      })
                  })
              })
            }),
            (F.prototype.bulkDelete = function (e) {
              var n = this,
                t = e.length
              return this._trans('readwrite', function (r) {
                return n.core.mutate({ trans: r, type: 'delete', keys: e })
              }).then(function (a) {
                var i = a.numFailures,
                  o = a.lastResult,
                  a = a.failures
                if (i === 0) return o
                throw new Ne(
                  ''
                    .concat(n.name, '.bulkDelete(): ')
                    .concat(i, ' of ')
                    .concat(t, ' operations failed'),
                  a
                )
              })
            }),
            F)
          function F () {}
          function nn (e) {
            function n (a, u) {
              if (u) {
                for (var c = arguments.length, f = new Array(c - 1); --c; )
                  f[c - 1] = arguments[c]
                return t[a].subscribe.apply(null, f), e
              }
              if (typeof a == 'string') return t[a]
            }
            var t = {}
            n.addEventType = o
            for (var r = 1, i = arguments.length; r < i; ++r) o(arguments[r])
            return n
            function o (a, u, c) {
              if (typeof a != 'object') {
                var f
                u = u || Dr
                var p = {
                  subscribers: [],
                  fire: (c = c || M),
                  subscribe: function (s) {
                    p.subscribers.indexOf(s) === -1 &&
                      (p.subscribers.push(s), (p.fire = u(p.fire, s)))
                  },
                  unsubscribe: function (s) {
                    ;(p.subscribers = p.subscribers.filter(function (v) {
                      return v !== s
                    })),
                      (p.fire = p.subscribers.reduce(u, c))
                  }
                }
                return (t[a] = n[a] = p)
              }
              V((f = a)).forEach(function (s) {
                var v = f[s]
                if (L(v)) o(s, f[s][0], f[s][1])
                else {
                  if (v !== 'asap')
                    throw new A.InvalidArgument('Invalid event config')
                  var l = o(s, Xe, function () {
                    for (var d = arguments.length, y = new Array(d); d--; )
                      y[d] = arguments[d]
                    l.subscribers.forEach(function (h) {
                      Dt(function () {
                        h.apply(null, y)
                      })
                    })
                  })
                }
              })
            }
          }
          function tn (e, n) {
            return Re(n).from({ prototype: e }), n
          }
          function We (e, n) {
            return (
              !(e.filter || e.algorithm || e.or) &&
              (n ? e.justLimit : !e.replayFilter)
            )
          }
          function rt (e, n) {
            e.filter = Ce(e.filter, n)
          }
          function it (e, n, t) {
            var r = e.replayFilter
            ;(e.replayFilter = r
              ? function () {
                  return Ce(r(), n())
                }
              : n),
              (e.justLimit = t && !r)
          }
          function Pn (e, n) {
            if (e.isPrimKey) return n.primaryKey
            var t = n.getIndexByKeyPath(e.index)
            if (!t)
              throw new A.Schema(
                'KeyPath ' +
                  e.index +
                  ' on object store ' +
                  n.name +
                  ' is not indexed'
              )
            return t
          }
          function Xt (e, n, t) {
            var r = Pn(e, n.schema)
            return n.openCursor({
              trans: t,
              values: !e.keysOnly,
              reverse: e.dir === 'prev',
              unique: !!e.unique,
              query: { index: r, range: e.range }
            })
          }
          function Kn (e, n, t, r) {
            var i = e.replayFilter ? Ce(e.filter, e.replayFilter()) : e.filter
            if (e.or) {
              var o = {},
                a = function (u, c, f) {
                  var p, s
                  ;(i &&
                    !i(
                      c,
                      f,
                      function (v) {
                        return c.stop(v)
                      },
                      function (v) {
                        return c.fail(v)
                      }
                    )) ||
                    ((s = '' + (p = c.primaryKey)) == '[object ArrayBuffer]' &&
                      (s = '' + new Uint8Array(p)),
                    J(o, s) || ((o[s] = !0), n(u, c, f)))
                }
              return Promise.all([
                e.or._iterate(a, t),
                Ht(Xt(e, r, t), e.algorithm, a, !e.keysOnly && e.valueMapper)
              ])
            }
            return Ht(
              Xt(e, r, t),
              Ce(e.algorithm, i),
              n,
              !e.keysOnly && e.valueMapper
            )
          }
          function Ht (e, n, t, r) {
            var i = N(
              r
                ? function (o, a, u) {
                    return t(r(o), a, u)
                  }
                : t
            )
            return e.then(function (o) {
              if (o)
                return o.start(function () {
                  var a = function () {
                    return o.continue()
                  }
                  ;(n &&
                    !n(
                      o,
                      function (u) {
                        return (a = u)
                      },
                      function (u) {
                        o.stop(u), (a = M)
                      },
                      function (u) {
                        o.fail(u), (a = M)
                      }
                    )) ||
                    i(o.value, o, function (u) {
                      return (a = u)
                    }),
                    a()
                })
            })
          }
          var fe = Symbol(),
            rn =
              ((Jt.prototype.execute = function (e) {
                if (this.add !== void 0) {
                  var n = this.add
                  if (L(n)) return fn(fn([], L(e) ? e : [], !0), n).sort()
                  if (typeof n == 'number') return (Number(e) || 0) + n
                  if (typeof n == 'bigint')
                    try {
                      return BigInt(e) + n
                    } catch {
                      return BigInt(0) + n
                    }
                  throw new TypeError('Invalid term '.concat(n))
                }
                if (this.remove !== void 0) {
                  var t = this.remove
                  if (L(t))
                    return L(e)
                      ? e
                          .filter(function (r) {
                            return !t.includes(r)
                          })
                          .sort()
                      : []
                  if (typeof t == 'number') return Number(e) - t
                  if (typeof t == 'bigint')
                    try {
                      return BigInt(e) - t
                    } catch {
                      return BigInt(0) - t
                    }
                  throw new TypeError('Invalid subtrahend '.concat(t))
                }
                return (
                  (n =
                    (n = this.replacePrefix) === null || n === void 0
                      ? void 0
                      : n[0]),
                  n && typeof e == 'string' && e.startsWith(n)
                    ? this.replacePrefix[1] + e.substring(n.length)
                    : e
                )
              }),
              Jt)
          function Jt (e) {
            Object.assign(this, e)
          }
          var Mr =
            ((R.prototype._read = function (e, n) {
              var t = this._ctx
              return t.error
                ? t.table._trans(null, U.bind(null, t.error))
                : t.table._trans('readonly', e).then(n)
            }),
            (R.prototype._write = function (e) {
              var n = this._ctx
              return n.error
                ? n.table._trans(null, U.bind(null, n.error))
                : n.table._trans('readwrite', e, 'locked')
            }),
            (R.prototype._addAlgorithm = function (e) {
              var n = this._ctx
              n.algorithm = Ce(n.algorithm, e)
            }),
            (R.prototype._iterate = function (e, n) {
              return Kn(this._ctx, e, n, this._ctx.table.core)
            }),
            (R.prototype.clone = function (e) {
              var n = Object.create(this.constructor.prototype),
                t = Object.create(this._ctx)
              return e && Z(t, e), (n._ctx = t), n
            }),
            (R.prototype.raw = function () {
              return (this._ctx.valueMapper = null), this
            }),
            (R.prototype.each = function (e) {
              var n = this._ctx
              return this._read(function (t) {
                return Kn(n, e, t, n.table.core)
              })
            }),
            (R.prototype.count = function (e) {
              var n = this
              return this._read(function (t) {
                var r = n._ctx,
                  i = r.table.core
                if (We(r, !0))
                  return i
                    .count({
                      trans: t,
                      query: { index: Pn(r, i.schema), range: r.range }
                    })
                    .then(function (a) {
                      return Math.min(a, r.limit)
                    })
                var o = 0
                return Kn(
                  r,
                  function () {
                    return ++o, !1
                  },
                  t,
                  i
                ).then(function () {
                  return o
                })
              }).then(e)
            }),
            (R.prototype.sortBy = function (e, n) {
              var t = e.split('.').reverse(),
                r = t[0],
                i = t.length - 1
              function o (c, f) {
                return f ? o(c[t[f]], f - 1) : c[r]
              }
              var a = this._ctx.dir === 'next' ? 1 : -1
              function u (c, f) {
                return B(o(c, i), o(f, i)) * a
              }
              return this.toArray(function (c) {
                return c.sort(u)
              }).then(n)
            }),
            (R.prototype.toArray = function (e) {
              var n = this
              return this._read(function (t) {
                var r = n._ctx
                if (r.dir === 'next' && We(r, !0) && 0 < r.limit) {
                  var i = r.valueMapper,
                    o = Pn(r, r.table.core.schema)
                  return r.table.core
                    .query({
                      trans: t,
                      limit: r.limit,
                      values: !0,
                      query: { index: o, range: r.range }
                    })
                    .then(function (u) {
                      return (u = u.result), i ? u.map(i) : u
                    })
                }
                var a = []
                return Kn(
                  r,
                  function (u) {
                    return a.push(u)
                  },
                  t,
                  r.table.core
                ).then(function () {
                  return a
                })
              }, e)
            }),
            (R.prototype.offset = function (e) {
              var n = this._ctx
              return (
                e <= 0 ||
                  ((n.offset += e),
                  We(n)
                    ? it(n, function () {
                        var t = e
                        return function (r, i) {
                          return (
                            t === 0 ||
                            (t === 1
                              ? --t
                              : i(function () {
                                  r.advance(t), (t = 0)
                                }),
                            !1)
                          )
                        }
                      })
                    : it(n, function () {
                        var t = e
                        return function () {
                          return --t < 0
                        }
                      })),
                this
              )
            }),
            (R.prototype.limit = function (e) {
              return (
                (this._ctx.limit = Math.min(this._ctx.limit, e)),
                it(
                  this._ctx,
                  function () {
                    var n = e
                    return function (t, r, i) {
                      return --n <= 0 && r(i), 0 <= n
                    }
                  },
                  !0
                ),
                this
              )
            }),
            (R.prototype.until = function (e, n) {
              return (
                rt(this._ctx, function (t, r, i) {
                  return !e(t.value) || (r(i), n)
                }),
                this
              )
            }),
            (R.prototype.first = function (e) {
              return this.limit(1)
                .toArray(function (n) {
                  return n[0]
                })
                .then(e)
            }),
            (R.prototype.last = function (e) {
              return this.reverse().first(e)
            }),
            (R.prototype.filter = function (e) {
              var n
              return (
                rt(this._ctx, function (t) {
                  return e(t.value)
                }),
                ((n = this._ctx).isMatch = Ce(n.isMatch, e)),
                this
              )
            }),
            (R.prototype.and = function (e) {
              return this.filter(e)
            }),
            (R.prototype.or = function (e) {
              return new this.db.WhereClause(this._ctx.table, e, this)
            }),
            (R.prototype.reverse = function () {
              return (
                (this._ctx.dir = this._ctx.dir === 'prev' ? 'next' : 'prev'),
                this._ondirectionchange &&
                  this._ondirectionchange(this._ctx.dir),
                this
              )
            }),
            (R.prototype.desc = function () {
              return this.reverse()
            }),
            (R.prototype.eachKey = function (e) {
              var n = this._ctx
              return (
                (n.keysOnly = !n.isMatch),
                this.each(function (t, r) {
                  e(r.key, r)
                })
              )
            }),
            (R.prototype.eachUniqueKey = function (e) {
              return (this._ctx.unique = 'unique'), this.eachKey(e)
            }),
            (R.prototype.eachPrimaryKey = function (e) {
              var n = this._ctx
              return (
                (n.keysOnly = !n.isMatch),
                this.each(function (t, r) {
                  e(r.primaryKey, r)
                })
              )
            }),
            (R.prototype.keys = function (e) {
              var n = this._ctx
              n.keysOnly = !n.isMatch
              var t = []
              return this.each(function (r, i) {
                t.push(i.key)
              })
                .then(function () {
                  return t
                })
                .then(e)
            }),
            (R.prototype.primaryKeys = function (e) {
              var n = this._ctx
              if (n.dir === 'next' && We(n, !0) && 0 < n.limit)
                return this._read(function (r) {
                  var i = Pn(n, n.table.core.schema)
                  return n.table.core.query({
                    trans: r,
                    values: !1,
                    limit: n.limit,
                    query: { index: i, range: n.range }
                  })
                })
                  .then(function (r) {
                    return r.result
                  })
                  .then(e)
              n.keysOnly = !n.isMatch
              var t = []
              return this.each(function (r, i) {
                t.push(i.primaryKey)
              })
                .then(function () {
                  return t
                })
                .then(e)
            }),
            (R.prototype.uniqueKeys = function (e) {
              return (this._ctx.unique = 'unique'), this.keys(e)
            }),
            (R.prototype.firstKey = function (e) {
              return this.limit(1)
                .keys(function (n) {
                  return n[0]
                })
                .then(e)
            }),
            (R.prototype.lastKey = function (e) {
              return this.reverse().firstKey(e)
            }),
            (R.prototype.distinct = function () {
              var e = this._ctx,
                e = e.index && e.table.schema.idxByName[e.index]
              if (!e || !e.multi) return this
              var n = {}
              return (
                rt(this._ctx, function (i) {
                  var r = i.primaryKey.toString(),
                    i = J(n, r)
                  return (n[r] = !0), !i
                }),
                this
              )
            }),
            (R.prototype.modify = function (e) {
              var n = this,
                t = this._ctx
              return this._write(function (r) {
                var i, o, a
                a =
                  typeof e == 'function'
                    ? e
                    : ((i = V(e)),
                      (o = i.length),
                      function (h) {
                        for (var m = !1, g = 0; g < o; ++g) {
                          var b = i[g],
                            w = e[b],
                            _ = se(h, b)
                          w instanceof rn
                            ? (ee(h, b, w.execute(_)), (m = !0))
                            : _ !== w && (ee(h, b, w), (m = !0))
                        }
                        return m
                      })
                var u = t.table.core,
                  s = u.schema.primaryKey,
                  c = s.outbound,
                  f = s.extractKey,
                  p = 200,
                  s = n.db._options.modifyChunkSize
                s && (p = typeof s == 'object' ? s[u.name] || s['*'] || 200 : s)
                function v (h, b) {
                  var g = b.failures,
                    b = b.numFailures
                  d += h - b
                  for (var w = 0, _ = V(g); w < _.length; w++) {
                    var P = _[w]
                    l.push(g[P])
                  }
                }
                var l = [],
                  d = 0,
                  y = []
                return n
                  .clone()
                  .primaryKeys()
                  .then(function (h) {
                    function m (b) {
                      var w = Math.min(p, h.length - b)
                      return u
                        .getMany({
                          trans: r,
                          keys: h.slice(b, b + w),
                          cache: 'immutable'
                        })
                        .then(function (_) {
                          for (
                            var P = [],
                              x = [],
                              k = c ? [] : null,
                              K = [],
                              O = 0;
                            O < w;
                            ++O
                          ) {
                            var S = _[O],
                              q = { value: ke(S), primKey: h[b + O] }
                            a.call(q, q.value, q) !== !1 &&
                              (q.value == null
                                ? K.push(h[b + O])
                                : c || B(f(S), f(q.value)) === 0
                                ? (x.push(q.value), c && k.push(h[b + O]))
                                : (K.push(h[b + O]), P.push(q.value)))
                          }
                          return Promise.resolve(
                            0 < P.length &&
                              u
                                .mutate({ trans: r, type: 'add', values: P })
                                .then(function (T) {
                                  for (var I in T.failures)
                                    K.splice(parseInt(I), 1)
                                  v(P.length, T)
                                })
                          )
                            .then(function () {
                              return (
                                (0 < x.length || (g && typeof e == 'object')) &&
                                u
                                  .mutate({
                                    trans: r,
                                    type: 'put',
                                    keys: k,
                                    values: x,
                                    criteria: g,
                                    changeSpec: typeof e != 'function' && e,
                                    isAdditionalChunk: 0 < b
                                  })
                                  .then(function (T) {
                                    return v(x.length, T)
                                  })
                              )
                            })
                            .then(function () {
                              return (
                                (0 < K.length || (g && e === ot)) &&
                                u
                                  .mutate({
                                    trans: r,
                                    type: 'delete',
                                    keys: K,
                                    criteria: g,
                                    isAdditionalChunk: 0 < b
                                  })
                                  .then(function (T) {
                                    return v(K.length, T)
                                  })
                              )
                            })
                            .then(function () {
                              return h.length > b + w && m(b + p)
                            })
                        })
                    }
                    var g = We(t) &&
                      t.limit === 1 / 0 &&
                      (typeof e != 'function' || e === ot) && {
                        index: t.index,
                        range: t.range
                      }
                    return m(0).then(function () {
                      if (0 < l.length)
                        throw new dn(
                          'Error modifying one or more objects',
                          l,
                          d,
                          y
                        )
                      return h.length
                    })
                  })
              })
            }),
            (R.prototype.delete = function () {
              var e = this._ctx,
                n = e.range
              return We(e) && (e.isPrimKey || n.type === 3)
                ? this._write(function (t) {
                    var r = e.table.core.schema.primaryKey,
                      i = n
                    return e.table.core
                      .count({ trans: t, query: { index: r, range: i } })
                      .then(function (o) {
                        return e.table.core
                          .mutate({ trans: t, type: 'deleteRange', range: i })
                          .then(function (a) {
                            var u = a.failures
                            if (
                              (a.lastResult, a.results, (a = a.numFailures), a)
                            )
                              throw new dn(
                                'Could not delete some values',
                                Object.keys(u).map(function (c) {
                                  return u[c]
                                }),
                                o - a
                              )
                            return o - a
                          })
                      })
                  })
                : this.modify(ot)
            }),
            R)
          function R () {}
          var ot = function (e, n) {
            return (n.value = null)
          }
          function Fr (e, n) {
            return e < n ? -1 : e === n ? 0 : 1
          }
          function Nr (e, n) {
            return n < e ? -1 : e === n ? 0 : 1
          }
          function ne (e, n, t) {
            return (
              (e = e instanceof er ? new e.Collection(e) : e),
              (e._ctx.error = new (t || TypeError)(n)),
              e
            )
          }
          function Ye (e) {
            return new e.Collection(e, function () {
              return Zt('')
            }).limit(0)
          }
          function En (e, n, t, r) {
            var i,
              o,
              a,
              u,
              c,
              f,
              p,
              s = t.length
            if (
              !t.every(function (d) {
                return typeof d == 'string'
              })
            )
              return ne(e, Vt)
            function v (d) {
              ;(i =
                d === 'next'
                  ? function (h) {
                      return h.toUpperCase()
                    }
                  : function (h) {
                      return h.toLowerCase()
                    }),
                (o =
                  d === 'next'
                    ? function (h) {
                        return h.toLowerCase()
                      }
                    : function (h) {
                        return h.toUpperCase()
                      }),
                (a = d === 'next' ? Fr : Nr)
              var y = t
                .map(function (h) {
                  return { lower: o(h), upper: i(h) }
                })
                .sort(function (h, m) {
                  return a(h.lower, m.lower)
                })
              ;(u = y.map(function (h) {
                return h.upper
              })),
                (c = y.map(function (h) {
                  return h.lower
                })),
                (p = (f = d) === 'next' ? '' : r)
            }
            v('next'),
              (e = new e.Collection(e, function () {
                return we(u[0], c[s - 1] + r)
              })),
              (e._ondirectionchange = function (d) {
                v(d)
              })
            var l = 0
            return (
              e._addAlgorithm(function (d, y, h) {
                var m = d.key
                if (typeof m != 'string') return !1
                var g = o(m)
                if (n(g, c, l)) return !0
                for (var b = null, w = l; w < s; ++w) {
                  var _ = (function (P, x, k, K, O, S) {
                    for (
                      var q = Math.min(P.length, K.length), T = -1, I = 0;
                      I < q;
                      ++I
                    ) {
                      var te = x[I]
                      if (te !== K[I])
                        return O(P[I], k[I]) < 0
                          ? P.substr(0, I) + k[I] + k.substr(I + 1)
                          : O(P[I], K[I]) < 0
                          ? P.substr(0, I) + K[I] + k.substr(I + 1)
                          : 0 <= T
                          ? P.substr(0, T) + x[T] + k.substr(T + 1)
                          : null
                      O(P[I], te) < 0 && (T = I)
                    }
                    return q < K.length && S === 'next'
                      ? P + k.substr(P.length)
                      : q < P.length && S === 'prev'
                      ? P.substr(0, k.length)
                      : T < 0
                      ? null
                      : P.substr(0, T) + K[T] + k.substr(T + 1)
                  })(m, g, u[w], c[w], a, f)
                  _ === null && b === null
                    ? (l = w + 1)
                    : (b === null || 0 < a(b, _)) && (b = _)
                }
                return (
                  y(
                    b !== null
                      ? function () {
                          d.continue(b + p)
                        }
                      : h
                  ),
                  !1
                )
              }),
              e
            )
          }
          function we (e, n, t, r) {
            return { type: 2, lower: e, upper: n, lowerOpen: t, upperOpen: r }
          }
          function Zt (e) {
            return { type: 1, lower: e, upper: e }
          }
          var er =
            (Object.defineProperty(Y.prototype, 'Collection', {
              get: function () {
                return this._ctx.table.db.Collection
              },
              enumerable: !1,
              configurable: !0
            }),
            (Y.prototype.between = function (e, n, t, r) {
              ;(t = t !== !1), (r = r === !0)
              try {
                return 0 < this._cmp(e, n) ||
                  (this._cmp(e, n) === 0 && (t || r) && (!t || !r))
                  ? Ye(this)
                  : new this.Collection(this, function () {
                      return we(e, n, !t, !r)
                    })
              } catch {
                return ne(this, le)
              }
            }),
            (Y.prototype.equals = function (e) {
              return e == null
                ? ne(this, le)
                : new this.Collection(this, function () {
                    return Zt(e)
                  })
            }),
            (Y.prototype.above = function (e) {
              return e == null
                ? ne(this, le)
                : new this.Collection(this, function () {
                    return we(e, void 0, !0)
                  })
            }),
            (Y.prototype.aboveOrEqual = function (e) {
              return e == null
                ? ne(this, le)
                : new this.Collection(this, function () {
                    return we(e, void 0, !1)
                  })
            }),
            (Y.prototype.below = function (e) {
              return e == null
                ? ne(this, le)
                : new this.Collection(this, function () {
                    return we(void 0, e, !1, !0)
                  })
            }),
            (Y.prototype.belowOrEqual = function (e) {
              return e == null
                ? ne(this, le)
                : new this.Collection(this, function () {
                    return we(void 0, e)
                  })
            }),
            (Y.prototype.startsWith = function (e) {
              return typeof e != 'string'
                ? ne(this, Vt)
                : this.between(e, e + Ae, !0, !0)
            }),
            (Y.prototype.startsWithIgnoreCase = function (e) {
              return e === ''
                ? this.startsWith(e)
                : En(
                    this,
                    function (n, t) {
                      return n.indexOf(t[0]) === 0
                    },
                    [e],
                    Ae
                  )
            }),
            (Y.prototype.equalsIgnoreCase = function (e) {
              return En(
                this,
                function (n, t) {
                  return n === t[0]
                },
                [e],
                ''
              )
            }),
            (Y.prototype.anyOfIgnoreCase = function () {
              var e = ce.apply(Me, arguments)
              return e.length === 0
                ? Ye(this)
                : En(
                    this,
                    function (n, t) {
                      return t.indexOf(n) !== -1
                    },
                    e,
                    ''
                  )
            }),
            (Y.prototype.startsWithAnyOfIgnoreCase = function () {
              var e = ce.apply(Me, arguments)
              return e.length === 0
                ? Ye(this)
                : En(
                    this,
                    function (n, t) {
                      return t.some(function (r) {
                        return n.indexOf(r) === 0
                      })
                    },
                    e,
                    Ae
                  )
            }),
            (Y.prototype.anyOf = function () {
              var e = this,
                n = ce.apply(Me, arguments),
                t = this._cmp
              try {
                n.sort(t)
              } catch {
                return ne(this, le)
              }
              if (n.length === 0) return Ye(this)
              var r = new this.Collection(this, function () {
                return we(n[0], n[n.length - 1])
              })
              r._ondirectionchange = function (o) {
                ;(t = o === 'next' ? e._ascending : e._descending), n.sort(t)
              }
              var i = 0
              return (
                r._addAlgorithm(function (o, a, u) {
                  for (var c = o.key; 0 < t(c, n[i]); )
                    if (++i === n.length) return a(u), !1
                  return (
                    t(c, n[i]) === 0 ||
                    (a(function () {
                      o.continue(n[i])
                    }),
                    !1)
                  )
                }),
                r
              )
            }),
            (Y.prototype.notEqual = function (e) {
              return this.inAnyRange(
                [
                  [-1 / 0, e],
                  [e, this.db._maxKey]
                ],
                { includeLowers: !1, includeUppers: !1 }
              )
            }),
            (Y.prototype.noneOf = function () {
              var e = ce.apply(Me, arguments)
              if (e.length === 0) return new this.Collection(this)
              try {
                e.sort(this._ascending)
              } catch {
                return ne(this, le)
              }
              var n = e.reduce(function (t, r) {
                return t ? t.concat([[t[t.length - 1][1], r]]) : [[-1 / 0, r]]
              }, null)
              return (
                n.push([e[e.length - 1], this.db._maxKey]),
                this.inAnyRange(n, { includeLowers: !1, includeUppers: !1 })
              )
            }),
            (Y.prototype.inAnyRange = function (m, n) {
              var t = this,
                r = this._cmp,
                i = this._ascending,
                o = this._descending,
                a = this._min,
                u = this._max
              if (m.length === 0) return Ye(this)
              if (
                !m.every(function (g) {
                  return (
                    g[0] !== void 0 && g[1] !== void 0 && i(g[0], g[1]) <= 0
                  )
                })
              )
                return ne(
                  this,
                  'First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower',
                  A.InvalidArgument
                )
              var c = !n || n.includeLowers !== !1,
                f = n && n.includeUppers === !0,
                p,
                s = i
              function v (g, b) {
                return s(g[0], b[0])
              }
              try {
                ;(p = m.reduce(function (g, b) {
                  for (var w = 0, _ = g.length; w < _; ++w) {
                    var P = g[w]
                    if (r(b[0], P[1]) < 0 && 0 < r(b[1], P[0])) {
                      ;(P[0] = a(P[0], b[0])), (P[1] = u(P[1], b[1]))
                      break
                    }
                  }
                  return w === _ && g.push(b), g
                }, [])).sort(v)
              } catch {
                return ne(this, le)
              }
              var l = 0,
                d = f
                  ? function (g) {
                      return 0 < i(g, p[l][1])
                    }
                  : function (g) {
                      return 0 <= i(g, p[l][1])
                    },
                y = c
                  ? function (g) {
                      return 0 < o(g, p[l][0])
                    }
                  : function (g) {
                      return 0 <= o(g, p[l][0])
                    },
                h = d,
                m = new this.Collection(this, function () {
                  return we(p[0][0], p[p.length - 1][1], !c, !f)
                })
              return (
                (m._ondirectionchange = function (g) {
                  ;(s = g === 'next' ? ((h = d), i) : ((h = y), o)), p.sort(v)
                }),
                m._addAlgorithm(function (g, b, w) {
                  for (var _, P = g.key; h(P); )
                    if (++l === p.length) return b(w), !1
                  return (
                    (!d((_ = P)) && !y(_)) ||
                    (t._cmp(P, p[l][1]) === 0 ||
                      t._cmp(P, p[l][0]) === 0 ||
                      b(function () {
                        s === i ? g.continue(p[l][0]) : g.continue(p[l][1])
                      }),
                    !1)
                  )
                }),
                m
              )
            }),
            (Y.prototype.startsWithAnyOf = function () {
              var e = ce.apply(Me, arguments)
              return e.every(function (n) {
                return typeof n == 'string'
              })
                ? e.length === 0
                  ? Ye(this)
                  : this.inAnyRange(
                      e.map(function (n) {
                        return [n, n + Ae]
                      })
                    )
                : ne(this, 'startsWithAnyOf() only works with strings')
            }),
            Y)
          function Y () {}
          function oe (e) {
            return N(function (n) {
              return on(n), e(n.target.error), !1
            })
          }
          function on (e) {
            e.stopPropagation && e.stopPropagation(),
              e.preventDefault && e.preventDefault()
          }
          var an = 'storagemutated',
            at = 'x-storagemutated-1',
            _e = nn(null, an),
            Lr =
              ((ae.prototype._lock = function () {
                return (
                  Ge(!j.global),
                  ++this._reculock,
                  this._reculock !== 1 || j.global || (j.lockOwnerFor = this),
                  this
                )
              }),
              (ae.prototype._unlock = function () {
                if ((Ge(!j.global), --this._reculock == 0))
                  for (
                    j.global || (j.lockOwnerFor = null);
                    0 < this._blockedFuncs.length && !this._locked();

                  ) {
                    var e = this._blockedFuncs.shift()
                    try {
                      je(e[1], e[0])
                    } catch {}
                  }
                return this
              }),
              (ae.prototype._locked = function () {
                return this._reculock && j.lockOwnerFor !== this
              }),
              (ae.prototype.create = function (e) {
                var n = this
                if (!this.mode) return this
                var t = this.db.idbdb,
                  r = this.db._state.dbOpenError
                if ((Ge(!this.idbtrans), !e && !t))
                  switch (r && r.name) {
                    case 'DatabaseClosedError':
                      throw new A.DatabaseClosed(r)
                    case 'MissingAPIError':
                      throw new A.MissingAPI(r.message, r)
                    default:
                      throw new A.OpenFailed(r)
                  }
                if (!this.active) throw new A.TransactionInactive()
                return (
                  Ge(this._completion._state === null),
                  ((e = this.idbtrans =
                    e ||
                    (this.db.core || t).transaction(
                      this.storeNames,
                      this.mode,
                      { durability: this.chromeTransactionDurability }
                    )).onerror = N(function (i) {
                    on(i), n._reject(e.error)
                  })),
                  (e.onabort = N(function (i) {
                    on(i),
                      n.active && n._reject(new A.Abort(e.error)),
                      (n.active = !1),
                      n.on('abort').fire(i)
                  })),
                  (e.oncomplete = N(function () {
                    ;(n.active = !1),
                      n._resolve(),
                      'mutatedParts' in e &&
                        _e.storagemutated.fire(e.mutatedParts)
                  })),
                  this
                )
              }),
              (ae.prototype._promise = function (e, n, t) {
                var r = this
                if (e === 'readwrite' && this.mode !== 'readwrite')
                  return U(new A.ReadOnly('Transaction is readonly'))
                if (!this.active) return U(new A.TransactionInactive())
                if (this._locked())
                  return new E(function (o, a) {
                    r._blockedFuncs.push([
                      function () {
                        r._promise(e, n, t).then(o, a)
                      },
                      j
                    ])
                  })
                if (t)
                  return me(function () {
                    var o = new E(function (a, u) {
                      r._lock()
                      var c = n(a, u, r)
                      c && c.then && c.then(a, u)
                    })
                    return (
                      o.finally(function () {
                        return r._unlock()
                      }),
                      (o._lib = !0),
                      o
                    )
                  })
                var i = new E(function (o, a) {
                  var u = n(o, a, r)
                  u && u.then && u.then(o, a)
                })
                return (i._lib = !0), i
              }),
              (ae.prototype._root = function () {
                return this.parent ? this.parent._root() : this
              }),
              (ae.prototype.waitFor = function (e) {
                var n,
                  t = this._root(),
                  r = E.resolve(e)
                t._waitingFor
                  ? (t._waitingFor = t._waitingFor.then(function () {
                      return r
                    }))
                  : ((t._waitingFor = r),
                    (t._waitingQueue = []),
                    (n = t.idbtrans.objectStore(t.storeNames[0])),
                    (function o () {
                      for (++t._spinCount; t._waitingQueue.length; )
                        t._waitingQueue.shift()()
                      t._waitingFor && (n.get(-1 / 0).onsuccess = o)
                    })())
                var i = t._waitingFor
                return new E(function (o, a) {
                  r.then(
                    function (u) {
                      return t._waitingQueue.push(N(o.bind(null, u)))
                    },
                    function (u) {
                      return t._waitingQueue.push(N(a.bind(null, u)))
                    }
                  ).finally(function () {
                    t._waitingFor === i && (t._waitingFor = null)
                  })
                })
              }),
              (ae.prototype.abort = function () {
                this.active &&
                  ((this.active = !1),
                  this.idbtrans && this.idbtrans.abort(),
                  this._reject(new A.Abort()))
              }),
              (ae.prototype.table = function (e) {
                var n = this._memoizedTables || (this._memoizedTables = {})
                if (J(n, e)) return n[e]
                var t = this.schema[e]
                if (!t)
                  throw new A.NotFound(
                    'Table ' + e + ' not part of transaction'
                  )
                return (
                  (t = new this.db.Table(e, t, this)),
                  (t.core = this.db.core.table(e)),
                  (n[e] = t)
                )
              }),
              ae)
          function ae () {}
          function ut (e, n, t, r, i, o, a) {
            return {
              name: e,
              keyPath: n,
              unique: t,
              multi: r,
              auto: i,
              compound: o,
              src:
                (t && !a ? '&' : '') + (r ? '*' : '') + (i ? '++' : '') + nr(n)
            }
          }
          function nr (e) {
            return typeof e == 'string'
              ? e
              : e
              ? '[' + [].join.call(e, '+') + ']'
              : ''
          }
          function st (e, n, t) {
            return {
              name: e,
              primKey: n,
              indexes: t,
              mappedClass: null,
              idxByName:
                ((r = function (i) {
                  return [i.name, i]
                }),
                t.reduce(function (i, o, a) {
                  return (a = r(o, a)), a && (i[a[0]] = a[1]), i
                }, {}))
            }
            var r
          }
          var un = function (e) {
            try {
              return (
                e.only([[]]),
                (un = function () {
                  return [[]]
                }),
                [[]]
              )
            } catch {
              return (
                (un = function () {
                  return Ae
                }),
                Ae
              )
            }
          }
          function ct (e) {
            return e == null
              ? function () {}
              : typeof e == 'string'
              ? (n = e).split('.').length === 1
                ? function (t) {
                    return t[n]
                  }
                : function (t) {
                    return se(t, n)
                  }
              : function (t) {
                  return se(t, e)
                }
            var n
          }
          function tr (e) {
            return [].slice.call(e)
          }
          var Ur = 0
          function sn (e) {
            return e == null
              ? ':id'
              : typeof e == 'string'
              ? e
              : '['.concat(e.join('+'), ']')
          }
          function zr (e, n, c) {
            function r (h) {
              if (h.type === 3) return null
              if (h.type === 4)
                throw new Error('Cannot convert never type to IDBKeyRange')
              var l = h.lower,
                d = h.upper,
                y = h.lowerOpen,
                h = h.upperOpen
              return l === void 0
                ? d === void 0
                  ? null
                  : n.upperBound(d, !!h)
                : d === void 0
                ? n.lowerBound(l, !!y)
                : n.bound(l, d, !!y, !!h)
            }
            function i (v) {
              var l,
                d = v.name
              return {
                name: d,
                schema: v,
                mutate: function (y) {
                  var h = y.trans,
                    m = y.type,
                    g = y.keys,
                    b = y.values,
                    w = y.range
                  return new Promise(function (_, P) {
                    _ = N(_)
                    var x = h.objectStore(d),
                      k = x.keyPath == null,
                      K = m === 'put' || m === 'add'
                    if (!K && m !== 'delete' && m !== 'deleteRange')
                      throw new Error('Invalid operation type: ' + m)
                    var O,
                      S = (g || b || { length: 1 }).length
                    if (g && b && g.length !== b.length)
                      throw new Error(
                        'Given keys array must have same length as given values array.'
                      )
                    if (S === 0)
                      return _({
                        numFailures: 0,
                        failures: {},
                        results: [],
                        lastResult: void 0
                      })
                    function q (H) {
                      ++te, on(H)
                    }
                    var T = [],
                      I = [],
                      te = 0
                    if (m === 'deleteRange') {
                      if (w.type === 4)
                        return _({
                          numFailures: te,
                          failures: I,
                          results: [],
                          lastResult: void 0
                        })
                      w.type === 3
                        ? T.push((O = x.clear()))
                        : T.push((O = x.delete(r(w))))
                    } else {
                      var k = K ? (k ? [b, g] : [b, null]) : [g, null],
                        D = k[0],
                        Q = k[1]
                      if (K)
                        for (var X = 0; X < S; ++X)
                          T.push(
                            (O =
                              Q && Q[X] !== void 0
                                ? x[m](D[X], Q[X])
                                : x[m](D[X]))
                          ),
                            (O.onerror = q)
                      else
                        for (X = 0; X < S; ++X)
                          T.push((O = x[m](D[X]))), (O.onerror = q)
                    }
                    function Nn (H) {
                      ;(H = H.target.result),
                        T.forEach(function (Te, Et) {
                          return Te.error != null && (I[Et] = Te.error)
                        }),
                        _({
                          numFailures: te,
                          failures: I,
                          results:
                            m === 'delete'
                              ? g
                              : T.map(function (Te) {
                                  return Te.result
                                }),
                          lastResult: H
                        })
                    }
                    ;(O.onerror = function (H) {
                      q(H), Nn(H)
                    }),
                      (O.onsuccess = Nn)
                  })
                },
                getMany: function (y) {
                  var h = y.trans,
                    m = y.keys
                  return new Promise(function (g, b) {
                    g = N(g)
                    for (
                      var w,
                        _ = h.objectStore(d),
                        P = m.length,
                        x = new Array(P),
                        k = 0,
                        K = 0,
                        O = function (T) {
                          ;(T = T.target),
                            (x[T._pos] = T.result),
                            ++K === k && g(x)
                        },
                        S = oe(b),
                        q = 0;
                      q < P;
                      ++q
                    )
                      m[q] != null &&
                        (((w = _.get(m[q]))._pos = q),
                        (w.onsuccess = O),
                        (w.onerror = S),
                        ++k)
                    k === 0 && g(x)
                  })
                },
                get: function (y) {
                  var h = y.trans,
                    m = y.key
                  return new Promise(function (g, b) {
                    g = N(g)
                    var w = h.objectStore(d).get(m)
                    ;(w.onsuccess = function (_) {
                      return g(_.target.result)
                    }),
                      (w.onerror = oe(b))
                  })
                },
                query:
                  ((l = f),
                  function (y) {
                    return new Promise(function (h, m) {
                      h = N(h)
                      var g,
                        b,
                        w,
                        k = y.trans,
                        _ = y.values,
                        P = y.limit,
                        O = y.query,
                        x = P === 1 / 0 ? void 0 : P,
                        K = O.index,
                        O = O.range,
                        k = k.objectStore(d),
                        K = K.isPrimaryKey ? k : k.index(K.name),
                        O = r(O)
                      if (P === 0) return h({ result: [] })
                      l
                        ? (((x = _
                            ? K.getAll(O, x)
                            : K.getAllKeys(O, x)).onsuccess = function (S) {
                            return h({ result: S.target.result })
                          }),
                          (x.onerror = oe(m)))
                        : ((g = 0),
                          (b =
                            !_ && 'openKeyCursor' in K
                              ? K.openKeyCursor(O)
                              : K.openCursor(O)),
                          (w = []),
                          (b.onsuccess = function (S) {
                            var q = b.result
                            return q
                              ? (w.push(_ ? q.value : q.primaryKey),
                                ++g === P
                                  ? h({ result: w })
                                  : void q.continue())
                              : h({ result: w })
                          }),
                          (b.onerror = oe(m)))
                    })
                  }),
                openCursor: function (y) {
                  var h = y.trans,
                    m = y.values,
                    g = y.query,
                    b = y.reverse,
                    w = y.unique
                  return new Promise(function (_, P) {
                    _ = N(_)
                    var K = g.index,
                      x = g.range,
                      k = h.objectStore(d),
                      k = K.isPrimaryKey ? k : k.index(K.name),
                      K = b
                        ? w
                          ? 'prevunique'
                          : 'prev'
                        : w
                        ? 'nextunique'
                        : 'next',
                      O =
                        !m && 'openKeyCursor' in k
                          ? k.openKeyCursor(r(x), K)
                          : k.openCursor(r(x), K)
                    ;(O.onerror = oe(P)),
                      (O.onsuccess = N(function (S) {
                        var q,
                          T,
                          I,
                          te,
                          D = O.result
                        D
                          ? ((D.___id = ++Ur),
                            (D.done = !1),
                            (q = D.continue.bind(D)),
                            (T = (T = D.continuePrimaryKey) && T.bind(D)),
                            (I = D.advance.bind(D)),
                            (te = function () {
                              throw new Error('Cursor not stopped')
                            }),
                            (D.trans = h),
                            (D.stop =
                              D.continue =
                              D.continuePrimaryKey =
                              D.advance =
                                function () {
                                  throw new Error('Cursor not started')
                                }),
                            (D.fail = N(P)),
                            (D.next = function () {
                              var Q = this,
                                X = 1
                              return this.start(function () {
                                return X-- ? Q.continue() : Q.stop()
                              }).then(function () {
                                return Q
                              })
                            }),
                            (D.start = function (Q) {
                              function X () {
                                if (O.result)
                                  try {
                                    Q()
                                  } catch (H) {
                                    D.fail(H)
                                  }
                                else
                                  (D.done = !0),
                                    (D.start = function () {
                                      throw new Error(
                                        'Cursor behind last entry'
                                      )
                                    }),
                                    D.stop()
                              }
                              var Nn = new Promise(function (H, Te) {
                                ;(H = N(H)),
                                  (O.onerror = oe(Te)),
                                  (D.fail = Te),
                                  (D.stop = function (Et) {
                                    ;(D.stop =
                                      D.continue =
                                      D.continuePrimaryKey =
                                      D.advance =
                                        te),
                                      H(Et)
                                  })
                              })
                              return (
                                (O.onsuccess = N(function (H) {
                                  ;(O.onsuccess = X), X()
                                })),
                                (D.continue = q),
                                (D.continuePrimaryKey = T),
                                (D.advance = I),
                                X(),
                                Nn
                              )
                            }),
                            _(D))
                          : _(null)
                      }, P))
                  })
                },
                count: function (y) {
                  var h = y.query,
                    m = y.trans,
                    g = h.index,
                    b = h.range
                  return new Promise(function (w, _) {
                    var P = m.objectStore(d),
                      x = g.isPrimaryKey ? P : P.index(g.name),
                      P = r(b),
                      x = P ? x.count(P) : x.count()
                    ;(x.onsuccess = N(function (k) {
                      return w(k.target.result)
                    })),
                      (x.onerror = oe(_))
                  })
                }
              }
            }
            var o,
              a,
              u,
              p =
                ((a = c),
                (u = tr((o = e).objectStoreNames)),
                {
                  schema: {
                    name: o.name,
                    tables: u
                      .map(function (v) {
                        return a.objectStore(v)
                      })
                      .map(function (v) {
                        var l = v.keyPath,
                          h = v.autoIncrement,
                          d = L(l),
                          y = {},
                          h = {
                            name: v.name,
                            primaryKey: {
                              name: null,
                              isPrimaryKey: !0,
                              outbound: l == null,
                              compound: d,
                              keyPath: l,
                              autoIncrement: h,
                              unique: !0,
                              extractKey: ct(l)
                            },
                            indexes: tr(v.indexNames)
                              .map(function (m) {
                                return v.index(m)
                              })
                              .map(function (w) {
                                var g = w.name,
                                  b = w.unique,
                                  _ = w.multiEntry,
                                  w = w.keyPath,
                                  _ = {
                                    name: g,
                                    compound: L(w),
                                    keyPath: w,
                                    unique: b,
                                    multiEntry: _,
                                    extractKey: ct(w)
                                  }
                                return (y[sn(w)] = _)
                              }),
                            getIndexByKeyPath: function (m) {
                              return y[sn(m)]
                            }
                          }
                        return (
                          (y[':id'] = h.primaryKey),
                          l != null && (y[sn(l)] = h.primaryKey),
                          h
                        )
                      })
                  },
                  hasGetAll:
                    0 < u.length &&
                    'getAll' in a.objectStore(u[0]) &&
                    !(
                      typeof navigator < 'u' &&
                      /Safari/.test(navigator.userAgent) &&
                      !/(Chrome\/|Edge\/)/.test(navigator.userAgent) &&
                      [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] <
                        604
                    )
                }),
              c = p.schema,
              f = p.hasGetAll,
              p = c.tables.map(i),
              s = {}
            return (
              p.forEach(function (v) {
                return (s[v.name] = v)
              }),
              {
                stack: 'dbcore',
                transaction: e.transaction.bind(e),
                table: function (v) {
                  if (!s[v]) throw new Error("Table '".concat(v, "' not found"))
                  return s[v]
                },
                MIN_KEY: -1 / 0,
                MAX_KEY: un(n),
                schema: c
              }
            )
          }
          function Vr (e, n, t, r) {
            var i = t.IDBKeyRange
            return (
              t.indexedDB,
              {
                dbcore:
                  ((r = zr(n, i, r)),
                  e.dbcore.reduce(function (o, a) {
                    return (a = a.create), C(C({}, o), a(o))
                  }, r))
              }
            )
          }
          function Sn (e, r) {
            var t = r.db,
              r = Vr(e._middlewares, t, e._deps, r)
            ;(e.core = r.dbcore),
              e.tables.forEach(function (i) {
                var o = i.name
                e.core.schema.tables.some(function (a) {
                  return a.name === o
                }) &&
                  ((i.core = e.core.table(o)),
                  e[o] instanceof e.Table && (e[o].core = i.core))
              })
          }
          function jn (e, n, t, r) {
            t.forEach(function (i) {
              var o = r[i]
              n.forEach(function (a) {
                var u = (function c (f, p) {
                  return _r(f, p) || ((f = Ie(f)) && c(f, p))
                })(a, i)
                ;(!u || ('value' in u && u.value === void 0)) &&
                  (a === e.Transaction.prototype || a instanceof e.Transaction
                    ? ye(a, i, {
                        get: function () {
                          return this.table(i)
                        },
                        set: function (c) {
                          At(this, i, {
                            value: c,
                            writable: !0,
                            configurable: !0,
                            enumerable: !0
                          })
                        }
                      })
                    : (a[i] = new e.Table(i, o)))
              })
            })
          }
          function lt (e, n) {
            n.forEach(function (t) {
              for (var r in t) t[r] instanceof e.Table && delete t[r]
            })
          }
          function Wr (e, n) {
            return e._cfg.version - n._cfg.version
          }
          function Yr (e, n, t, r) {
            var i = e._dbSchema
            t.objectStoreNames.contains('$meta') &&
              !i.$meta &&
              ((i.$meta = st('$meta', ir('')[0], [])),
              e._storeNames.push('$meta'))
            var o = e._createTransaction('readwrite', e._storeNames, i)
            o.create(t), o._completion.catch(r)
            var a = o._reject.bind(o),
              u = j.transless || j
            me(function () {
              return (
                (j.trans = o),
                (j.transless = u),
                n !== 0
                  ? (Sn(e, t),
                    (f = n),
                    ((c = o).storeNames.includes('$meta')
                      ? c
                          .table('$meta')
                          .get('version')
                          .then(function (p) {
                            return p ?? f
                          })
                      : E.resolve(f)
                    )
                      .then(function (p) {
                        return (
                          (v = p),
                          (l = o),
                          (d = t),
                          (y = []),
                          (p = (s = e)._versions),
                          (h = s._dbSchema = Cn(0, s.idbdb, d)),
                          (p = p.filter(function (m) {
                            return m._cfg.version >= v
                          })).length !== 0
                            ? (p.forEach(function (m) {
                                y.push(function () {
                                  var g = h,
                                    b = m._cfg.dbschema
                                  Dn(s, g, d),
                                    Dn(s, b, d),
                                    (h = s._dbSchema = b)
                                  var w = ft(g, b)
                                  w.add.forEach(function (K) {
                                    ht(d, K[0], K[1].primKey, K[1].indexes)
                                  }),
                                    w.change.forEach(function (K) {
                                      if (K.recreate)
                                        throw new A.Upgrade(
                                          'Not yet support for changing primary key'
                                        )
                                      var O = d.objectStore(K.name)
                                      K.add.forEach(function (S) {
                                        return An(O, S)
                                      }),
                                        K.change.forEach(function (S) {
                                          O.deleteIndex(S.name), An(O, S)
                                        }),
                                        K.del.forEach(function (S) {
                                          return O.deleteIndex(S)
                                        })
                                    })
                                  var _ = m._cfg.contentUpgrade
                                  if (_ && m._cfg.version > v) {
                                    Sn(s, d), (l._memoizedTables = {})
                                    var P = qt(b)
                                    w.del.forEach(function (K) {
                                      P[K] = g[K]
                                    }),
                                      lt(s, [s.Transaction.prototype]),
                                      jn(s, [s.Transaction.prototype], V(P), P),
                                      (l.schema = P)
                                    var x,
                                      k = Vn(_)
                                    return (
                                      k && ze(),
                                      (w = E.follow(function () {
                                        var K
                                        ;(x = _(l)) &&
                                          k &&
                                          ((K = ge.bind(null, null)),
                                          x.then(K, K))
                                      })),
                                      x && typeof x.then == 'function'
                                        ? E.resolve(x)
                                        : w.then(function () {
                                            return x
                                          })
                                    )
                                  }
                                }),
                                  y.push(function (g) {
                                    var b,
                                      w,
                                      _ = m._cfg.dbschema
                                    ;(b = _),
                                      (w = g),
                                      [].slice
                                        .call(w.db.objectStoreNames)
                                        .forEach(function (P) {
                                          return (
                                            b[P] == null &&
                                            w.db.deleteObjectStore(P)
                                          )
                                        }),
                                      lt(s, [s.Transaction.prototype]),
                                      jn(
                                        s,
                                        [s.Transaction.prototype],
                                        s._storeNames,
                                        s._dbSchema
                                      ),
                                      (l.schema = s._dbSchema)
                                  }),
                                  y.push(function (g) {
                                    s.idbdb.objectStoreNames.contains(
                                      '$meta'
                                    ) &&
                                      (Math.ceil(s.idbdb.version / 10) ===
                                      m._cfg.version
                                        ? (s.idbdb.deleteObjectStore('$meta'),
                                          delete s._dbSchema.$meta,
                                          (s._storeNames = s._storeNames.filter(
                                            function (b) {
                                              return b !== '$meta'
                                            }
                                          )))
                                        : g
                                            .objectStore('$meta')
                                            .put(m._cfg.version, 'version'))
                                  })
                              }),
                              (function m () {
                                return y.length
                                  ? E.resolve(y.shift()(l.idbtrans)).then(m)
                                  : E.resolve()
                              })().then(function () {
                                rr(h, d)
                              }))
                            : E.resolve()
                        )
                        var s, v, l, d, y, h
                      })
                      .catch(a))
                  : (V(i).forEach(function (p) {
                      ht(t, p, i[p].primKey, i[p].indexes)
                    }),
                    Sn(e, t),
                    void E.follow(function () {
                      return e.on.populate.fire(o)
                    }).catch(a))
              )
              var c, f
            })
          }
          function $r (e, n) {
            rr(e._dbSchema, n),
              n.db.version % 10 != 0 ||
                n.objectStoreNames.contains('$meta') ||
                n.db
                  .createObjectStore('$meta')
                  .add(Math.ceil(n.db.version / 10 - 1), 'version')
            var t = Cn(0, e.idbdb, n)
            Dn(e, e._dbSchema, n)
            for (var r = 0, i = ft(t, e._dbSchema).change; r < i.length; r++) {
              var o = (function (a) {
                if (a.change.length || a.recreate)
                  return (
                    console.warn(
                      'Unable to patch indexes of table '.concat(
                        a.name,
                        ' because it has changes on the type of index or primary key.'
                      )
                    ),
                    { value: void 0 }
                  )
                var u = n.objectStore(a.name)
                a.add.forEach(function (c) {
                  ie &&
                    console.debug(
                      'Dexie upgrade patch: Creating missing index '
                        .concat(a.name, '.')
                        .concat(c.src)
                    ),
                    An(u, c)
                })
              })(i[r])
              if (typeof o == 'object') return o.value
            }
          }
          function ft (e, n) {
            var t,
              r = { del: [], add: [], change: [] }
            for (t in e) n[t] || r.del.push(t)
            for (t in n) {
              var i = e[t],
                o = n[t]
              if (i) {
                var a = {
                  name: t,
                  def: o,
                  recreate: !1,
                  del: [],
                  add: [],
                  change: []
                }
                if (
                  '' + (i.primKey.keyPath || '') !=
                    '' + (o.primKey.keyPath || '') ||
                  i.primKey.auto !== o.primKey.auto
                )
                  (a.recreate = !0), r.change.push(a)
                else {
                  var u = i.idxByName,
                    c = o.idxByName,
                    f = void 0
                  for (f in u) c[f] || a.del.push(f)
                  for (f in c) {
                    var p = u[f],
                      s = c[f]
                    p ? p.src !== s.src && a.change.push(s) : a.add.push(s)
                  }
                  ;(0 < a.del.length ||
                    0 < a.add.length ||
                    0 < a.change.length) &&
                    r.change.push(a)
                }
              } else r.add.push([t, o])
            }
            return r
          }
          function ht (e, n, t, r) {
            var i = e.db.createObjectStore(
              n,
              t.keyPath
                ? { keyPath: t.keyPath, autoIncrement: t.auto }
                : { autoIncrement: t.auto }
            )
            return (
              r.forEach(function (o) {
                return An(i, o)
              }),
              i
            )
          }
          function rr (e, n) {
            V(e).forEach(function (t) {
              n.db.objectStoreNames.contains(t) ||
                (ie && console.debug('Dexie: Creating missing table', t),
                ht(n, t, e[t].primKey, e[t].indexes))
            })
          }
          function An (e, n) {
            e.createIndex(n.name, n.keyPath, {
              unique: n.unique,
              multiEntry: n.multi
            })
          }
          function Cn (e, n, t) {
            var r = {}
            return (
              hn(n.objectStoreNames, 0).forEach(function (i) {
                for (
                  var o = t.objectStore(i),
                    a = ut(
                      nr((f = o.keyPath)),
                      f || '',
                      !0,
                      !1,
                      !!o.autoIncrement,
                      f && typeof f != 'string',
                      !0
                    ),
                    u = [],
                    c = 0;
                  c < o.indexNames.length;
                  ++c
                ) {
                  var p = o.index(o.indexNames[c]),
                    f = p.keyPath,
                    p = ut(
                      p.name,
                      f,
                      !!p.unique,
                      !!p.multiEntry,
                      !1,
                      f && typeof f != 'string',
                      !1
                    )
                  u.push(p)
                }
                r[i] = st(i, a, u)
              }),
              r
            )
          }
          function Dn (e, n, t) {
            for (var r = t.db.objectStoreNames, i = 0; i < r.length; ++i) {
              var o = r[i],
                a = t.objectStore(o)
              e._hasGetAll = 'getAll' in a
              for (var u = 0; u < a.indexNames.length; ++u) {
                var c = a.indexNames[u],
                  f = a.index(c).keyPath,
                  p = typeof f == 'string' ? f : '[' + hn(f).join('+') + ']'
                !n[o] ||
                  ((f = n[o].idxByName[p]) &&
                    ((f.name = c),
                    delete n[o].idxByName[p],
                    (n[o].idxByName[c] = f)))
              }
            }
            typeof navigator < 'u' &&
              /Safari/.test(navigator.userAgent) &&
              !/(Chrome\/|Edge\/)/.test(navigator.userAgent) &&
              $.WorkerGlobalScope &&
              $ instanceof $.WorkerGlobalScope &&
              [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 &&
              (e._hasGetAll = !1)
          }
          function ir (e) {
            return e.split(',').map(function (n, t) {
              var r = (n = n.trim()).replace(/([&*]|\+\+)/g, ''),
                i = /^\[/.test(r) ? r.match(/^\[(.*)\]$/)[1].split('+') : r
              return ut(
                r,
                i || null,
                /\&/.test(n),
                /\*/.test(n),
                /\+\+/.test(n),
                L(i),
                t === 0
              )
            })
          }
          var Gr =
            ((qn.prototype._parseStoresSpec = function (e, n) {
              V(e).forEach(function (t) {
                if (e[t] !== null) {
                  var r = ir(e[t]),
                    i = r.shift()
                  if (((i.unique = !0), i.multi))
                    throw new A.Schema('Primary key cannot be multi-valued')
                  r.forEach(function (o) {
                    if (o.auto)
                      throw new A.Schema(
                        'Only primary key can be marked as autoIncrement (++)'
                      )
                    if (!o.keyPath)
                      throw new A.Schema(
                        'Index must have a name and cannot be an empty string'
                      )
                  }),
                    (n[t] = st(t, i, r))
                }
              })
            }),
            (qn.prototype.stores = function (t) {
              var n = this.db
              this._cfg.storesSource = this._cfg.storesSource
                ? Z(this._cfg.storesSource, t)
                : t
              var t = n._versions,
                r = {},
                i = {}
              return (
                t.forEach(function (o) {
                  Z(r, o._cfg.storesSource),
                    (i = o._cfg.dbschema = {}),
                    o._parseStoresSpec(r, i)
                }),
                (n._dbSchema = i),
                lt(n, [n._allTables, n, n.Transaction.prototype]),
                jn(
                  n,
                  [n._allTables, n, n.Transaction.prototype, this._cfg.tables],
                  V(i),
                  i
                ),
                (n._storeNames = V(i)),
                this
              )
            }),
            (qn.prototype.upgrade = function (e) {
              return (
                (this._cfg.contentUpgrade = Yn(
                  this._cfg.contentUpgrade || M,
                  e
                )),
                this
              )
            }),
            qn)
          function qn () {}
          function dt (e, n) {
            var t = e._dbNamesDB
            return (
              t ||
                (t = e._dbNamesDB =
                  new he(kn, { addons: [], indexedDB: e, IDBKeyRange: n }))
                  .version(1)
                  .stores({ dbnames: 'name' }),
              t.table('dbnames')
            )
          }
          function pt (e) {
            return e && typeof e.databases == 'function'
          }
          function yt (e) {
            return me(function () {
              return (j.letThrough = !0), e()
            })
          }
          function vt (e) {
            return !('from' in e)
          }
          var G = function (e, n) {
            if (!this) {
              var t = new G()
              return e && 'd' in e && Z(t, e), t
            }
            Z(
              this,
              arguments.length
                ? { d: 1, from: e, to: 1 < arguments.length ? n : e }
                : { d: 0 }
            )
          }
          function cn (e, n, t) {
            var r = B(n, t)
            if (!isNaN(r)) {
              if (0 < r) throw RangeError()
              if (vt(e)) return Z(e, { from: n, to: t, d: 1 })
              var i = e.l,
                r = e.r
              if (B(t, e.from) < 0)
                return (
                  i
                    ? cn(i, n, t)
                    : (e.l = { from: n, to: t, d: 1, l: null, r: null }),
                  ar(e)
                )
              if (0 < B(n, e.to))
                return (
                  r
                    ? cn(r, n, t)
                    : (e.r = { from: n, to: t, d: 1, l: null, r: null }),
                  ar(e)
                )
              B(n, e.from) < 0 &&
                ((e.from = n), (e.l = null), (e.d = r ? r.d + 1 : 1)),
                0 < B(t, e.to) &&
                  ((e.to = t), (e.r = null), (e.d = e.l ? e.l.d + 1 : 1)),
                (t = !e.r),
                i && !e.l && ln(e, i),
                r && t && ln(e, r)
            }
          }
          function ln (e, n) {
            vt(n) ||
              (function t (r, c) {
                var o = c.from,
                  a = c.to,
                  u = c.l,
                  c = c.r
                cn(r, o, a), u && t(r, u), c && t(r, c)
              })(e, n)
          }
          function or (e, n) {
            var t = Tn(n),
              r = t.next()
            if (r.done) return !1
            for (
              var i = r.value, o = Tn(e), a = o.next(i.from), u = a.value;
              !r.done && !a.done;

            ) {
              if (B(u.from, i.to) <= 0 && 0 <= B(u.to, i.from)) return !0
              B(i.from, u.from) < 0
                ? (i = (r = t.next(u.from)).value)
                : (u = (a = o.next(i.from)).value)
            }
            return !1
          }
          function Tn (e) {
            var n = vt(e) ? null : { s: 0, n: e }
            return {
              next: function (t) {
                for (var r = 0 < arguments.length; n; )
                  switch (n.s) {
                    case 0:
                      if (((n.s = 1), r))
                        for (; n.n.l && B(t, n.n.from) < 0; )
                          n = { up: n, n: n.n.l, s: 1 }
                      else for (; n.n.l; ) n = { up: n, n: n.n.l, s: 1 }
                    case 1:
                      if (((n.s = 2), !r || B(t, n.n.to) <= 0))
                        return { value: n.n, done: !1 }
                    case 2:
                      if (n.n.r) {
                        ;(n.s = 3), (n = { up: n, n: n.n.r, s: 0 })
                        continue
                      }
                    case 3:
                      n = n.up
                  }
                return { done: !0 }
              }
            }
          }
          function ar (e) {
            var n,
              t,
              r =
                (((n = e.r) === null || n === void 0 ? void 0 : n.d) || 0) -
                (((t = e.l) === null || t === void 0 ? void 0 : t.d) || 0),
              i = 1 < r ? 'r' : r < -1 ? 'l' : ''
            i &&
              ((n = i == 'r' ? 'l' : 'r'),
              (t = C({}, e)),
              (r = e[i]),
              (e.from = r.from),
              (e.to = r.to),
              (e[i] = r[i]),
              (t[i] = r[n]),
              ((e[n] = t).d = ur(t))),
              (e.d = ur(e))
          }
          function ur (t) {
            var n = t.r,
              t = t.l
            return (n ? (t ? Math.max(n.d, t.d) : n.d) : t ? t.d : 0) + 1
          }
          function In (e, n) {
            return (
              V(n).forEach(function (t) {
                e[t]
                  ? ln(e[t], n[t])
                  : (e[t] = (function r (i) {
                      var o,
                        a,
                        u = {}
                      for (o in i)
                        J(i, o) &&
                          ((a = i[o]),
                          (u[o] =
                            !a || typeof a != 'object' || It.has(a.constructor)
                              ? a
                              : r(a)))
                      return u
                    })(n[t]))
              }),
              e
            )
          }
          function mt (e, n) {
            return (
              e.all ||
              n.all ||
              Object.keys(e).some(function (t) {
                return n[t] && or(n[t], e[t])
              })
            )
          }
          Be(
            G.prototype,
            (((re = {
              add: function (e) {
                return ln(this, e), this
              },
              addKey: function (e) {
                return cn(this, e, e), this
              },
              addKeys: function (e) {
                var n = this
                return (
                  e.forEach(function (t) {
                    return cn(n, t, t)
                  }),
                  this
                )
              },
              hasKey: function (e) {
                var n = Tn(this).next(e).value
                return n && B(n.from, e) <= 0 && 0 <= B(n.to, e)
              }
            })[zn] = function () {
              return Tn(this)
            }),
            re)
          )
          var De = {},
            gt = {},
            bt = !1
          function Bn (e) {
            In(gt, e),
              bt ||
                ((bt = !0),
                setTimeout(function () {
                  ;(bt = !1), wt(gt, !(gt = {}))
                }, 0))
          }
          function wt (e, n) {
            n === void 0 && (n = !1)
            var t = new Set()
            if (e.all)
              for (var r = 0, i = Object.values(De); r < i.length; r++)
                sr((a = i[r]), e, t, n)
            else
              for (var o in e) {
                var a,
                  u = /^idb\:\/\/(.*)\/(.*)\//.exec(o)
                u &&
                  ((o = u[1]),
                  (u = u[2]),
                  (a = De['idb://'.concat(o, '/').concat(u)]) && sr(a, e, t, n))
              }
            t.forEach(function (c) {
              return c()
            })
          }
          function sr (e, n, t, r) {
            for (
              var i = [], o = 0, a = Object.entries(e.queries.query);
              o < a.length;
              o++
            ) {
              for (
                var u = a[o], c = u[0], f = [], p = 0, s = u[1];
                p < s.length;
                p++
              ) {
                var v = s[p]
                mt(n, v.obsSet)
                  ? v.subscribers.forEach(function (h) {
                      return t.add(h)
                    })
                  : r && f.push(v)
              }
              r && i.push([c, f])
            }
            if (r)
              for (var l = 0, d = i; l < d.length; l++) {
                var y = d[l],
                  c = y[0],
                  f = y[1]
                e.queries.query[c] = f
              }
          }
          function Qr (e) {
            var n = e._state,
              t = e._deps.indexedDB
            if (n.isBeingOpened || e.idbdb)
              return n.dbReadyPromise.then(function () {
                return n.dbOpenError ? U(n.dbOpenError) : e
              })
            ;(n.isBeingOpened = !0),
              (n.dbOpenError = null),
              (n.openComplete = !1)
            var r = n.openCanceller,
              i = Math.round(10 * e.verno),
              o = !1
            function a () {
              if (n.openCanceller !== r)
                throw new A.DatabaseClosed('db.open() was cancelled')
            }
            function u () {
              return new E(function (v, l) {
                if ((a(), !t)) throw new A.MissingAPI()
                var d = e.name,
                  y = n.autoSchema || !i ? t.open(d) : t.open(d, i)
                if (!y) throw new A.MissingAPI()
                ;(y.onerror = oe(l)),
                  (y.onblocked = N(e._fireOnBlocked)),
                  (y.onupgradeneeded = N(function (h) {
                    var m
                    ;(p = y.transaction),
                      n.autoSchema && !e._options.allowEmptyDB
                        ? ((y.onerror = on),
                          p.abort(),
                          y.result.close(),
                          ((m = t.deleteDatabase(d)).onsuccess = m.onerror =
                            N(function () {
                              l(
                                new A.NoSuchDatabase(
                                  'Database '.concat(d, ' doesnt exist')
                                )
                              )
                            })))
                        : ((p.onerror = oe(l)),
                          (h =
                            h.oldVersion > Math.pow(2, 62) ? 0 : h.oldVersion),
                          (s = h < 1),
                          (e.idbdb = y.result),
                          o && $r(e, p),
                          Yr(e, h / 10, p, l))
                  }, l)),
                  (y.onsuccess = N(function () {
                    p = null
                    var h,
                      m,
                      g,
                      b,
                      w,
                      _ = (e.idbdb = y.result),
                      P = hn(_.objectStoreNames)
                    if (0 < P.length)
                      try {
                        var x = _.transaction(
                          (b = P).length === 1 ? b[0] : b,
                          'readonly'
                        )
                        if (n.autoSchema)
                          (m = _),
                            (g = x),
                            ((h = e).verno = m.version / 10),
                            (g = h._dbSchema = Cn(0, m, g)),
                            (h._storeNames = hn(m.objectStoreNames, 0)),
                            jn(h, [h._allTables], V(g), g)
                        else if (
                          (Dn(e, e._dbSchema, x),
                          ((w = ft(Cn(0, (w = e).idbdb, x), w._dbSchema)).add
                            .length ||
                            w.change.some(function (k) {
                              return k.add.length || k.change.length
                            })) &&
                            !o)
                        )
                          return (
                            console.warn(
                              'Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this.'
                            ),
                            _.close(),
                            (i = _.version + 1),
                            (o = !0),
                            v(u())
                          )
                        Sn(e, x)
                      } catch {}
                    Ve.push(e),
                      (_.onversionchange = N(function (k) {
                        ;(n.vcFired = !0), e.on('versionchange').fire(k)
                      })),
                      (_.onclose = N(function (k) {
                        e.on('close').fire(k)
                      })),
                      s &&
                        ((w = e._deps),
                        (x = d),
                        (_ = w.indexedDB),
                        (w = w.IDBKeyRange),
                        pt(_) ||
                          x === kn ||
                          dt(_, w).put({ name: x }).catch(M)),
                      v()
                  }, l))
              }).catch(function (v) {
                switch (v == null ? void 0 : v.name) {
                  case 'UnknownError':
                    if (0 < n.PR1398_maxLoop)
                      return (
                        n.PR1398_maxLoop--,
                        console.warn(
                          'Dexie: Workaround for Chrome UnknownError on open()'
                        ),
                        u()
                      )
                    break
                  case 'VersionError':
                    if (0 < i) return (i = 0), u()
                }
                return E.reject(v)
              })
            }
            var c,
              f = n.dbReadyResolve,
              p = null,
              s = !1
            return E.race([
              r,
              (typeof navigator > 'u'
                ? E.resolve()
                : !navigator.userAgentData &&
                  /Safari\//.test(navigator.userAgent) &&
                  !/Chrom(e|ium)\//.test(navigator.userAgent) &&
                  indexedDB.databases
                ? new Promise(function (v) {
                    function l () {
                      return indexedDB.databases().finally(v)
                    }
                    ;(c = setInterval(l, 100)), l()
                  }).finally(function () {
                    return clearInterval(c)
                  })
                : Promise.resolve()
              ).then(u)
            ])
              .then(function () {
                return (
                  a(),
                  (n.onReadyBeingFired = []),
                  E.resolve(
                    yt(function () {
                      return e.on.ready.fire(e.vip)
                    })
                  ).then(function v () {
                    if (0 < n.onReadyBeingFired.length) {
                      var l = n.onReadyBeingFired.reduce(Yn, M)
                      return (
                        (n.onReadyBeingFired = []),
                        E.resolve(
                          yt(function () {
                            return l(e.vip)
                          })
                        ).then(v)
                      )
                    }
                  })
                )
              })
              .finally(function () {
                n.openCanceller === r &&
                  ((n.onReadyBeingFired = null), (n.isBeingOpened = !1))
              })
              .catch(function (v) {
                n.dbOpenError = v
                try {
                  p && p.abort()
                } catch {}
                return r === n.openCanceller && e._close(), U(v)
              })
              .finally(function () {
                ;(n.openComplete = !0), f()
              })
              .then(function () {
                var v
                return (
                  s &&
                    ((v = {}),
                    e.tables.forEach(function (l) {
                      l.schema.indexes.forEach(function (d) {
                        d.name &&
                          (v[
                            'idb://'
                              .concat(e.name, '/')
                              .concat(l.name, '/')
                              .concat(d.name)
                          ] = new G(-1 / 0, [[[]]]))
                      }),
                        (v['idb://'.concat(e.name, '/').concat(l.name, '/')] =
                          v[
                            'idb://'
                              .concat(e.name, '/')
                              .concat(l.name, '/:dels')
                          ] =
                            new G(-1 / 0, [[[]]]))
                    }),
                    _e(an).fire(v),
                    wt(v, !0)),
                  e
                )
              })
          }
          function _t (e) {
            function n (o) {
              return e.next(o)
            }
            var t = i(n),
              r = i(function (o) {
                return e.throw(o)
              })
            function i (o) {
              return function (c) {
                var u = o(c),
                  c = u.value
                return u.done
                  ? c
                  : c && typeof c.then == 'function'
                  ? c.then(t, r)
                  : L(c)
                  ? Promise.all(c).then(t, r)
                  : t(c)
              }
            }
            return i(n)()
          }
          function Rn (e, n, t) {
            for (var r = L(e) ? e.slice() : [e], i = 0; i < t; ++i) r.push(n)
            return r
          }
          var Xr = {
            stack: 'dbcore',
            name: 'VirtualIndexMiddleware',
            level: 1,
            create: function (e) {
              return C(C({}, e), {
                table: function (n) {
                  var t = e.table(n),
                    r = t.schema,
                    i = {},
                    o = []
                  function a (s, v, l) {
                    var d = sn(s),
                      y = (i[d] = i[d] || []),
                      h = s == null ? 0 : typeof s == 'string' ? 1 : s.length,
                      m = 0 < v,
                      m = C(C({}, l), {
                        name: m
                          ? ''.concat(d, '(virtual-from:').concat(l.name, ')')
                          : l.name,
                        lowLevelIndex: l,
                        isVirtual: m,
                        keyTail: v,
                        keyLength: h,
                        extractKey: ct(s),
                        unique: !m && l.unique
                      })
                    return (
                      y.push(m),
                      m.isPrimaryKey || o.push(m),
                      1 < h && a(h === 2 ? s[0] : s.slice(0, h - 1), v + 1, l),
                      y.sort(function (g, b) {
                        return g.keyTail - b.keyTail
                      }),
                      m
                    )
                  }
                  ;(n = a(r.primaryKey.keyPath, 0, r.primaryKey)),
                    (i[':id'] = [n])
                  for (var u = 0, c = r.indexes; u < c.length; u++) {
                    var f = c[u]
                    a(f.keyPath, 0, f)
                  }
                  function p (s) {
                    var v,
                      l = s.query.index
                    return l.isVirtual
                      ? C(C({}, s), {
                          query: {
                            index: l.lowLevelIndex,
                            range:
                              ((v = s.query.range),
                              (l = l.keyTail),
                              {
                                type: v.type === 1 ? 2 : v.type,
                                lower: Rn(
                                  v.lower,
                                  v.lowerOpen ? e.MAX_KEY : e.MIN_KEY,
                                  l
                                ),
                                lowerOpen: !0,
                                upper: Rn(
                                  v.upper,
                                  v.upperOpen ? e.MIN_KEY : e.MAX_KEY,
                                  l
                                ),
                                upperOpen: !0
                              })
                          }
                        })
                      : s
                  }
                  return C(C({}, t), {
                    schema: C(C({}, r), {
                      primaryKey: n,
                      indexes: o,
                      getIndexByKeyPath: function (s) {
                        return (s = i[sn(s)]) && s[0]
                      }
                    }),
                    count: function (s) {
                      return t.count(p(s))
                    },
                    query: function (s) {
                      return t.query(p(s))
                    },
                    openCursor: function (s) {
                      var v = s.query.index,
                        l = v.keyTail,
                        d = v.isVirtual,
                        y = v.keyLength
                      return d
                        ? t.openCursor(p(s)).then(function (m) {
                            return m && h(m)
                          })
                        : t.openCursor(s)
                      function h (m) {
                        return Object.create(m, {
                          continue: {
                            value: function (g) {
                              g != null
                                ? m.continue(
                                    Rn(g, s.reverse ? e.MAX_KEY : e.MIN_KEY, l)
                                  )
                                : s.unique
                                ? m.continue(
                                    m.key
                                      .slice(0, y)
                                      .concat(
                                        s.reverse ? e.MIN_KEY : e.MAX_KEY,
                                        l
                                      )
                                  )
                                : m.continue()
                            }
                          },
                          continuePrimaryKey: {
                            value: function (g, b) {
                              m.continuePrimaryKey(Rn(g, e.MAX_KEY, l), b)
                            }
                          },
                          primaryKey: {
                            get: function () {
                              return m.primaryKey
                            }
                          },
                          key: {
                            get: function () {
                              var g = m.key
                              return y === 1 ? g[0] : g.slice(0, y)
                            }
                          },
                          value: {
                            get: function () {
                              return m.value
                            }
                          }
                        })
                      }
                    }
                  })
                }
              })
            }
          }
          function xt (e, n, t, r) {
            return (
              (t = t || {}),
              (r = r || ''),
              V(e).forEach(function (i) {
                var o, a, u
                J(n, i)
                  ? ((o = e[i]),
                    (a = n[i]),
                    typeof o == 'object' && typeof a == 'object' && o && a
                      ? (u = Un(o)) !== Un(a)
                        ? (t[r + i] = n[i])
                        : u === 'Object'
                        ? xt(o, a, t, r + i + '.')
                        : o !== a && (t[r + i] = n[i])
                      : o !== a && (t[r + i] = n[i]))
                  : (t[r + i] = void 0)
              }),
              V(n).forEach(function (i) {
                J(e, i) || (t[r + i] = n[i])
              }),
              t
            )
          }
          function kt (e, n) {
            return n.type === 'delete'
              ? n.keys
              : n.keys || n.values.map(e.extractKey)
          }
          var Hr = {
            stack: 'dbcore',
            name: 'HooksMiddleware',
            level: 2,
            create: function (e) {
              return C(C({}, e), {
                table: function (n) {
                  var t = e.table(n),
                    r = t.schema.primaryKey
                  return C(C({}, t), {
                    mutate: function (i) {
                      var o = j.trans,
                        a = o.table(n).hook,
                        u = a.deleting,
                        c = a.creating,
                        f = a.updating
                      switch (i.type) {
                        case 'add':
                          if (c.fire === M) break
                          return o._promise(
                            'readwrite',
                            function () {
                              return p(i)
                            },
                            !0
                          )
                        case 'put':
                          if (c.fire === M && f.fire === M) break
                          return o._promise(
                            'readwrite',
                            function () {
                              return p(i)
                            },
                            !0
                          )
                        case 'delete':
                          if (u.fire === M) break
                          return o._promise(
                            'readwrite',
                            function () {
                              return p(i)
                            },
                            !0
                          )
                        case 'deleteRange':
                          if (u.fire === M) break
                          return o._promise(
                            'readwrite',
                            function () {
                              return (function s (v, l, d) {
                                return t
                                  .query({
                                    trans: v,
                                    values: !1,
                                    query: { index: r, range: l },
                                    limit: d
                                  })
                                  .then(function (y) {
                                    var h = y.result
                                    return p({
                                      type: 'delete',
                                      keys: h,
                                      trans: v
                                    }).then(function (m) {
                                      return 0 < m.numFailures
                                        ? Promise.reject(m.failures[0])
                                        : h.length < d
                                        ? {
                                            failures: [],
                                            numFailures: 0,
                                            lastResult: void 0
                                          }
                                        : s(
                                            v,
                                            C(C({}, l), {
                                              lower: h[h.length - 1],
                                              lowerOpen: !0
                                            }),
                                            d
                                          )
                                    })
                                  })
                              })(i.trans, i.range, 1e4)
                            },
                            !0
                          )
                      }
                      return t.mutate(i)
                      function p (s) {
                        var v,
                          l,
                          d,
                          y = j.trans,
                          h = s.keys || kt(r, s)
                        if (!h) throw new Error('Keys missing')
                        return (
                          (s =
                            s.type === 'add' || s.type === 'put'
                              ? C(C({}, s), { keys: h })
                              : C({}, s)).type !== 'delete' &&
                            (s.values = fn([], s.values)),
                          s.keys && (s.keys = fn([], s.keys)),
                          (v = t),
                          (d = h),
                          ((l = s).type === 'add'
                            ? Promise.resolve([])
                            : v.getMany({
                                trans: l.trans,
                                keys: d,
                                cache: 'immutable'
                              })
                          ).then(function (m) {
                            var g = h.map(function (b, w) {
                              var _,
                                P,
                                x,
                                k = m[w],
                                K = { onerror: null, onsuccess: null }
                              return (
                                s.type === 'delete'
                                  ? u.fire.call(K, b, k, y)
                                  : s.type === 'add' || k === void 0
                                  ? ((_ = c.fire.call(K, b, s.values[w], y)),
                                    b == null &&
                                      _ != null &&
                                      ((s.keys[w] = b = _),
                                      r.outbound ||
                                        ee(s.values[w], r.keyPath, b)))
                                  : ((_ = xt(k, s.values[w])),
                                    (P = f.fire.call(K, _, b, k, y)) &&
                                      ((x = s.values[w]),
                                      Object.keys(P).forEach(function (O) {
                                        J(x, O) ? (x[O] = P[O]) : ee(x, O, P[O])
                                      }))),
                                K
                              )
                            })
                            return t
                              .mutate(s)
                              .then(function (b) {
                                for (
                                  var w = b.failures,
                                    _ = b.results,
                                    P = b.numFailures,
                                    b = b.lastResult,
                                    x = 0;
                                  x < h.length;
                                  ++x
                                ) {
                                  var k = (_ || h)[x],
                                    K = g[x]
                                  k == null
                                    ? K.onerror && K.onerror(w[x])
                                    : K.onsuccess &&
                                      K.onsuccess(
                                        s.type === 'put' && m[x]
                                          ? s.values[x]
                                          : k
                                      )
                                }
                                return {
                                  failures: w,
                                  results: _,
                                  numFailures: P,
                                  lastResult: b
                                }
                              })
                              .catch(function (b) {
                                return (
                                  g.forEach(function (w) {
                                    return w.onerror && w.onerror(b)
                                  }),
                                  Promise.reject(b)
                                )
                              })
                          })
                        )
                      }
                    }
                  })
                }
              })
            }
          }
          function cr (e, n, t) {
            try {
              if (!n || n.keys.length < e.length) return null
              for (
                var r = [], i = 0, o = 0;
                i < n.keys.length && o < e.length;
                ++i
              )
                B(n.keys[i], e[o]) === 0 &&
                  (r.push(t ? ke(n.values[i]) : n.values[i]), ++o)
              return r.length === e.length ? r : null
            } catch {
              return null
            }
          }
          var Jr = {
            stack: 'dbcore',
            level: -1,
            create: function (e) {
              return {
                table: function (n) {
                  var t = e.table(n)
                  return C(C({}, t), {
                    getMany: function (r) {
                      if (!r.cache) return t.getMany(r)
                      var i = cr(r.keys, r.trans._cache, r.cache === 'clone')
                      return i
                        ? E.resolve(i)
                        : t.getMany(r).then(function (o) {
                            return (
                              (r.trans._cache = {
                                keys: r.keys,
                                values: r.cache === 'clone' ? ke(o) : o
                              }),
                              o
                            )
                          })
                    },
                    mutate: function (r) {
                      return (
                        r.type !== 'add' && (r.trans._cache = null), t.mutate(r)
                      )
                    }
                  })
                }
              }
            }
          }
          function lr (e, n) {
            return (
              e.trans.mode === 'readonly' &&
              !!e.subscr &&
              !e.trans.explicit &&
              e.trans.db._options.cache !== 'disabled' &&
              !n.schema.primaryKey.outbound
            )
          }
          function fr (e, n) {
            switch (e) {
              case 'query':
                return n.values && !n.unique
              case 'get':
              case 'getMany':
              case 'count':
              case 'openCursor':
                return !1
            }
          }
          var Zr = {
            stack: 'dbcore',
            level: 0,
            name: 'Observability',
            create: function (e) {
              var n = e.schema.name,
                t = new G(e.MIN_KEY, e.MAX_KEY)
              return C(C({}, e), {
                transaction: function (r, i, o) {
                  if (j.subscr && i !== 'readonly')
                    throw new A.ReadOnly(
                      'Readwrite transaction in liveQuery context. Querier source: '.concat(
                        j.querier
                      )
                    )
                  return e.transaction(r, i, o)
                },
                table: function (r) {
                  var i = e.table(r),
                    o = i.schema,
                    a = o.primaryKey,
                    s = o.indexes,
                    u = a.extractKey,
                    c = a.outbound,
                    f =
                      a.autoIncrement &&
                      s.filter(function (l) {
                        return l.compound && l.keyPath.includes(a.keyPath)
                      }),
                    p = C(C({}, i), {
                      mutate: function (l) {
                        function d (O) {
                          return (
                            (O = 'idb://'
                              .concat(n, '/')
                              .concat(r, '/')
                              .concat(O)),
                            b[O] || (b[O] = new G())
                          )
                        }
                        var y,
                          h,
                          m,
                          g = l.trans,
                          b = l.mutatedParts || (l.mutatedParts = {}),
                          w = d(''),
                          _ = d(':dels'),
                          P = l.type,
                          K =
                            l.type === 'deleteRange'
                              ? [l.range]
                              : l.type === 'delete'
                              ? [l.keys]
                              : l.values.length < 50
                              ? [
                                  kt(a, l).filter(function (O) {
                                    return O
                                  }),
                                  l.values
                                ]
                              : [],
                          x = K[0],
                          k = K[1],
                          K = l.trans._cache
                        return (
                          L(x)
                            ? (w.addKeys(x),
                              (K =
                                P === 'delete' || x.length === k.length
                                  ? cr(x, K)
                                  : null) || _.addKeys(x),
                              (K || k) &&
                                ((y = d),
                                (h = K),
                                (m = k),
                                o.indexes.forEach(function (O) {
                                  var S = y(O.name || '')
                                  function q (I) {
                                    return I != null ? O.extractKey(I) : null
                                  }
                                  function T (I) {
                                    return O.multiEntry && L(I)
                                      ? I.forEach(function (te) {
                                          return S.addKey(te)
                                        })
                                      : S.addKey(I)
                                  }
                                  ;(h || m).forEach(function (I, Q) {
                                    var D = h && q(h[Q]),
                                      Q = m && q(m[Q])
                                    B(D, Q) !== 0 &&
                                      (D != null && T(D), Q != null && T(Q))
                                  })
                                })))
                            : x
                            ? ((k = {
                                from:
                                  (k = x.lower) !== null && k !== void 0
                                    ? k
                                    : e.MIN_KEY,
                                to:
                                  (k = x.upper) !== null && k !== void 0
                                    ? k
                                    : e.MAX_KEY
                              }),
                              _.add(k),
                              w.add(k))
                            : (w.add(t),
                              _.add(t),
                              o.indexes.forEach(function (O) {
                                return d(O.name).add(t)
                              })),
                          i.mutate(l).then(function (O) {
                            return (
                              !x ||
                                (l.type !== 'add' && l.type !== 'put') ||
                                (w.addKeys(O.results),
                                f &&
                                  f.forEach(function (S) {
                                    for (
                                      var q = l.values.map(function (D) {
                                          return S.extractKey(D)
                                        }),
                                        T = S.keyPath.findIndex(function (D) {
                                          return D === a.keyPath
                                        }),
                                        I = 0,
                                        te = O.results.length;
                                      I < te;
                                      ++I
                                    )
                                      q[I][T] = O.results[I]
                                    d(S.name).addKeys(q)
                                  })),
                              (g.mutatedParts = In(g.mutatedParts || {}, b)),
                              O
                            )
                          })
                        )
                      }
                    }),
                    s = function (d) {
                      var y = d.query,
                        d = y.index,
                        y = y.range
                      return [
                        d,
                        new G(
                          (d = y.lower) !== null && d !== void 0
                            ? d
                            : e.MIN_KEY,
                          (y = y.upper) !== null && y !== void 0 ? y : e.MAX_KEY
                        )
                      ]
                    },
                    v = {
                      get: function (l) {
                        return [a, new G(l.key)]
                      },
                      getMany: function (l) {
                        return [a, new G().addKeys(l.keys)]
                      },
                      count: s,
                      query: s,
                      openCursor: s
                    }
                  return (
                    V(v).forEach(function (l) {
                      p[l] = function (d) {
                        var y = j.subscr,
                          h = !!y,
                          m = lr(j, i) && fr(l, d) ? (d.obsSet = {}) : y
                        if (h) {
                          var g = function (k) {
                              return (
                                (k = 'idb://'
                                  .concat(n, '/')
                                  .concat(r, '/')
                                  .concat(k)),
                                m[k] || (m[k] = new G())
                              )
                            },
                            b = g(''),
                            w = g(':dels'),
                            y = v[l](d),
                            h = y[0],
                            y = y[1]
                          if (
                            ((l === 'query' && h.isPrimaryKey && !d.values
                              ? w
                              : g(h.name || '')
                            ).add(y),
                            !h.isPrimaryKey)
                          ) {
                            if (l !== 'count') {
                              var _ =
                                l === 'query' &&
                                c &&
                                d.values &&
                                i.query(C(C({}, d), { values: !1 }))
                              return i[l]
                                .apply(this, arguments)
                                .then(function (k) {
                                  if (l === 'query') {
                                    if (c && d.values)
                                      return _.then(function (q) {
                                        return (q = q.result), b.addKeys(q), k
                                      })
                                    var K = d.values
                                      ? k.result.map(u)
                                      : k.result
                                    ;(d.values ? b : w).addKeys(K)
                                  } else if (l === 'openCursor') {
                                    var O = k,
                                      S = d.values
                                    return (
                                      O &&
                                      Object.create(O, {
                                        key: {
                                          get: function () {
                                            return w.addKey(O.primaryKey), O.key
                                          }
                                        },
                                        primaryKey: {
                                          get: function () {
                                            var q = O.primaryKey
                                            return w.addKey(q), q
                                          }
                                        },
                                        value: {
                                          get: function () {
                                            return (
                                              S && b.addKey(O.primaryKey),
                                              O.value
                                            )
                                          }
                                        }
                                      })
                                    )
                                  }
                                  return k
                                })
                            }
                            w.add(t)
                          }
                        }
                        return i[l].apply(this, arguments)
                      }
                    }),
                    p
                  )
                }
              })
            }
          }
          function hr (e, n, t) {
            if (t.numFailures === 0) return n
            if (n.type === 'deleteRange') return null
            var r = n.keys
              ? n.keys.length
              : 'values' in n && n.values
              ? n.values.length
              : 1
            return t.numFailures === r
              ? null
              : ((n = C({}, n)),
                L(n.keys) &&
                  (n.keys = n.keys.filter(function (i, o) {
                    return !(o in t.failures)
                  })),
                'values' in n &&
                  L(n.values) &&
                  (n.values = n.values.filter(function (i, o) {
                    return !(o in t.failures)
                  })),
                n)
          }
          function Ot (e, n) {
            return (
              (t = e),
              ((r = n).lower === void 0 ||
                (r.lowerOpen ? 0 < B(t, r.lower) : 0 <= B(t, r.lower))) &&
                ((e = e),
                (n = n).upper === void 0 ||
                  (n.upperOpen ? B(e, n.upper) < 0 : B(e, n.upper) <= 0))
            )
            var t, r
          }
          function dr (e, n, v, r, i, o) {
            if (!v || v.length === 0) return e
            var a = n.query.index,
              u = a.multiEntry,
              c = n.query.range,
              f = r.schema.primaryKey.extractKey,
              p = a.extractKey,
              s = (a.lowLevelIndex || a).extractKey,
              v = v.reduce(function (l, d) {
                var y = l,
                  h = []
                if (d.type === 'add' || d.type === 'put')
                  for (var m = new G(), g = d.values.length - 1; 0 <= g; --g) {
                    var b,
                      w = d.values[g],
                      _ = f(w)
                    m.hasKey(_) ||
                      ((b = p(w)),
                      (u && L(b)
                        ? b.some(function (O) {
                            return Ot(O, c)
                          })
                        : Ot(b, c)) && (m.addKey(_), h.push(w)))
                  }
                switch (d.type) {
                  case 'add':
                    var P = new G().addKeys(
                        n.values
                          ? l.map(function (S) {
                              return f(S)
                            })
                          : l
                      ),
                      y = l.concat(
                        n.values
                          ? h.filter(function (S) {
                              return (
                                (S = f(S)), !P.hasKey(S) && (P.addKey(S), !0)
                              )
                            })
                          : h
                              .map(function (S) {
                                return f(S)
                              })
                              .filter(function (S) {
                                return !P.hasKey(S) && (P.addKey(S), !0)
                              })
                      )
                    break
                  case 'put':
                    var x = new G().addKeys(
                      d.values.map(function (S) {
                        return f(S)
                      })
                    )
                    y = l
                      .filter(function (S) {
                        return !x.hasKey(n.values ? f(S) : S)
                      })
                      .concat(
                        n.values
                          ? h
                          : h.map(function (S) {
                              return f(S)
                            })
                      )
                    break
                  case 'delete':
                    var k = new G().addKeys(d.keys)
                    y = l.filter(function (S) {
                      return !k.hasKey(n.values ? f(S) : S)
                    })
                    break
                  case 'deleteRange':
                    var K = d.range
                    y = l.filter(function (S) {
                      return !Ot(f(S), K)
                    })
                }
                return y
              }, e)
            return v === e
              ? e
              : (v.sort(function (l, d) {
                  return B(s(l), s(d)) || B(f(l), f(d))
                }),
                n.limit &&
                  n.limit < 1 / 0 &&
                  (v.length > n.limit
                    ? (v.length = n.limit)
                    : e.length === n.limit &&
                      v.length < n.limit &&
                      (i.dirty = !0)),
                o ? Object.freeze(v) : v)
          }
          function pr (e, n) {
            return (
              B(e.lower, n.lower) === 0 &&
              B(e.upper, n.upper) === 0 &&
              !!e.lowerOpen == !!n.lowerOpen &&
              !!e.upperOpen == !!n.upperOpen
            )
          }
          function ei (e, n) {
            return (
              (function (t, r, i, o) {
                if (t === void 0) return r !== void 0 ? -1 : 0
                if (r === void 0) return 1
                if ((r = B(t, r)) === 0) {
                  if (i && o) return 0
                  if (i) return 1
                  if (o) return -1
                }
                return r
              })(e.lower, n.lower, e.lowerOpen, n.lowerOpen) <= 0 &&
              0 <=
                (function (t, r, i, o) {
                  if (t === void 0) return r !== void 0 ? 1 : 0
                  if (r === void 0) return -1
                  if ((r = B(t, r)) === 0) {
                    if (i && o) return 0
                    if (i) return -1
                    if (o) return 1
                  }
                  return r
                })(e.upper, n.upper, e.upperOpen, n.upperOpen)
            )
          }
          function ni (e, n, t, r) {
            e.subscribers.add(t),
              r.addEventListener('abort', function () {
                var i, o
                e.subscribers.delete(t),
                  e.subscribers.size === 0 &&
                    ((i = e),
                    (o = n),
                    setTimeout(function () {
                      i.subscribers.size === 0 && Oe(o, i)
                    }, 3e3))
              })
          }
          var ti = {
            stack: 'dbcore',
            level: 0,
            name: 'Cache',
            create: function (e) {
              var n = e.schema.name
              return C(C({}, e), {
                transaction: function (t, r, i) {
                  var o,
                    a,
                    u = e.transaction(t, r, i)
                  return (
                    r === 'readwrite' &&
                      ((a = (o = new AbortController()).signal),
                      (i = function (c) {
                        return function () {
                          if ((o.abort(), r === 'readwrite')) {
                            for (
                              var f = new Set(), p = 0, s = t;
                              p < s.length;
                              p++
                            ) {
                              var v = s[p],
                                l = De['idb://'.concat(n, '/').concat(v)]
                              if (l) {
                                var d = e.table(v),
                                  y = l.optimisticOps.filter(function (S) {
                                    return S.trans === u
                                  })
                                if (u._explicit && c && u.mutatedParts)
                                  for (
                                    var h = 0,
                                      m = Object.values(l.queries.query);
                                    h < m.length;
                                    h++
                                  )
                                    for (
                                      var g = 0, b = (P = m[h]).slice();
                                      g < b.length;
                                      g++
                                    )
                                      mt((x = b[g]).obsSet, u.mutatedParts) &&
                                        (Oe(P, x),
                                        x.subscribers.forEach(function (S) {
                                          return f.add(S)
                                        }))
                                else if (0 < y.length) {
                                  l.optimisticOps = l.optimisticOps.filter(
                                    function (S) {
                                      return S.trans !== u
                                    }
                                  )
                                  for (
                                    var w = 0,
                                      _ = Object.values(l.queries.query);
                                    w < _.length;
                                    w++
                                  )
                                    for (
                                      var P,
                                        x,
                                        k,
                                        K = 0,
                                        O = (P = _[w]).slice();
                                      K < O.length;
                                      K++
                                    )
                                      (x = O[K]).res != null &&
                                        u.mutatedParts &&
                                        (c && !x.dirty
                                          ? ((k = Object.isFrozen(x.res)),
                                            (k = dr(x.res, x.req, y, d, x, k)),
                                            x.dirty
                                              ? (Oe(P, x),
                                                x.subscribers.forEach(function (
                                                  S
                                                ) {
                                                  return f.add(S)
                                                }))
                                              : k !== x.res &&
                                                ((x.res = k),
                                                (x.promise = E.resolve({
                                                  result: k
                                                }))))
                                          : (x.dirty && Oe(P, x),
                                            x.subscribers.forEach(function (S) {
                                              return f.add(S)
                                            })))
                                }
                              }
                            }
                            f.forEach(function (S) {
                              return S()
                            })
                          }
                        }
                      }),
                      u.addEventListener('abort', i(!1), { signal: a }),
                      u.addEventListener('error', i(!1), { signal: a }),
                      u.addEventListener('complete', i(!0), { signal: a })),
                    u
                  )
                },
                table: function (t) {
                  var r = e.table(t),
                    i = r.schema.primaryKey
                  return C(C({}, r), {
                    mutate: function (o) {
                      var a = j.trans
                      if (
                        i.outbound ||
                        a.db._options.cache === 'disabled' ||
                        a.explicit ||
                        a.idbtrans.mode !== 'readwrite'
                      )
                        return r.mutate(o)
                      var u = De['idb://'.concat(n, '/').concat(t)]
                      return u
                        ? ((a = r.mutate(o)),
                          (o.type !== 'add' && o.type !== 'put') ||
                          !(
                            50 <= o.values.length ||
                            kt(i, o).some(function (c) {
                              return c == null
                            })
                          )
                            ? (u.optimisticOps.push(o),
                              o.mutatedParts && Bn(o.mutatedParts),
                              a.then(function (c) {
                                0 < c.numFailures &&
                                  (Oe(u.optimisticOps, o),
                                  (c = hr(0, o, c)) && u.optimisticOps.push(c),
                                  o.mutatedParts && Bn(o.mutatedParts))
                              }),
                              a.catch(function () {
                                Oe(u.optimisticOps, o),
                                  o.mutatedParts && Bn(o.mutatedParts)
                              }))
                            : a.then(function (c) {
                                var f = hr(
                                  0,
                                  C(C({}, o), {
                                    values: o.values.map(function (p, s) {
                                      var v
                                      return c.failures[s]
                                        ? p
                                        : ((p =
                                            (v = i.keyPath) !== null &&
                                            v !== void 0 &&
                                            v.includes('.')
                                              ? ke(p)
                                              : C({}, p)),
                                          ee(p, i.keyPath, c.results[s]),
                                          p)
                                    })
                                  }),
                                  c
                                )
                                u.optimisticOps.push(f),
                                  queueMicrotask(function () {
                                    return o.mutatedParts && Bn(o.mutatedParts)
                                  })
                              }),
                          a)
                        : r.mutate(o)
                    },
                    query: function (o) {
                      if (!lr(j, r) || !fr('query', o)) return r.query(o)
                      var a =
                          ((f = j.trans) === null || f === void 0
                            ? void 0
                            : f.db._options.cache) === 'immutable',
                        s = j,
                        u = s.requery,
                        c = s.signal,
                        f = (function (d, y, h, m) {
                          var g = De['idb://'.concat(d, '/').concat(y)]
                          if (!g) return []
                          if (!(y = g.queries[h])) return [null, !1, g, null]
                          var b = y[(m.query ? m.query.index.name : null) || '']
                          if (!b) return [null, !1, g, null]
                          switch (h) {
                            case 'query':
                              var w = b.find(function (_) {
                                return (
                                  _.req.limit === m.limit &&
                                  _.req.values === m.values &&
                                  pr(_.req.query.range, m.query.range)
                                )
                              })
                              return w
                                ? [w, !0, g, b]
                                : [
                                    b.find(function (_) {
                                      return (
                                        ('limit' in _.req
                                          ? _.req.limit
                                          : 1 / 0) >= m.limit &&
                                        (!m.values || _.req.values) &&
                                        ei(_.req.query.range, m.query.range)
                                      )
                                    }),
                                    !1,
                                    g,
                                    b
                                  ]
                            case 'count':
                              return (
                                (w = b.find(function (_) {
                                  return pr(_.req.query.range, m.query.range)
                                })),
                                [w, !!w, g, b]
                              )
                          }
                        })(n, t, 'query', o),
                        p = f[0],
                        s = f[1],
                        v = f[2],
                        l = f[3]
                      return (
                        p && s
                          ? (p.obsSet = o.obsSet)
                          : ((s = r
                              .query(o)
                              .then(function (d) {
                                var y = d.result
                                if ((p && (p.res = y), a)) {
                                  for (var h = 0, m = y.length; h < m; ++h)
                                    Object.freeze(y[h])
                                  Object.freeze(y)
                                } else d.result = ke(y)
                                return d
                              })
                              .catch(function (d) {
                                return l && p && Oe(l, p), Promise.reject(d)
                              })),
                            (p = {
                              obsSet: o.obsSet,
                              promise: s,
                              subscribers: new Set(),
                              type: 'query',
                              req: o,
                              dirty: !1
                            }),
                            l
                              ? l.push(p)
                              : ((l = [p]),
                                ((v =
                                  v ||
                                  (De['idb://'.concat(n, '/').concat(t)] = {
                                    queries: { query: {}, count: {} },
                                    objs: new Map(),
                                    optimisticOps: [],
                                    unsignaledParts: {}
                                  })).queries.query[o.query.index.name || ''] =
                                  l))),
                        ni(p, l, u, c),
                        p.promise.then(function (d) {
                          return {
                            result: dr(
                              d.result,
                              o,
                              v == null ? void 0 : v.optimisticOps,
                              r,
                              p,
                              a
                            )
                          }
                        })
                      )
                    }
                  })
                }
              })
            }
          }
          function Mn (e, n) {
            return new Proxy(e, {
              get: function (t, r, i) {
                return r === 'db' ? n : Reflect.get(t, r, i)
              }
            })
          }
          var he =
            ((z.prototype.version = function (e) {
              if (isNaN(e) || e < 0.1)
                throw new A.Type('Given version is not a positive number')
              if (
                ((e = Math.round(10 * e) / 10),
                this.idbdb || this._state.isBeingOpened)
              )
                throw new A.Schema('Cannot add version when database is open')
              this.verno = Math.max(this.verno, e)
              var n = this._versions,
                t = n.filter(function (r) {
                  return r._cfg.version === e
                })[0]
              return (
                t ||
                ((t = new this.Version(e)),
                n.push(t),
                n.sort(Wr),
                t.stores({}),
                (this._state.autoSchema = !1),
                t)
              )
            }),
            (z.prototype._whenReady = function (e) {
              var n = this
              return this.idbdb &&
                (this._state.openComplete || j.letThrough || this._vip)
                ? e()
                : new E(function (t, r) {
                    if (n._state.openComplete)
                      return r(new A.DatabaseClosed(n._state.dbOpenError))
                    if (!n._state.isBeingOpened) {
                      if (!n._state.autoOpen)
                        return void r(new A.DatabaseClosed())
                      n.open().catch(M)
                    }
                    n._state.dbReadyPromise.then(t, r)
                  }).then(e)
            }),
            (z.prototype.use = function (e) {
              var n = e.stack,
                t = e.create,
                r = e.level,
                i = e.name
              return (
                i && this.unuse({ stack: n, name: i }),
                (e = this._middlewares[n] || (this._middlewares[n] = [])),
                e.push({ stack: n, create: t, level: r ?? 10, name: i }),
                e.sort(function (o, a) {
                  return o.level - a.level
                }),
                this
              )
            }),
            (z.prototype.unuse = function (e) {
              var n = e.stack,
                t = e.name,
                r = e.create
              return (
                n &&
                  this._middlewares[n] &&
                  (this._middlewares[n] = this._middlewares[n].filter(function (
                    i
                  ) {
                    return r ? i.create !== r : !!t && i.name !== t
                  })),
                this
              )
            }),
            (z.prototype.open = function () {
              var e = this
              return je(ve, function () {
                return Qr(e)
              })
            }),
            (z.prototype._close = function () {
              var e = this._state,
                n = Ve.indexOf(this)
              if ((0 <= n && Ve.splice(n, 1), this.idbdb)) {
                try {
                  this.idbdb.close()
                } catch {}
                this.idbdb = null
              }
              e.isBeingOpened ||
                ((e.dbReadyPromise = new E(function (t) {
                  e.dbReadyResolve = t
                })),
                (e.openCanceller = new E(function (t, r) {
                  e.cancelOpen = r
                })))
            }),
            (z.prototype.close = function (t) {
              var n = (t === void 0 ? { disableAutoOpen: !0 } : t)
                  .disableAutoOpen,
                t = this._state
              n
                ? (t.isBeingOpened && t.cancelOpen(new A.DatabaseClosed()),
                  this._close(),
                  (t.autoOpen = !1),
                  (t.dbOpenError = new A.DatabaseClosed()))
                : (this._close(),
                  (t.autoOpen = this._options.autoOpen || t.isBeingOpened),
                  (t.openComplete = !1),
                  (t.dbOpenError = null))
            }),
            (z.prototype.delete = function (e) {
              var n = this
              e === void 0 && (e = { disableAutoOpen: !0 })
              var t = 0 < arguments.length && typeof arguments[0] != 'object',
                r = this._state
              return new E(function (i, o) {
                function a () {
                  n.close(e)
                  var u = n._deps.indexedDB.deleteDatabase(n.name)
                  ;(u.onsuccess = N(function () {
                    var c, f, p
                    ;(c = n._deps),
                      (f = n.name),
                      (p = c.indexedDB),
                      (c = c.IDBKeyRange),
                      pt(p) || f === kn || dt(p, c).delete(f).catch(M),
                      i()
                  })),
                    (u.onerror = oe(o)),
                    (u.onblocked = n._fireOnBlocked)
                }
                if (t)
                  throw new A.InvalidArgument(
                    'Invalid closeOptions argument to db.delete()'
                  )
                r.isBeingOpened ? r.dbReadyPromise.then(a) : a()
              })
            }),
            (z.prototype.backendDB = function () {
              return this.idbdb
            }),
            (z.prototype.isOpen = function () {
              return this.idbdb !== null
            }),
            (z.prototype.hasBeenClosed = function () {
              var e = this._state.dbOpenError
              return e && e.name === 'DatabaseClosed'
            }),
            (z.prototype.hasFailed = function () {
              return this._state.dbOpenError !== null
            }),
            (z.prototype.dynamicallyOpened = function () {
              return this._state.autoSchema
            }),
            Object.defineProperty(z.prototype, 'tables', {
              get: function () {
                var e = this
                return V(this._allTables).map(function (n) {
                  return e._allTables[n]
                })
              },
              enumerable: !1,
              configurable: !0
            }),
            (z.prototype.transaction = function () {
              var e = function (n, t, r) {
                var i = arguments.length
                if (i < 2) throw new A.InvalidArgument('Too few arguments')
                for (var o = new Array(i - 1); --i; ) o[i - 1] = arguments[i]
                return (r = o.pop()), [n, Tt(o), r]
              }.apply(this, arguments)
              return this._transaction.apply(this, e)
            }),
            (z.prototype._transaction = function (e, n, t) {
              var r = this,
                i = j.trans
              ;(i && i.db === this && e.indexOf('!') === -1) || (i = null)
              var o,
                a,
                u = e.indexOf('?') !== -1
              e = e.replace('!', '').replace('?', '')
              try {
                if (
                  ((a = n.map(function (f) {
                    if (
                      ((f = f instanceof r.Table ? f.name : f),
                      typeof f != 'string')
                    )
                      throw new TypeError(
                        'Invalid table argument to Dexie.transaction(). Only Table or String are allowed'
                      )
                    return f
                  })),
                  e == 'r' || e === nt)
                )
                  o = nt
                else {
                  if (e != 'rw' && e != tt)
                    throw new A.InvalidArgument(
                      'Invalid transaction mode: ' + e
                    )
                  o = tt
                }
                if (i) {
                  if (i.mode === nt && o === tt) {
                    if (!u)
                      throw new A.SubTransaction(
                        'Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY'
                      )
                    i = null
                  }
                  i &&
                    a.forEach(function (f) {
                      if (i && i.storeNames.indexOf(f) === -1) {
                        if (!u)
                          throw new A.SubTransaction(
                            'Table ' +
                              f +
                              ' not included in parent transaction.'
                          )
                        i = null
                      }
                    }),
                    u && i && !i.active && (i = null)
                }
              } catch (f) {
                return i
                  ? i._promise(null, function (p, s) {
                      s(f)
                    })
                  : U(f)
              }
              var c = function f (p, s, v, l, d) {
                return E.resolve().then(function () {
                  var y = j.transless || j,
                    h = p._createTransaction(s, v, p._dbSchema, l)
                  if (((h.explicit = !0), (y = { trans: h, transless: y }), l))
                    h.idbtrans = l.idbtrans
                  else
                    try {
                      h.create(),
                        (h.idbtrans._explicit = !0),
                        (p._state.PR1398_maxLoop = 3)
                    } catch (b) {
                      return b.name === Wn.InvalidState &&
                        p.isOpen() &&
                        0 < --p._state.PR1398_maxLoop
                        ? (console.warn('Dexie: Need to reopen db'),
                          p.close({ disableAutoOpen: !1 }),
                          p.open().then(function () {
                            return f(p, s, v, null, d)
                          }))
                        : U(b)
                    }
                  var m,
                    g = Vn(d)
                  return (
                    g && ze(),
                    (y = E.follow(function () {
                      var b
                      ;(m = d.call(h, h)) &&
                        (g
                          ? ((b = ge.bind(null, null)), m.then(b, b))
                          : typeof m.next == 'function' &&
                            typeof m.throw == 'function' &&
                            (m = _t(m)))
                    }, y)),
                    (m && typeof m.then == 'function'
                      ? E.resolve(m).then(function (b) {
                          return h.active
                            ? b
                            : U(
                                new A.PrematureCommit(
                                  'Transaction committed too early. See http://bit.ly/2kdckMn'
                                )
                              )
                        })
                      : y.then(function () {
                          return m
                        })
                    )
                      .then(function (b) {
                        return (
                          l && h._resolve(),
                          h._completion.then(function () {
                            return b
                          })
                        )
                      })
                      .catch(function (b) {
                        return h._reject(b), U(b)
                      })
                  )
                })
              }.bind(null, this, o, a, i, t)
              return i
                ? i._promise(o, c, 'lock')
                : j.trans
                ? je(j.transless, function () {
                    return r._whenReady(c)
                  })
                : this._whenReady(c)
            }),
            (z.prototype.table = function (e) {
              if (!J(this._allTables, e))
                throw new A.InvalidTable('Table '.concat(e, ' does not exist'))
              return this._allTables[e]
            }),
            z)
          function z (e, n) {
            var t = this
            ;(this._middlewares = {}), (this.verno = 0)
            var r = z.dependencies
            ;(this._options = n =
              C(
                {
                  addons: z.addons,
                  autoOpen: !0,
                  indexedDB: r.indexedDB,
                  IDBKeyRange: r.IDBKeyRange,
                  cache: 'cloned'
                },
                n
              )),
              (this._deps = {
                indexedDB: n.indexedDB,
                IDBKeyRange: n.IDBKeyRange
              }),
              (r = n.addons),
              (this._dbSchema = {}),
              (this._versions = []),
              (this._storeNames = []),
              (this._allTables = {}),
              (this.idbdb = null),
              (this._novip = this)
            var i,
              o,
              a,
              u,
              c,
              f = {
                dbOpenError: null,
                isBeingOpened: !1,
                onReadyBeingFired: null,
                openComplete: !1,
                dbReadyResolve: M,
                dbReadyPromise: null,
                cancelOpen: M,
                openCanceller: null,
                autoSchema: !0,
                PR1398_maxLoop: 3,
                autoOpen: n.autoOpen
              }
            ;(f.dbReadyPromise = new E(function (s) {
              f.dbReadyResolve = s
            })),
              (f.openCanceller = new E(function (s, v) {
                f.cancelOpen = v
              })),
              (this._state = f),
              (this.name = e),
              (this.on = nn(
                this,
                'populate',
                'blocked',
                'versionchange',
                'close',
                { ready: [Yn, M] }
              )),
              (this.on.ready.subscribe = Ct(
                this.on.ready.subscribe,
                function (s) {
                  return function (v, l) {
                    z.vip(function () {
                      var d,
                        y = t._state
                      y.openComplete
                        ? (y.dbOpenError || E.resolve().then(v), l && s(v))
                        : y.onReadyBeingFired
                        ? (y.onReadyBeingFired.push(v), l && s(v))
                        : (s(v),
                          (d = t),
                          l ||
                            s(function h () {
                              d.on.ready.unsubscribe(v),
                                d.on.ready.unsubscribe(h)
                            }))
                    })
                  }
                }
              )),
              (this.Collection =
                ((i = this),
                tn(Mr.prototype, function (m, h) {
                  this.db = i
                  var l = Wt,
                    d = null
                  if (h)
                    try {
                      l = h()
                    } catch (g) {
                      d = g
                    }
                  var y = m._ctx,
                    h = y.table,
                    m = h.hook.reading.fire
                  this._ctx = {
                    table: h,
                    index: y.index,
                    isPrimKey:
                      !y.index ||
                      (h.schema.primKey.keyPath &&
                        y.index === h.schema.primKey.name),
                    range: l,
                    keysOnly: !1,
                    dir: 'next',
                    unique: '',
                    algorithm: null,
                    filter: null,
                    replayFilter: null,
                    justLimit: !0,
                    isMatch: null,
                    offset: 0,
                    limit: 1 / 0,
                    error: d,
                    or: y.or,
                    valueMapper: m !== Xe ? m : null
                  }
                }))),
              (this.Table =
                ((o = this),
                tn(Qt.prototype, function (s, v, l) {
                  ;(this.db = o),
                    (this._tx = l),
                    (this.name = s),
                    (this.schema = v),
                    (this.hook = o._allTables[s]
                      ? o._allTables[s].hook
                      : nn(null, {
                          creating: [jr, M],
                          reading: [Sr, Xe],
                          updating: [Cr, M],
                          deleting: [Ar, M]
                        }))
                }))),
              (this.Transaction =
                ((a = this),
                tn(Lr.prototype, function (s, v, l, d, y) {
                  var h = this
                  ;(this.db = a),
                    (this.mode = s),
                    (this.storeNames = v),
                    (this.schema = l),
                    (this.chromeTransactionDurability = d),
                    (this.idbtrans = null),
                    (this.on = nn(this, 'complete', 'error', 'abort')),
                    (this.parent = y || null),
                    (this.active = !0),
                    (this._reculock = 0),
                    (this._blockedFuncs = []),
                    (this._resolve = null),
                    (this._reject = null),
                    (this._waitingFor = null),
                    (this._waitingQueue = null),
                    (this._spinCount = 0),
                    (this._completion = new E(function (m, g) {
                      ;(h._resolve = m), (h._reject = g)
                    })),
                    this._completion.then(
                      function () {
                        ;(h.active = !1), h.on.complete.fire()
                      },
                      function (m) {
                        var g = h.active
                        return (
                          (h.active = !1),
                          h.on.error.fire(m),
                          h.parent
                            ? h.parent._reject(m)
                            : g && h.idbtrans && h.idbtrans.abort(),
                          U(m)
                        )
                      }
                    )
                }))),
              (this.Version =
                ((u = this),
                tn(Gr.prototype, function (s) {
                  ;(this.db = u),
                    (this._cfg = {
                      version: s,
                      storesSource: null,
                      dbschema: {},
                      tables: {},
                      contentUpgrade: null
                    })
                }))),
              (this.WhereClause =
                ((c = this),
                tn(er.prototype, function (s, v, l) {
                  if (
                    ((this.db = c),
                    (this._ctx = {
                      table: s,
                      index: v === ':id' ? null : v,
                      or: l
                    }),
                    (this._cmp = this._ascending = B),
                    (this._descending = function (d, y) {
                      return B(y, d)
                    }),
                    (this._max = function (d, y) {
                      return 0 < B(d, y) ? d : y
                    }),
                    (this._min = function (d, y) {
                      return B(d, y) < 0 ? d : y
                    }),
                    (this._IDBKeyRange = c._deps.IDBKeyRange),
                    !this._IDBKeyRange)
                  )
                    throw new A.MissingAPI()
                }))),
              this.on('versionchange', function (s) {
                0 < s.newVersion
                  ? console.warn(
                      "Another connection wants to upgrade database '".concat(
                        t.name,
                        "'. Closing db now to resume the upgrade."
                      )
                    )
                  : console.warn(
                      "Another connection wants to delete database '".concat(
                        t.name,
                        "'. Closing db now to resume the delete request."
                      )
                    ),
                  t.close({ disableAutoOpen: !1 })
              }),
              this.on('blocked', function (s) {
                !s.newVersion || s.newVersion < s.oldVersion
                  ? console.warn(
                      "Dexie.delete('".concat(t.name, "') was blocked")
                    )
                  : console.warn(
                      "Upgrade '"
                        .concat(
                          t.name,
                          "' blocked by other connection holding version "
                        )
                        .concat(s.oldVersion / 10)
                    )
              }),
              (this._maxKey = un(n.IDBKeyRange)),
              (this._createTransaction = function (s, v, l, d) {
                return new t.Transaction(
                  s,
                  v,
                  l,
                  t._options.chromeTransactionDurability,
                  d
                )
              }),
              (this._fireOnBlocked = function (s) {
                t.on('blocked').fire(s),
                  Ve.filter(function (v) {
                    return v.name === t.name && v !== t && !v._state.vcFired
                  }).map(function (v) {
                    return v.on('versionchange').fire(s)
                  })
              }),
              this.use(Jr),
              this.use(ti),
              this.use(Zr),
              this.use(Xr),
              this.use(Hr)
            var p = new Proxy(this, {
              get: function (s, v, l) {
                if (v === '_vip') return !0
                if (v === 'table')
                  return function (y) {
                    return Mn(t.table(y), p)
                  }
                var d = Reflect.get(s, v, l)
                return d instanceof Qt
                  ? Mn(d, p)
                  : v === 'tables'
                  ? d.map(function (y) {
                      return Mn(y, p)
                    })
                  : v === '_createTransaction'
                  ? function () {
                      return Mn(d.apply(this, arguments), p)
                    }
                  : d
              }
            })
            ;(this.vip = p),
              r.forEach(function (s) {
                return s(t)
              })
          }
          var Fn,
            re =
              typeof Symbol < 'u' && 'observable' in Symbol
                ? Symbol.observable
                : '@@observable',
            ri =
              ((Pt.prototype.subscribe = function (e, n, t) {
                return this._subscribe(
                  e && typeof e != 'function'
                    ? e
                    : { next: e, error: n, complete: t }
                )
              }),
              (Pt.prototype[re] = function () {
                return this
              }),
              Pt)
          function Pt (e) {
            this._subscribe = e
          }
          try {
            Fn = {
              indexedDB:
                $.indexedDB ||
                $.mozIndexedDB ||
                $.webkitIndexedDB ||
                $.msIndexedDB,
              IDBKeyRange: $.IDBKeyRange || $.webkitIDBKeyRange
            }
          } catch {
            Fn = { indexedDB: null, IDBKeyRange: null }
          }
          function yr (e) {
            var n,
              t = !1,
              r = new ri(function (i) {
                var o = Vn(e),
                  a,
                  u = !1,
                  c = {},
                  f = {},
                  p = {
                    get closed () {
                      return u
                    },
                    unsubscribe: function () {
                      u ||
                        ((u = !0),
                        a && a.abort(),
                        s && _e.storagemutated.unsubscribe(l))
                    }
                  }
                i.start && i.start(p)
                var s = !1,
                  v = function () {
                    return et(d)
                  },
                  l = function (y) {
                    In(c, y), mt(f, c) && v()
                  },
                  d = function () {
                    var y, h, m
                    !u &&
                      Fn.indexedDB &&
                      ((c = {}),
                      (y = {}),
                      a && a.abort(),
                      (a = new AbortController()),
                      (m = (function (g) {
                        var b = Le()
                        try {
                          o && ze()
                          var w = me(e, g)
                          return (w = o ? w.finally(ge) : w)
                        } finally {
                          b && Ue()
                        }
                      })(
                        (h = {
                          subscr: y,
                          signal: a.signal,
                          requery: v,
                          querier: e,
                          trans: null
                        })
                      )),
                      Promise.resolve(m).then(
                        function (g) {
                          ;(t = !0),
                            (n = g),
                            u ||
                              h.signal.aborted ||
                              ((c = {}),
                              (function (b) {
                                for (var w in b) if (J(b, w)) return
                                return 1
                              })((f = y)) ||
                                s ||
                                (_e(an, l), (s = !0)),
                              et(function () {
                                return !u && i.next && i.next(g)
                              }))
                        },
                        function (g) {
                          ;(t = !1),
                            ['DatabaseClosedError', 'AbortError'].includes(
                              g == null ? void 0 : g.name
                            ) ||
                              u ||
                              et(function () {
                                u || (i.error && i.error(g))
                              })
                        }
                      ))
                  }
                return setTimeout(v, 0), p
              })
            return (
              (r.hasValue = function () {
                return t
              }),
              (r.getValue = function () {
                return n
              }),
              r
            )
          }
          var qe = he
          function Kt (e) {
            var n = xe
            try {
              ;(xe = !0), _e.storagemutated.fire(e), wt(e, !0)
            } finally {
              xe = n
            }
          }
          Be(
            qe,
            C(C({}, pn), {
              delete: function (e) {
                return new qe(e, { addons: [] }).delete()
              },
              exists: function (e) {
                return new qe(e, { addons: [] })
                  .open()
                  .then(function (n) {
                    return n.close(), !0
                  })
                  .catch('NoSuchDatabaseError', function () {
                    return !1
                  })
              },
              getDatabaseNames: function (e) {
                try {
                  return (
                    (n = qe.dependencies),
                    (t = n.indexedDB),
                    (n = n.IDBKeyRange),
                    (pt(t)
                      ? Promise.resolve(t.databases()).then(function (r) {
                          return r
                            .map(function (i) {
                              return i.name
                            })
                            .filter(function (i) {
                              return i !== kn
                            })
                        })
                      : dt(t, n).toCollection().primaryKeys()
                    ).then(e)
                  )
                } catch {
                  return U(new A.MissingAPI())
                }
                var n, t
              },
              defineClass: function () {
                return function (e) {
                  Z(this, e)
                }
              },
              ignoreTransaction: function (e) {
                return j.trans ? je(j.transless, e) : e()
              },
              vip: yt,
              async: function (e) {
                return function () {
                  try {
                    var n = _t(e.apply(this, arguments))
                    return n && typeof n.then == 'function' ? n : E.resolve(n)
                  } catch (t) {
                    return U(t)
                  }
                }
              },
              spawn: function (e, n, t) {
                try {
                  var r = _t(e.apply(t, n || []))
                  return r && typeof r.then == 'function' ? r : E.resolve(r)
                } catch (i) {
                  return U(i)
                }
              },
              currentTransaction: {
                get: function () {
                  return j.trans || null
                }
              },
              waitFor: function (e, n) {
                return (
                  (n = E.resolve(
                    typeof e == 'function' ? qe.ignoreTransaction(e) : e
                  ).timeout(n || 6e4)),
                  j.trans ? j.trans.waitFor(n) : n
                )
              },
              Promise: E,
              debug: {
                get: function () {
                  return ie
                },
                set: function (e) {
                  Mt(e)
                }
              },
              derive: Re,
              extend: Z,
              props: Be,
              override: Ct,
              Events: nn,
              on: _e,
              liveQuery: yr,
              extendObservabilitySet: In,
              getByKeyPath: se,
              setByKeyPath: ee,
              delByKeyPath: function (e, n) {
                typeof n == 'string'
                  ? ee(e, n, void 0)
                  : 'length' in n &&
                    [].map.call(n, function (t) {
                      ee(e, t, void 0)
                    })
              },
              shallowClone: qt,
              deepClone: ke,
              getObjectDiff: xt,
              cmp: B,
              asap: Dt,
              minKey: -1 / 0,
              addons: [],
              connections: Ve,
              errnames: Wn,
              dependencies: Fn,
              cache: De,
              semVer: '4.0.10',
              version: '4.0.10'
                .split('.')
                .map(function (e) {
                  return parseInt(e)
                })
                .reduce(function (e, n, t) {
                  return e + n / Math.pow(10, 2 * t)
                })
            })
          ),
            (qe.maxKey = un(qe.dependencies.IDBKeyRange)),
            typeof dispatchEvent < 'u' &&
              typeof addEventListener < 'u' &&
              (_e(an, function (e) {
                xe ||
                  ((e = new CustomEvent(at, { detail: e })),
                  (xe = !0),
                  dispatchEvent(e),
                  (xe = !1))
              }),
              addEventListener(at, function (e) {
                ;(e = e.detail), xe || Kt(e)
              }))
          var $e,
            xe = !1,
            vr = function () {}
          return (
            typeof BroadcastChannel < 'u' &&
              ((vr = function () {
                ;($e = new BroadcastChannel(at)).onmessage = function (e) {
                  return e.data && Kt(e.data)
                }
              })(),
              typeof $e.unref == 'function' && $e.unref(),
              _e(an, function (e) {
                xe || $e.postMessage(e)
              })),
            typeof addEventListener < 'u' &&
              (addEventListener('pagehide', function (e) {
                if (!he.disableBfCache && e.persisted) {
                  ie && console.debug('Dexie: handling persisted pagehide'),
                    $e != null && $e.close()
                  for (var n = 0, t = Ve; n < t.length; n++)
                    t[n].close({ disableAutoOpen: !1 })
                }
              }),
              addEventListener('pageshow', function (e) {
                !he.disableBfCache &&
                  e.persisted &&
                  (ie && console.debug('Dexie: handling persisted pageshow'),
                  vr(),
                  Kt({ all: new G(-1 / 0, [[]]) }))
              })),
            (E.rejectionMapper = function (e, n) {
              return !e ||
                e instanceof Fe ||
                e instanceof TypeError ||
                e instanceof SyntaxError ||
                !e.name ||
                !Rt[e.name]
                ? e
                : ((n = new Rt[e.name](n || e.message, e)),
                  'stack' in e &&
                    ye(n, 'stack', {
                      get: function () {
                        return this.inner.stack
                      }
                    }),
                  n)
            }),
            Mt(ie),
            C(
              he,
              Object.freeze({
                __proto__: null,
                Dexie: he,
                liveQuery: yr,
                Entity: Yt,
                cmp: B,
                PropModSymbol: fe,
                PropModification: rn,
                replacePrefix: function (e, n) {
                  return new rn({ replacePrefix: [e, n] })
                },
                add: function (e) {
                  return new rn({ add: e })
                },
                remove: function (e) {
                  return new rn({ remove: e })
                },
                default: he,
                RangeSet: G,
                mergeRanges: ln,
                rangesOverlap: or
              }),
              { default: he }
            ),
            he
          )
        })
      })(Ln)),
    Ln.exports
  )
}
var li = ci()
const St = ui(li),
  br = Symbol.for('Dexie'),
  jt = globalThis[br] || (globalThis[br] = St)
if (St.semVer !== jt.semVer)
  throw new Error(
    `Two different versions of Dexie loaded in the same app: ${St.semVer} and ${jt.semVer}`
  )
class fi extends jt {
  constructor () {
    super('Database')
    mr(this, 'quizzes')
    this.version(1).stores({ quizzes: '&id, quiz_id' })
  }
}
const pi = new fi()
export { pi as d }
