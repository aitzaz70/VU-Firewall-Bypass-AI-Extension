const j = {
  context: void 0,
  registry: void 0,
  effects: void 0,
  done: !1,
  getContextId () {
    return Ye(this.context.count)
  },
  getNextContextId () {
    return Ye(this.context.count++)
  }
}
function Ye (e) {
  const t = String(e),
    n = t.length - 1
  return j.context.id + (n ? String.fromCharCode(96 + n) : '') + t
}
function jt (e) {
  j.context = e
}
const Tt = (e, t) => e === t,
  I = Symbol('solid-proxy'),
  it = typeof Proxy == 'function',
  xe = Symbol('solid-track'),
  ae = { equals: Tt }
let ct = dt
const $ = 1,
  fe = 2,
  lt = { owned: null, cleanups: null, context: null, owner: null }
var _ = null
let _e = null,
  zt = null,
  S = null,
  E = null,
  L = null,
  we = 0
function ve (e, t) {
  const n = S,
    r = _,
    s = e.length === 0,
    o = t === void 0 ? r : t,
    i = s
      ? lt
      : {
          owned: null,
          cleanups: null,
          context: o ? o.context : null,
          owner: o
        },
    c = s ? e : () => e(() => M(() => re(i)))
  ;(_ = i), (S = null)
  try {
    return Z(c, !0)
  } finally {
    ;(S = n), (_ = r)
  }
}
function H (e, t) {
  t = t ? Object.assign({}, ae, t) : ae
  const n = {
      value: e,
      observers: null,
      observerSlots: null,
      comparator: t.equals || void 0
    },
    r = s => (typeof s == 'function' && (s = s(n.value)), ft(n, s))
  return [at.bind(n), r]
}
function Sn (e, t, n) {
  const r = me(e, t, !0, $)
  Q(r)
}
function It (e, t, n) {
  const r = me(e, t, !1, $)
  Q(r)
}
function Mt (e, t, n) {
  ct = Rt
  const r = me(e, t, !1, $)
  ;(r.user = !0), L ? L.push(r) : Q(r)
}
function z (e, t, n) {
  n = n ? Object.assign({}, ae, n) : ae
  const r = me(e, t, !0, 0)
  return (
    (r.observers = null),
    (r.observerSlots = null),
    (r.comparator = n.equals || void 0),
    Q(r),
    at.bind(r)
  )
}
function kt (e) {
  return Z(e, !1)
}
function M (e) {
  if (S === null) return e()
  const t = S
  S = null
  try {
    return e()
  } finally {
    S = t
  }
}
function An (e, t, n) {
  const r = Array.isArray(e)
  let s
  return o => {
    let i
    if (r) {
      i = Array(e.length)
      for (let l = 0; l < e.length; l++) i[l] = e[l]()
    } else i = e()
    const c = M(() => t(i, s, o))
    return (s = i), c
  }
}
function On (e) {
  Mt(() => M(e))
}
function Dt (e) {
  return (
    _ === null ||
      (_.cleanups === null ? (_.cleanups = [e]) : _.cleanups.push(e)),
    e
  )
}
function Ee () {
  return S
}
function xn (e, t) {
  const n = Symbol('context')
  return { id: n, Provider: Ft(n), defaultValue: e }
}
function En (e) {
  let t
  return _ && _.context && (t = _.context[e.id]) !== void 0 ? t : e.defaultValue
}
function ut (e) {
  const t = z(e),
    n = z(() => Pe(t()))
  return (
    (n.toArray = () => {
      const r = n()
      return Array.isArray(r) ? r : r != null ? [r] : []
    }),
    n
  )
}
function at () {
  if (this.sources && this.state)
    if (this.state === $) Q(this)
    else {
      const e = E
      ;(E = null), Z(() => he(this), !1), (E = e)
    }
  if (S) {
    const e = this.observers ? this.observers.length : 0
    S.sources
      ? (S.sources.push(this), S.sourceSlots.push(e))
      : ((S.sources = [this]), (S.sourceSlots = [e])),
      this.observers
        ? (this.observers.push(S),
          this.observerSlots.push(S.sources.length - 1))
        : ((this.observers = [S]),
          (this.observerSlots = [S.sources.length - 1]))
  }
  return this.value
}
function ft (e, t, n) {
  let r = e.value
  return (
    (!e.comparator || !e.comparator(r, t)) &&
      ((e.value = t),
      e.observers &&
        e.observers.length &&
        Z(() => {
          for (let s = 0; s < e.observers.length; s += 1) {
            const o = e.observers[s],
              i = _e && _e.running
            i && _e.disposed.has(o),
              (i ? !o.tState : !o.state) &&
                (o.pure ? E.push(o) : L.push(o), o.observers && ht(o)),
              i || (o.state = $)
          }
          if (E.length > 1e6) throw ((E = []), new Error())
        }, !1)),
    t
  )
}
function Q (e) {
  if (!e.fn) return
  re(e)
  const t = we
  Lt(e, e.value, t)
}
function Lt (e, t, n) {
  let r
  const s = _,
    o = S
  S = _ = e
  try {
    r = e.fn(t)
  } catch (i) {
    return (
      e.pure &&
        ((e.state = $), e.owned && e.owned.forEach(re), (e.owned = null)),
      (e.updatedAt = n + 1),
      gt(i)
    )
  } finally {
    ;(S = o), (_ = s)
  }
  ;(!e.updatedAt || e.updatedAt <= n) &&
    (e.updatedAt != null && 'observers' in e ? ft(e, r) : (e.value = r),
    (e.updatedAt = n))
}
function me (e, t, n, r = $, s) {
  const o = {
    fn: e,
    state: r,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: _,
    context: _ ? _.context : null,
    pure: n
  }
  return (
    _ === null || (_ !== lt && (_.owned ? _.owned.push(o) : (_.owned = [o]))), o
  )
}
function de (e) {
  if (e.state === 0) return
  if (e.state === fe) return he(e)
  if (e.suspense && M(e.suspense.inFallback)) return e.suspense.effects.push(e)
  const t = [e]
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < we); )
    e.state && t.push(e)
  for (let n = t.length - 1; n >= 0; n--)
    if (((e = t[n]), e.state === $)) Q(e)
    else if (e.state === fe) {
      const r = E
      ;(E = null), Z(() => he(e, t[0]), !1), (E = r)
    }
}
function Z (e, t) {
  if (E) return e()
  let n = !1
  t || (E = []), L ? (n = !0) : (L = []), we++
  try {
    const r = e()
    return Nt(n), r
  } catch (r) {
    n || (L = null), (E = null), gt(r)
  }
}
function Nt (e) {
  if ((E && (dt(E), (E = null)), e)) return
  const t = L
  ;(L = null), t.length && Z(() => ct(t), !1)
}
function dt (e) {
  for (let t = 0; t < e.length; t++) de(e[t])
}
function Rt (e) {
  let t,
    n = 0
  for (t = 0; t < e.length; t++) {
    const r = e[t]
    r.user ? (e[n++] = r) : de(r)
  }
  if (j.context) {
    if (j.count) {
      j.effects || (j.effects = []), j.effects.push(...e.slice(0, n))
      return
    }
    jt()
  }
  for (
    j.effects &&
      !j.count &&
      ((e = [...j.effects, ...e]), (n += j.effects.length), delete j.effects),
      t = 0;
    t < n;
    t++
  )
    de(e[t])
}
function he (e, t) {
  e.state = 0
  for (let n = 0; n < e.sources.length; n += 1) {
    const r = e.sources[n]
    if (r.sources) {
      const s = r.state
      s === $
        ? r !== t && (!r.updatedAt || r.updatedAt < we) && de(r)
        : s === fe && he(r, t)
    }
  }
}
function ht (e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const n = e.observers[t]
    n.state ||
      ((n.state = fe), n.pure ? E.push(n) : L.push(n), n.observers && ht(n))
  }
}
function re (e) {
  let t
  if (e.sources)
    for (; e.sources.length; ) {
      const n = e.sources.pop(),
        r = e.sourceSlots.pop(),
        s = n.observers
      if (s && s.length) {
        const o = s.pop(),
          i = n.observerSlots.pop()
        r < s.length &&
          ((o.sourceSlots[i] = r), (s[r] = o), (n.observerSlots[r] = i))
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) re(e.tOwned[t])
    delete e.tOwned
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) re(e.owned[t])
    e.owned = null
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]()
    e.cleanups = null
  }
  e.state = 0
}
function $t (e) {
  return e instanceof Error
    ? e
    : new Error(typeof e == 'string' ? e : 'Unknown error', { cause: e })
}
function gt (e, t = _) {
  throw $t(e)
}
function Pe (e) {
  if (typeof e == 'function' && !e.length) return Pe(e())
  if (Array.isArray(e)) {
    const t = []
    for (let n = 0; n < e.length; n++) {
      const r = Pe(e[n])
      Array.isArray(r) ? t.push.apply(t, r) : t.push(r)
    }
    return t
  }
  return e
}
function Ft (e, t) {
  return function (r) {
    let s
    return (
      It(
        () =>
          (s = M(
            () => (
              (_.context = { ..._.context, [e]: r.value }), ut(() => r.children)
            )
          )),
        void 0
      ),
      s
    )
  }
}
const Ut = Symbol('fallback')
function Ge (e) {
  for (let t = 0; t < e.length; t++) e[t]()
}
function Bt (e, t, n = {}) {
  let r = [],
    s = [],
    o = [],
    i = 0,
    c = t.length > 1 ? [] : null
  return (
    Dt(() => Ge(o)),
    () => {
      let l = e() || [],
        u = l.length,
        f,
        a
      return (
        l[xe],
        M(() => {
          let y, b, O, v, P, A, d, h, p
          if (u === 0)
            i !== 0 &&
              (Ge(o), (o = []), (r = []), (s = []), (i = 0), c && (c = [])),
              n.fallback &&
                ((r = [Ut]),
                (s[0] = ve(x => ((o[0] = x), n.fallback()))),
                (i = 1))
          else if (i === 0) {
            for (s = new Array(u), a = 0; a < u; a++)
              (r[a] = l[a]), (s[a] = ve(g))
            i = u
          } else {
            for (
              O = new Array(u),
                v = new Array(u),
                c && (P = new Array(u)),
                A = 0,
                d = Math.min(i, u);
              A < d && r[A] === l[A];
              A++
            );
            for (
              d = i - 1, h = u - 1;
              d >= A && h >= A && r[d] === l[h];
              d--, h--
            )
              (O[h] = s[d]), (v[h] = o[d]), c && (P[h] = c[d])
            for (y = new Map(), b = new Array(h + 1), a = h; a >= A; a--)
              (p = l[a]),
                (f = y.get(p)),
                (b[a] = f === void 0 ? -1 : f),
                y.set(p, a)
            for (f = A; f <= d; f++)
              (p = r[f]),
                (a = y.get(p)),
                a !== void 0 && a !== -1
                  ? ((O[a] = s[f]),
                    (v[a] = o[f]),
                    c && (P[a] = c[f]),
                    (a = b[a]),
                    y.set(p, a))
                  : o[f]()
            for (a = A; a < u; a++)
              a in O
                ? ((s[a] = O[a]), (o[a] = v[a]), c && ((c[a] = P[a]), c[a](a)))
                : (s[a] = ve(g))
            ;(s = s.slice(0, (i = u))), (r = l.slice(0))
          }
          return s
        })
      )
      function g (y) {
        if (((o[a] = y), c)) {
          const [b, O] = H(a)
          return (c[a] = O), t(l[a], b)
        }
        return t(l[a])
      }
    }
  )
}
function Pn (e, t) {
  return M(() => e(t || {}))
}
function ie () {
  return !0
}
const Ce = {
  get (e, t, n) {
    return t === I ? n : e.get(t)
  },
  has (e, t) {
    return t === I ? !0 : e.has(t)
  },
  set: ie,
  deleteProperty: ie,
  getOwnPropertyDescriptor (e, t) {
    return {
      configurable: !0,
      enumerable: !0,
      get () {
        return e.get(t)
      },
      set: ie,
      deleteProperty: ie
    }
  },
  ownKeys (e) {
    return e.keys()
  }
}
function Se (e) {
  return (e = typeof e == 'function' ? e() : e) ? e : {}
}
function qt () {
  for (let e = 0, t = this.length; e < t; ++e) {
    const n = this[e]()
    if (n !== void 0) return n
  }
}
function Cn (...e) {
  let t = !1
  for (let i = 0; i < e.length; i++) {
    const c = e[i]
    ;(t = t || (!!c && I in c)),
      (e[i] = typeof c == 'function' ? ((t = !0), z(c)) : c)
  }
  if (it && t)
    return new Proxy(
      {
        get (i) {
          for (let c = e.length - 1; c >= 0; c--) {
            const l = Se(e[c])[i]
            if (l !== void 0) return l
          }
        },
        has (i) {
          for (let c = e.length - 1; c >= 0; c--) if (i in Se(e[c])) return !0
          return !1
        },
        keys () {
          const i = []
          for (let c = 0; c < e.length; c++) i.push(...Object.keys(Se(e[c])))
          return [...new Set(i)]
        }
      },
      Ce
    )
  const n = {},
    r = Object.create(null)
  for (let i = e.length - 1; i >= 0; i--) {
    const c = e[i]
    if (!c) continue
    const l = Object.getOwnPropertyNames(c)
    for (let u = l.length - 1; u >= 0; u--) {
      const f = l[u]
      if (f === '__proto__' || f === 'constructor') continue
      const a = Object.getOwnPropertyDescriptor(c, f)
      if (!r[f])
        r[f] = a.get
          ? {
              enumerable: !0,
              configurable: !0,
              get: qt.bind((n[f] = [a.get.bind(c)]))
            }
          : a.value !== void 0
          ? a
          : void 0
      else {
        const g = n[f]
        g &&
          (a.get
            ? g.push(a.get.bind(c))
            : a.value !== void 0 && g.push(() => a.value))
      }
    }
  }
  const s = {},
    o = Object.keys(r)
  for (let i = o.length - 1; i >= 0; i--) {
    const c = o[i],
      l = r[c]
    l && l.get ? Object.defineProperty(s, c, l) : (s[c] = l ? l.value : void 0)
  }
  return s
}
function jn (e, ...t) {
  if (it && I in e) {
    const s = new Set(t.length > 1 ? t.flat() : t[0]),
      o = t.map(
        i =>
          new Proxy(
            {
              get (c) {
                return i.includes(c) ? e[c] : void 0
              },
              has (c) {
                return i.includes(c) && c in e
              },
              keys () {
                return i.filter(c => c in e)
              }
            },
            Ce
          )
      )
    return (
      o.push(
        new Proxy(
          {
            get (i) {
              return s.has(i) ? void 0 : e[i]
            },
            has (i) {
              return s.has(i) ? !1 : i in e
            },
            keys () {
              return Object.keys(e).filter(i => !s.has(i))
            }
          },
          Ce
        )
      ),
      o
    )
  }
  const n = {},
    r = t.map(() => ({}))
  for (const s of Object.getOwnPropertyNames(e)) {
    const o = Object.getOwnPropertyDescriptor(e, s),
      i = !o.get && !o.set && o.enumerable && o.writable && o.configurable
    let c = !1,
      l = 0
    for (const u of t)
      u.includes(s) &&
        ((c = !0), i ? (r[l][s] = o.value) : Object.defineProperty(r[l], s, o)),
        ++l
    c || (i ? (n[s] = o.value) : Object.defineProperty(n, s, o))
  }
  return [...r, n]
}
let Ht = 0
function Tn () {
  return j.context ? j.getNextContextId() : `cl-${Ht++}`
}
const pt = e => `Stale read from <${e}>.`
function zn (e) {
  const t = 'fallback' in e && { fallback: () => e.fallback }
  return z(Bt(() => e.each, e.children, t || void 0))
}
function In (e) {
  const t = e.keyed,
    n = z(() => e.when, void 0, { equals: (r, s) => (t ? r === s : !r == !s) })
  return z(
    () => {
      const r = n()
      if (r) {
        const s = e.children
        return typeof s == 'function' && s.length > 0
          ? M(() =>
              s(
                t
                  ? r
                  : () => {
                      if (!M(n)) throw pt('Show')
                      return e.when
                    }
              )
            )
          : s
      }
      return e.fallback
    },
    void 0,
    void 0
  )
}
function Mn (e) {
  let t = !1
  const n = (o, i) => (t ? o[1] === i[1] : !o[1] == !i[1]) && o[2] === i[2],
    r = ut(() => e.children),
    s = z(
      () => {
        let o = r()
        Array.isArray(o) || (o = [o])
        for (let i = 0; i < o.length; i++) {
          const c = o[i].when
          if (c) return (t = !!o[i].keyed), [i, c, o[i]]
        }
        return [-1]
      },
      void 0,
      { equals: n }
    )
  return z(
    () => {
      const [o, i, c] = s()
      if (o < 0) return e.fallback
      const l = c.children
      return typeof l == 'function' && l.length > 0
        ? M(() =>
            l(
              t
                ? i
                : () => {
                    if (M(s)[0] !== o) throw pt('Match')
                    return c.when
                  }
            )
          )
        : l
    },
    void 0,
    void 0
  )
}
function kn (e) {
  return e
}
class Kt extends Error {
  constructor () {
    super(
      'Context not defined. Call `initialize(Context)` before using any chrome functions'
    ),
      (this.name = 'ContextNotDefinedError')
  }
}
var B = (e => (
  (e.Background = 'background'),
  (e.ContentScript = 'contentScript'),
  (e.SidePanel = 'sidePanel'),
  (e.Popup = 'popup'),
  (e.External = 'external'),
  e
))(B || {})
let je
function Dn (e) {
  je = e
}
function Le () {
  if (!je) throw new Kt()
  return je
}
const Ln = 'https://vubuddy.com',
  Jt = 'vu-buddy'
var tt
const Nn =
    (tt = chrome == null ? void 0 : chrome.runtime) == null ? void 0 : tt.id,
  U = e => e.test(navigator.userAgent)
function Wt () {
  if (typeof navigator > 'u') return 6
  switch (!0) {
    case U(/edg/i):
      return 0
    case U(/trident/i):
      return 1
    case U(/firefox|fxios/i):
      return 2
    case U(/opr\//i):
      return 3
    case U(/ucbrowser/i):
      return 4
    case U(/samsungbrowser/i):
      return 5
    case U(/chrome|chromium|crios/i):
      return 6
    case U(/safari/i):
      return 7
    default:
      return 8
  }
}
const yt = () => Wt() === 2
function Te (e) {
  return typeof e == 'function'
}
const Yt = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict'
let bt = (e = 21) => {
  let t = '',
    n = crypto.getRandomValues(new Uint8Array((e |= 0)))
  for (; e--; ) t += Yt[n[e] & 63]
  return t
}
const Ae = 'AbortController',
  ce = new Map(),
  Gt = {
    serialize (
      e,
      { sendMessage: t, destination: n, type: r, origin: s, sender: o }
    ) {
      const i = bt(6)
      return (
        ce.set(i, e),
        e.signal.addEventListener(
          'abort',
          () => {
            var u
            const c =
              r === 'reply'
                ? {
                    destination: s,
                    tabId:
                      (u = o == null ? void 0 : o.tab) == null ? void 0 : u.id
                  }
                : n
            let l = e.signal.reason
            typeof (l == null ? void 0 : l.stack) == 'string' &&
              l.stack.includes('signal is aborted without reason') &&
              (l = void 0),
              t(c, '__Serialized__', Ae, i, 'abort', l)
          },
          { once: !0 }
        ),
        { __type__: Ae, value: i }
      )
    },
    deserialize ({ value: e }) {
      const t = new AbortController()
      return ce.set(e, t), t
    },
    canSerialize (e) {
      return e instanceof AbortController
    },
    canDeserialize (e) {
      return e === Ae
    },
    onMessage (e) {
      const [t, n, r] = e,
        s = ce.get(t)
      if (!s) return !1
      n === 'abort' && (s.abort(r), ce.delete(t))
    }
  },
  Vt =
    self.requestIdleCallback ||
    function (e) {
      var t = Date.now()
      return setTimeout(() => {
        e({
          didTimeout: !1,
          timeRemaining: () => Math.max(0, 50 - (Date.now() - t))
        })
      }, 1)
    }
class Xt extends Error {
  constructor (t) {
    super(t), (this.name = 'AbortError')
  }
}
function Qt (e) {
  return (
    typeof e == 'object' &&
    e !== null &&
    'name' in e &&
    (e == null ? void 0 : e.name) === 'AbortError'
  )
}
const Oe = new Map(),
  Ve = new Map(),
  te = 'ReadableStream',
  Zt = {
    serialize (
      e,
      { destination: t, sendMessage: n, origin: r, type: s, sender: o }
    ) {
      var y
      const i = bt(6)
      Ve.set(i, e)
      const c = e.getReader()
      let l = !1,
        u
      c.closed.then(() => (l = !0)).catch(b => (u = b))
      const f = () => {
          Ve.delete(i)
        },
        a =
          s === 'reply'
            ? {
                destination: r,
                tabId: (y = o == null ? void 0 : o.tab) == null ? void 0 : y.id
              }
            : t,
        g = () => {
          c.read()
            .then(({ value: b, done: O }) => {
              if (l) return f()
              if (u) return n(a, '__Serialized__', te, i, 'error', u), f()
              n(a, '__Serialized__', te, i, 'enqueue', b, O), O ? f() : g()
            })
            .catch(b => {
              if (Qt(b))
                (l = !0), f(), n(a, '__Serialized__', te, i, 'abort', b.message)
              else throw b
            })
        }
      return Vt(g), { __type__: te, value: i }
    },
    deserialize ({ value: e }) {
      return new ReadableStream({
        start (t) {
          Oe.set(e, t)
        }
      })
    },
    canSerialize (e) {
      return e instanceof ReadableStream
    },
    canDeserialize (e) {
      return e === te
    },
    onMessage (e) {
      const [t, n, r, s] = e,
        o = Oe.get(t)
      if (!o) return !1
      n === 'enqueue'
        ? (o.enqueue(r), s && (o.close(), Oe.delete(t)))
        : n === 'error'
        ? o.error(r)
        : n === 'abort' && o.error(new Xt(r))
    }
  },
  Xe = 'Error',
  en = {
    serialize (e) {
      return {
        __type__: Xe,
        value: { name: e.name, message: e.message, stack: e.stack }
      }
    },
    deserialize ({ value: e }) {
      return Object.assign(new Error(), e)
    },
    canDeserialize (e) {
      return e === Xe
    },
    canSerialize (e) {
      return e instanceof Error
    }
  },
  tn = {
    serialize (e) {
      return { __type__: 'Date', value: e.toISOString() }
    },
    deserialize ({ value: e }) {
      return new Date(e)
    },
    canSerialize (e) {
      return e instanceof Date
    },
    canDeserialize (e) {
      return e === 'Date'
    }
  },
  Ne = [Zt, Gt, en, tn]
function ze (e, t) {
  for (const n of Ne) if (n.canSerialize(e)) return n.serialize(e, t)
  return e
}
function Ie (e, t) {
  if (typeof e == 'object' && e !== null && '__type__' in e) {
    for (const n of Ne)
      if (n.canDeserialize(e.__type__)) return n.deserialize(e, t)
  }
  return e
}
function nn ([e, ...t], n, r) {
  var s
  for (const o of Ne)
    if (o.canDeserialize(e))
      return (s = o.onMessage) == null ? void 0 : s.call(o, t, n, r)
  return !1
}
const q = async (e, t, ...n) => {
    const r = Le()
    let s
    typeof e == 'object' && ((s = e.tabId), (e = e.destination)), (n = [...n])
    for (const c in n) {
      const l = n[c]
      let u = ze(l, {
        destination: e,
        origin: r,
        sendMessage: q,
        type: 'message'
      })
      u instanceof Promise && (u = await u), u !== l && (n[c] = u)
    }
    const o = { event: t, data: n, destination: e, origin: r }
    return (
      s
        ? ((c, l) => {
            var u
            if (
              Te(
                (u = chrome == null ? void 0 : chrome.tabs) == null
                  ? void 0
                  : u.sendMessage
              )
            )
              return chrome.tabs.sendMessage(c, l)
            throw new Error(
              'chrome.tabs.sendMessage is only available in the background context'
            )
          })(s, o)
        : chrome.runtime.sendMessage(o)
    ).then(async c => {
      var l
      if ((l = chrome == null ? void 0 : chrome.runtime) != null && l.lastError)
        throw chrome.runtime.lastError
      if (c != null && c.__type__) {
        const u = Ie(c, { origin: e, destination: r, type: 'reply' })
        if (u instanceof Error) throw u
        return u
      } else if (Array.isArray(c) || (typeof c == 'object' && c !== null))
        for (const u in c) {
          const f = c[u]
          f != null &&
            f.__type__ &&
            ((c[u] = Ie(f, { origin: r, destination: e, type: 'reply' })),
            c[u] instanceof Promise && (c[u] = await c[u]))
        }
      return c
    })
  },
  Me = new Map(),
  ke = new Map(),
  ge = new Set(),
  N = (e, t) => (Me.set(e, t), () => Me.delete(e))
N.background = N
N.sidePanel = N
N.contentScript = N
N.external = (e, t) => (ke.set(e, t), () => ke.delete(e))
const J = e => {
  for (const t in e) N(t, e[t])
}
J.background = J
J.sidePanel = J
J.contentScript = J
J.external = e => {
  for (const t in e) N.external(t, e[t])
}
const Rn = e => (ge.add(e), () => ge.delete(e)),
  rn = (e, t, n) => {
    const r = Le()
    if (!(e != null && e.event) || e.destination !== r) return !1
    const s = { ...t, destination: e.destination, origin: e.origin }
    let o = !1
    if (e.origin === B.External) o = wt(e, t, n)
    else {
      const i = e.data
      for (const c in i) {
        const l = i[c]
        let u = Ie(l, {
          destination: e.destination,
          origin: e.origin,
          type: 'message'
        })
        u !== l && (i[c] = u)
      }
      e.event === '__Serialized__'
        ? (o = nn(i, s, n))
        : (o = mt(Me.get(e.event), i, s, n))
    }
    return o instanceof Promise && !yt() ? !0 : o
  },
  wt = (e, t, n) => {
    const r = Le()
    if (!(e != null && e.event) || e.destination !== r) return !1
    const s = { ...t, destination: e.destination, origin: e.origin },
      o = mt(ke.get(e.event), e.data, s, n)
    return typeof o != 'boolean' && !yt() ? !0 : o
  }
function mt (e, t, n, r) {
  if (!e) return !1
  let s, o
  try {
    s = e(n, ...t)
  } catch (c) {
    o = c
  }
  const i = Promise.resolve()
    .then(() => o ?? s)
    .catch(c => c)
    .then(async c => {
      c instanceof Error && console.error(c)
      const l = {
          destination: n.destination,
          origin: n.origin,
          sendMessage: q,
          sender: n,
          type: 'reply'
        },
        u = ze(c, l)
      if (u !== c) return u
      if (Array.isArray(c) || (typeof c == 'object' && c !== null))
        for (const f in c) {
          const a = c[f]
          let g = ze(a, l)
          g instanceof Promise && (g = await g), g !== a && (c[f] = g)
        }
      return c
    })
  return i.then(r), i
}
function on () {
  var e, t, n
  return (
    Te(
      (e = chrome == null ? void 0 : chrome.runtime) == null
        ? void 0
        : e.sendMessage
    ) &&
    Te(
      (n =
        (t = chrome == null ? void 0 : chrome.runtime) == null
          ? void 0
          : t.onMessage) == null
        ? void 0
        : n.addListener
    )
  )
}
addEventListener(
  `${Jt}-context-invalidated`,
  () => {
    ge.forEach(e => e()), ge.clear()
  },
  { once: !0 }
)
var nt, le, rt, ot, ue, st
on() &&
  ((rt =
    (le =
      (nt = chrome == null ? void 0 : chrome.runtime) == null
        ? void 0
        : nt.onMessage) == null
      ? void 0
      : le.addListener) == null || rt.call(le, rn),
  (st =
    (ue =
      (ot = chrome == null ? void 0 : chrome.runtime) == null
        ? void 0
        : ot.onMessageExternal) == null
      ? void 0
      : ue.addListener) == null || st.call(ue, wt))
const pe = Symbol('store-raw'),
  V = Symbol('store-node'),
  D = Symbol('store-has'),
  _t = Symbol('store-self')
function vt (e) {
  let t = e[I]
  if (
    !t &&
    (Object.defineProperty(e, I, { value: (t = new Proxy(e, ln)) }),
    !Array.isArray(e))
  ) {
    const n = Object.keys(e),
      r = Object.getOwnPropertyDescriptors(e)
    for (let s = 0, o = n.length; s < o; s++) {
      const i = n[s]
      r[i].get &&
        Object.defineProperty(e, i, {
          enumerable: r[i].enumerable,
          get: r[i].get.bind(t)
        })
    }
  }
  return t
}
function k (e) {
  let t
  return (
    e != null &&
    typeof e == 'object' &&
    (e[I] ||
      !(t = Object.getPrototypeOf(e)) ||
      t === Object.prototype ||
      Array.isArray(e))
  )
}
function R (e, t = new Set()) {
  let n, r, s, o
  if ((n = e != null && e[pe])) return n
  if (!k(e) || t.has(e)) return e
  if (Array.isArray(e)) {
    Object.isFrozen(e) ? (e = e.slice(0)) : t.add(e)
    for (let i = 0, c = e.length; i < c; i++)
      (s = e[i]), (r = R(s, t)) !== s && (e[i] = r)
  } else {
    Object.isFrozen(e) ? (e = Object.assign({}, e)) : t.add(e)
    const i = Object.keys(e),
      c = Object.getOwnPropertyDescriptors(e)
    for (let l = 0, u = i.length; l < u; l++)
      (o = i[l]), !c[o].get && ((s = e[o]), (r = R(s, t)) !== s && (e[o] = r))
  }
  return e
}
function ye (e, t) {
  let n = e[t]
  return (
    n || Object.defineProperty(e, t, { value: (n = Object.create(null)) }), n
  )
}
function oe (e, t, n) {
  if (e[t]) return e[t]
  const [r, s] = H(n, { equals: !1, internal: !0 })
  return (r.$ = s), (e[t] = r)
}
function sn (e, t) {
  const n = Reflect.getOwnPropertyDescriptor(e, t)
  return (
    !n ||
      n.get ||
      !n.configurable ||
      t === I ||
      t === V ||
      (delete n.value, delete n.writable, (n.get = () => e[I][t])),
    n
  )
}
function St (e) {
  Ee() && oe(ye(e, V), _t)()
}
function cn (e) {
  return St(e), Reflect.ownKeys(e)
}
const ln = {
  get (e, t, n) {
    if (t === pe) return e
    if (t === I) return n
    if (t === xe) return St(e), n
    const r = ye(e, V),
      s = r[t]
    let o = s ? s() : e[t]
    if (t === V || t === D || t === '__proto__') return o
    if (!s) {
      const i = Object.getOwnPropertyDescriptor(e, t)
      Ee() &&
        (typeof o != 'function' || e.hasOwnProperty(t)) &&
        !(i && i.get) &&
        (o = oe(r, t, o)())
    }
    return k(o) ? vt(o) : o
  },
  has (e, t) {
    return t === pe ||
      t === I ||
      t === xe ||
      t === V ||
      t === D ||
      t === '__proto__'
      ? !0
      : (Ee() && oe(ye(e, D), t)(), t in e)
  },
  set () {
    return !0
  },
  deleteProperty () {
    return !0
  },
  ownKeys: cn,
  getOwnPropertyDescriptor: sn
}
function T (e, t, n, r = !1) {
  if (!r && e[t] === n) return
  const s = e[t],
    o = e.length
  n === void 0
    ? (delete e[t], e[D] && e[D][t] && s !== void 0 && e[D][t].$())
    : ((e[t] = n), e[D] && e[D][t] && s === void 0 && e[D][t].$())
  let i = ye(e, V),
    c
  if (((c = oe(i, t, s)) && c.$(() => n), Array.isArray(e) && e.length !== o)) {
    for (let l = e.length; l < o; l++) (c = i[l]) && c.$()
    ;(c = oe(i, 'length', o)) && c.$(e.length)
  }
  ;(c = i[_t]) && c.$()
}
function At (e, t) {
  const n = Object.keys(t)
  for (let r = 0; r < n.length; r += 1) {
    const s = n[r]
    T(e, s, t[s])
  }
}
function un (e, t) {
  if ((typeof t == 'function' && (t = t(e)), (t = R(t)), Array.isArray(t))) {
    if (e === t) return
    let n = 0,
      r = t.length
    for (; n < r; n++) {
      const s = t[n]
      e[n] !== s && T(e, n, s)
    }
    T(e, 'length', r)
  } else At(e, t)
}
function ne (e, t, n = []) {
  let r,
    s = e
  if (t.length > 1) {
    r = t.shift()
    const i = typeof r,
      c = Array.isArray(e)
    if (Array.isArray(r)) {
      for (let l = 0; l < r.length; l++) ne(e, [r[l]].concat(t), n)
      return
    } else if (c && i === 'function') {
      for (let l = 0; l < e.length; l++) r(e[l], l) && ne(e, [l].concat(t), n)
      return
    } else if (c && i === 'object') {
      const { from: l = 0, to: u = e.length - 1, by: f = 1 } = r
      for (let a = l; a <= u; a += f) ne(e, [a].concat(t), n)
      return
    } else if (t.length > 1) {
      ne(e[r], t, [r].concat(n))
      return
    }
    ;(s = e[r]), (n = [r].concat(n))
  }
  let o = t[0]
  ;(typeof o == 'function' && ((o = o(s, n)), o === s)) ||
    (r === void 0 && o == null) ||
    ((o = R(o)),
    r === void 0 || (k(s) && k(o) && !Array.isArray(o)) ? At(s, o) : T(e, r, o))
}
function Re (...[e, t]) {
  const n = R(e || {}),
    r = Array.isArray(n),
    s = vt(n)
  function o (...i) {
    kt(() => {
      r && i.length === 1 ? un(n, i[0]) : ne(n, i)
    })
  }
  return [s, o]
}
const De = Symbol('store-root')
function G (e, t, n, r, s) {
  const o = t[n]
  if (e === o) return
  const i = Array.isArray(e)
  if (
    n !== De &&
    (!k(e) || !k(o) || i !== Array.isArray(o) || (s && e[s] !== o[s]))
  ) {
    T(t, n, e)
    return
  }
  if (i) {
    if (e.length && o.length && (!r || (s && e[0] && e[0][s] != null))) {
      let u, f, a, g, y, b, O, v
      for (
        a = 0, g = Math.min(o.length, e.length);
        a < g && (o[a] === e[a] || (s && o[a] && e[a] && o[a][s] === e[a][s]));
        a++
      )
        G(e[a], o, a, r, s)
      const P = new Array(e.length),
        A = new Map()
      for (
        g = o.length - 1, y = e.length - 1;
        g >= a &&
        y >= a &&
        (o[g] === e[y] || (s && o[a] && e[a] && o[g][s] === e[y][s]));
        g--, y--
      )
        P[y] = o[g]
      if (a > y || a > g) {
        for (f = a; f <= y; f++) T(o, f, e[f])
        for (; f < e.length; f++) T(o, f, P[f]), G(e[f], o, f, r, s)
        o.length > e.length && T(o, 'length', e.length)
        return
      }
      for (O = new Array(y + 1), f = y; f >= a; f--)
        (b = e[f]),
          (v = s && b ? b[s] : b),
          (u = A.get(v)),
          (O[f] = u === void 0 ? -1 : u),
          A.set(v, f)
      for (u = a; u <= g; u++)
        (b = o[u]),
          (v = s && b ? b[s] : b),
          (f = A.get(v)),
          f !== void 0 && f !== -1 && ((P[f] = o[u]), (f = O[f]), A.set(v, f))
      for (f = a; f < e.length; f++)
        f in P ? (T(o, f, P[f]), G(e[f], o, f, r, s)) : T(o, f, e[f])
    } else for (let u = 0, f = e.length; u < f; u++) G(e[u], o, u, r, s)
    o.length > e.length && T(o, 'length', e.length)
    return
  }
  const c = Object.keys(e)
  for (let u = 0, f = c.length; u < f; u++) G(e[c[u]], o, c[u], r, s)
  const l = Object.keys(o)
  for (let u = 0, f = l.length; u < f; u++)
    e[l[u]] === void 0 && T(o, l[u], void 0)
}
function $n (e, t = {}) {
  const { merge: n, key: r = 'id' } = t,
    s = R(e)
  return o => {
    if (!k(o) || !k(s)) return s
    const i = G(s, { [De]: o }, De, n, r)
    return i === void 0 ? o : i
  }
}
const be = new WeakMap(),
  Ot = {
    get (e, t) {
      if (t === pe) return e
      const n = e[t]
      let r
      return k(n) ? be.get(n) || (be.set(n, (r = new Proxy(n, Ot))), r) : n
    },
    set (e, t, n) {
      return T(e, t, R(n)), !0
    },
    deleteProperty (e, t) {
      return T(e, t, void 0, !0), !0
    }
  }
function Fn (e) {
  return t => {
    if (k(t)) {
      let n
      ;(n = be.get(t)) || be.set(t, (n = new Proxy(t, Ot))), e(n)
    }
    return t
  }
}
function an () {
  let e, t
  return {
    promise: new Promise((r, s) => {
      ;(e = r), (t = s)
    }),
    resolve: e,
    reject: t
  }
}
function Qe (e, t) {
  var i, c
  if (
    typeof ((c =
      (i = chrome == null ? void 0 : chrome.storage) == null
        ? void 0
        : i.local) == null
      ? void 0
      : c.get) != 'function'
  )
    return fn(t)
  const [n, r] = Re(structuredClone(t)),
    s = an()
  ;(async () => {
    const u = (await chrome.storage.local.get(e))[e]
    if (!u) return s.resolve(!1)
    r(f => ({ ...f, ...u })), s.resolve(!0)
  })(),
    chrome.storage.local.onChanged.addListener(async l => {
      e in l &&
        (l[e].newValue
          ? r(l[e].newValue)
          : (chrome.storage.local.remove(e), r(structuredClone(t))))
    })
  const o = () => n
  return (
    (o.toString = () => JSON.stringify(n)),
    (o.set = l => {
      const u = { ...R(n), ...l }
      chrome.storage.local.set({ [e]: u })
    }),
    (o.reset = () => {
      chrome.storage.local.remove(e), r(structuredClone(t))
    }),
    (o.promise = () => s.promise.then(() => o)),
    o
  )
}
function Un (e, t) {
  const [n, r] = Re(structuredClone(t)),
    s = () => n
  ;(s.toString = () => JSON.stringify(n)),
    (s.set = i => {
      const c = { ...R(n), ...i }
      r(c), localStorage.setItem(e, btoa(JSON.stringify(c)))
    }),
    (s.reset = () => {
      localStorage.removeItem(e), r(structuredClone(t))
    }),
    window.addEventListener('storage', i => {
      if (i.storageArea === localStorage && i.key === e) {
        const c = i.newValue
        r(c ? JSON.parse(atob(c)) : structuredClone(t))
      }
    }),
    (s.promise = () => Promise.resolve(s))
  const o = localStorage.getItem(e)
  return o && r(JSON.parse(atob(o))), s
}
function fn (e) {
  const [t, n] = Re(structuredClone(e)),
    r = () => t
  return (
    (r.toString = () => JSON.stringify(t)),
    (r.set = s => {
      n(o => ({ ...o, ...s }))
    }),
    (r.reset = () => {
      n(structuredClone(e))
    }),
    (r.promise = () => Promise.resolve(r)),
    r
  )
}
const dn = 'application/json',
  xt = 'Content-Type',
  Y = Symbol(),
  Et = Symbol()
function Ze (e = {}) {
  var t
  const n = e instanceof Array ? Object.fromEntries(e) : e
  return (t = Object.entries(n).find(
    ([r]) => r.toLowerCase() === xt.toLowerCase()
  )) === null || t === void 0
    ? void 0
    : t[1]
}
function et (e) {
  return /^application\/.*json.*/.test(e)
}
const K = function (e, t, n = !1) {
    return Object.entries(t).reduce(
      (r, [s, o]) => {
        const i = e[s]
        return (
          Array.isArray(i) && Array.isArray(o)
            ? (r[s] = n ? [...i, ...o] : o)
            : typeof i == 'object' && typeof o == 'object'
            ? (r[s] = K(i, o, n))
            : (r[s] = o),
          r
        )
      },
      { ...e }
    )
  },
  X = {
    options: {},
    errorType: 'text',
    polyfills: {},
    polyfill (e, t = !0, n = !1, ...r) {
      const s =
        this.polyfills[e] ||
        (typeof self < 'u' ? self[e] : null) ||
        (typeof global < 'u' ? global[e] : null)
      if (t && !s) throw new Error(e + ' is not defined')
      return n && s ? new s(...r) : s
    }
  }
function hn (e, t = !1) {
  X.options = t ? e : K(X.options, e)
}
function gn (e, t = !1) {
  X.polyfills = t ? e : K(X.polyfills, e)
}
function pn (e) {
  X.errorType = e
}
const yn = e => t => e.reduceRight((n, r) => r(n), t) || t
class Pt extends Error {}
const bn = e => {
    const t = Object.create(null)
    e = e._addons.reduce(
      (d, h) => (h.beforeRequest && h.beforeRequest(d, e._options, t)) || d,
      e
    )
    const {
        _url: n,
        _options: r,
        _config: s,
        _catchers: o,
        _resolvers: i,
        _middlewares: c,
        _addons: l
      } = e,
      u = new Map(o),
      f = K(s.options, r)
    let a = n
    const g = yn(c)((d, h) => ((a = d), s.polyfill('fetch')(d, h)))(n, f),
      y = new Error(),
      b = g
        .catch(d => {
          throw { [Y]: d }
        })
        .then(d => {
          var h
          if (!d.ok) {
            const p = new Pt()
            if (
              ((p.cause = y),
              (p.stack =
                p.stack +
                `
CAUSE: ` +
                y.stack),
              (p.response = d),
              (p.status = d.status),
              (p.url = a),
              d.type === 'opaque')
            )
              throw p
            const x =
              s.errorType === 'json' ||
              ((h = d.headers.get('Content-Type')) === null || h === void 0
                ? void 0
                : h.split(';')[0]) === 'application/json'
            return (
              s.errorType
                ? x
                  ? d.text()
                  : d[s.errorType]()
                : Promise.resolve(d.body)
            ).then(C => {
              throw (
                ((p.message = typeof C == 'string' ? C : d.statusText),
                C &&
                  (x && typeof C == 'string'
                    ? ((p.text = C), (p.json = JSON.parse(C)))
                    : (p[s.errorType] = C)),
                p)
              )
            })
          }
          return d
        }),
      O = d =>
        d.catch(h => {
          const p = Object.prototype.hasOwnProperty.call(h, Y),
            x = p ? h[Y] : h,
            ee =
              ((x == null ? void 0 : x.status) && u.get(x.status)) ||
              u.get(x == null ? void 0 : x.name) ||
              (p && u.has(Y) && u.get(Y))
          if (ee) return ee(x, e)
          const C = u.get(Et)
          if (C) return C(x, e)
          throw x
        }),
      v = d => h =>
        O(
          d
            ? b.then(p => p && p[d]()).then(p => (h ? h(p) : p))
            : b.then(p => (h ? h(p) : p))
        ),
      P = {
        _wretchReq: e,
        _fetchReq: g,
        _sharedState: t,
        res: v(null),
        json: v('json'),
        blob: v('blob'),
        formData: v('formData'),
        arrayBuffer: v('arrayBuffer'),
        text: v('text'),
        error (d, h) {
          return u.set(d, h), this
        },
        badRequest (d) {
          return this.error(400, d)
        },
        unauthorized (d) {
          return this.error(401, d)
        },
        forbidden (d) {
          return this.error(403, d)
        },
        notFound (d) {
          return this.error(404, d)
        },
        timeout (d) {
          return this.error(408, d)
        },
        internalError (d) {
          return this.error(500, d)
        },
        fetchError (d) {
          return this.error(Y, d)
        }
      },
      A = l.reduce(
        (d, h) => ({
          ...d,
          ...(typeof h.resolver == 'function' ? h.resolver(d) : h.resolver)
        }),
        P
      )
    return i.reduce((d, h) => h(d, e), A)
  },
  wn = {
    _url: '',
    _options: {},
    _config: X,
    _catchers: new Map(),
    _resolvers: [],
    _deferred: [],
    _middlewares: [],
    _addons: [],
    addon (e) {
      return { ...this, _addons: [...this._addons, e], ...e.wretch }
    },
    errorType (e) {
      return { ...this, _config: { ...this._config, errorType: e } }
    },
    polyfills (e, t = !1) {
      return {
        ...this,
        _config: {
          ...this._config,
          polyfills: t ? e : K(this._config.polyfills, e)
        }
      }
    },
    url (e, t = !1) {
      if (t) return { ...this, _url: e }
      const n = this._url.split('?')
      return {
        ...this,
        _url: n.length > 1 ? n[0] + e + '?' + n[1] : this._url + e
      }
    },
    options (e, t = !1) {
      return { ...this, _options: t ? e : K(this._options, e) }
    },
    headers (e) {
      const t = e
        ? Array.isArray(e)
          ? Object.fromEntries(e)
          : 'entries' in e
          ? Object.fromEntries(e.entries())
          : e
        : {}
      return { ...this, _options: K(this._options, { headers: t }) }
    },
    accept (e) {
      return this.headers({ Accept: e })
    },
    content (e) {
      return this.headers({ [xt]: e })
    },
    auth (e) {
      return this.headers({ Authorization: e })
    },
    catcher (e, t) {
      const n = new Map(this._catchers)
      return n.set(e, t), { ...this, _catchers: n }
    },
    catcherFallback (e) {
      return this.catcher(Et, e)
    },
    resolve (e, t = !1) {
      return { ...this, _resolvers: t ? [e] : [...this._resolvers, e] }
    },
    defer (e, t = !1) {
      return { ...this, _deferred: t ? [e] : [...this._deferred, e] }
    },
    middlewares (e, t = !1) {
      return { ...this, _middlewares: t ? e : [...this._middlewares, ...e] }
    },
    fetch (e = this._options.method, t = '', n = null) {
      let r = this.url(t).options({ method: e })
      const s = Ze(r._options.headers),
        o = this._config.polyfill('FormData', !1),
        i =
          typeof n == 'object' &&
          !(o && n instanceof o) &&
          (!r._options.headers || !s || et(s))
      return (
        (r = n ? (i ? r.json(n, s) : r.body(n)) : r),
        bn(r._deferred.reduce((c, l) => l(c, c._url, c._options), r))
      )
    },
    get (e = '') {
      return this.fetch('GET', e)
    },
    delete (e = '') {
      return this.fetch('DELETE', e)
    },
    put (e, t = '') {
      return this.fetch('PUT', t, e)
    },
    post (e, t = '') {
      return this.fetch('POST', t, e)
    },
    patch (e, t = '') {
      return this.fetch('PATCH', t, e)
    },
    head (e = '') {
      return this.fetch('HEAD', e)
    },
    opts (e = '') {
      return this.fetch('OPTIONS', e)
    },
    body (e) {
      return { ...this, _options: { ...this._options, body: e } }
    },
    json (e, t) {
      const n = Ze(this._options.headers)
      return this.content(t || (et(n) && n) || dn).body(JSON.stringify(e))
    }
  }
function W (e = '', t = {}) {
  return { ...wn, _url: e, _options: t }
}
W.default = W
W.options = hn
W.errorType = pn
W.polyfills = gn
W.WretchError = Pt
const mn = e => {
    if (!e || e.length === 0) return ''
    const t = e.toLowerCase()
    return t.substring(0, 1).toUpperCase() + t.substring(1, t.length)
  },
  _n = e =>
    e
      ? e
          .split(/(?=[A-Z])|[\.\-\s_]/)
          .map(t => t.trim())
          .filter(t => !!t)
          .map(t => mn(t.toLowerCase()))
          .join(' ')
      : ''
var vn = (e => (
  (e[(e.Subscribed = 1)] = 'Subscribed'),
  (e[(e.LoggedIn = 0)] = 'LoggedIn'),
  (e[(e.LoggedOut = 2)] = 'LoggedOut'),
  (e[(e.ContinueAs = 3)] = 'ContinueAs'),
  e
))(vn || {})
function Bn (e = !1) {
  const [t, n] = H(),
    r = Qe('account', { token: void 0 }),
    [s, o] = H()
  e ||
    q(B.Background, 'd40291e2710006a5fc78943499ea060e').then(m => {
      o(m)
    })
  const [i, c] = H(),
    l = Qe('localAccount', { sessionId: void 0, user: void 0 }),
    [u, f] = H(),
    [a, g] = H(!0),
    y = z(() => (e ? i() : l().sessionId === s() ? l().user : void 0)),
    b = z(() => {
      var m, w
      return (m = y()) != null && m.email && r().token
        ? y().subscribed
          ? 0
          : 1
        : (w = u()) != null && w.email
        ? 3
        : 2
    }),
    O = z(() => b() === 0)
  function v () {
    return q(B.Background, 'd40291e2710006a5fc78943499ea060e')
  }
  async function P () {
    var m
    try {
      g(!0), await p(), await r.promise()
      const w = await chrome.storage.local
          .get('session_id')
          .then(se => se.session_id),
        F = await v()
      F !== w || !((m = r()) != null && m.token)
        ? (await d(),
          F && (await chrome.storage.local.set({ session_id: F })),
          await A())
        : await C(r().token).catch(() => A())
    } catch (w) {
      console.error(w)
    } finally {
      g(!1)
    }
  }
  async function A () {
    const m = await h()
    f(m)
  }
  async function d () {
    var m, w
    r.set({ token: void 0 }),
      c(void 0),
      l.set({ sessionId: void 0, user: void 0 }),
      (w =
        (m = chrome == null ? void 0 : chrome.storage) == null
          ? void 0
          : m.local) == null || w.remove('subscribe_url_cache')
  }
  async function h () {
    var Ue, Be, qe, He, Ke, Je, We
    const m = await W('https://vulms.vu.edu.pk/Profile/StudentProfile.aspx', {
      credentials: 'include',
      priority: 'high'
    })
      .get()
      .fetchError(() => {})
      .res()
    if (!(m != null && m.url) || !m.url.includes('Profile/StudentProfile.aspx'))
      return
    const w = new DOMParser().parseFromString(await m.text(), 'text/html'),
      F =
        (Be =
          (Ue = w.getElementById('MainContent_lblStdId')) == null
            ? void 0
            : Ue.textContent) == null
          ? void 0
          : Be.trim(),
      se =
        (He =
          (qe = w.getElementById('MainContent_lblStdName')) == null
            ? void 0
            : qe.textContent) == null
          ? void 0
          : He.trim(),
      $e =
        (Ke = w.getElementById('MainContent_txtStdEmail')) == null
          ? void 0
          : Ke.value,
      Fe =
        (We =
          (Je = w.getElementById('MainContent_lblVuEmail')) == null
            ? void 0
            : Je.textContent) == null
          ? void 0
          : We.trim()
    if (!(!F || !se || !$e || !Fe))
      return {
        id: F.toUpperCase(),
        name: _n(se.toLocaleLowerCase()),
        email: Fe,
        personal_email: $e
      }
  }
  async function p () {
    n(await q(B.Background, 'ca425c5852b4d7dcd48490f6c8392020'))
  }
  async function x (m) {
    try {
      g(!0), await ee(m)
    } catch (w) {
      console.error(w)
    } finally {
      g(!1)
    }
  }
  async function ee (m) {
    const w = await q(B.Background, '6a00cebb99a7779cea28567d9b45978e', m)
    if (w) return await C(w).then(() => w)
  }
  async function C (m) {
    const w = await q(B.Background, '4750140e5c1fe2a486703813ab519180', m)
    if (w) {
      c(w), r.set({ token: m })
      const F = await v()
      return l.set({ user: w, sessionId: F }), w
    }
  }
  async function Ct (m) {
    const w = await q(B.Background, 'caf41c34c80dae0adce788a65ee42334', m)
    return w.success && (await C(r().token)), w
  }
  return {
    account: r,
    semester: t,
    user: y,
    continueAs: u,
    processing: a,
    status: b,
    isSubscribed: 1,
    loginAs: x,
    checkLogin: P,
    activateLicense: Ct
  }
}
export {
  Jt as A,
  ut as B,
  B as C,
  Sn as D,
  Nn as E,
  zn as F,
  Qe as G,
  Fn as H,
  ve as I,
  j as J,
  kn as M,
  In as S,
  Dn as a,
  Pn as b,
  H as c,
  It as d,
  Un as e,
  z as f,
  Mt as g,
  M as h,
  On as i,
  Mn as j,
  vn as k,
  Re as l,
  Cn as m,
  Tn as n,
  Dt as o,
  jn as p,
  Rn as q,
  $n as r,
  q as s,
  W as t,
  Bn as u,
  Ln as v,
  N as w,
  xn as x,
  En as y,
  An as z
}
