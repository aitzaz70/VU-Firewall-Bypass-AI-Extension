import {
  I as Te,
  d as L,
  h as xe,
  J as k,
  p as W,
  f as O,
  m as D,
  c as Ee,
  g as Le,
  b as K
} from './D_rTIZ-0.js'
const ze = [
    'allowfullscreen',
    'async',
    'autofocus',
    'autoplay',
    'checked',
    'controls',
    'default',
    'disabled',
    'formnovalidate',
    'hidden',
    'indeterminate',
    'inert',
    'ismap',
    'loop',
    'multiple',
    'muted',
    'nomodule',
    'novalidate',
    'open',
    'playsinline',
    'readonly',
    'required',
    'reversed',
    'seamless',
    'selected'
  ],
  Me = new Set([
    'className',
    'value',
    'readOnly',
    'formNoValidate',
    'isMap',
    'noModule',
    'playsInline',
    ...ze
  ]),
  Ge = new Set(['innerHTML', 'textContent', 'innerText', 'children']),
  $e = Object.assign(Object.create(null), {
    className: 'class',
    htmlFor: 'for'
  }),
  Ie = Object.assign(Object.create(null), {
    class: 'className',
    formnovalidate: { $: 'formNoValidate', BUTTON: 1, INPUT: 1 },
    ismap: { $: 'isMap', IMG: 1 },
    nomodule: { $: 'noModule', SCRIPT: 1 },
    playsinline: { $: 'playsInline', VIDEO: 1 },
    readonly: { $: 'readOnly', INPUT: 1, TEXTAREA: 1 }
  })
function je (e, t) {
  const o = Ie[e]
  return typeof o == 'object' ? (o[t] ? o.$ : void 0) : o
}
const Re = new Set([
    'beforeinput',
    'click',
    'dblclick',
    'contextmenu',
    'focusin',
    'focusout',
    'input',
    'keydown',
    'keyup',
    'mousedown',
    'mousemove',
    'mouseout',
    'mouseover',
    'mouseup',
    'pointerdown',
    'pointermove',
    'pointerout',
    'pointerover',
    'pointerup',
    'touchend',
    'touchmove',
    'touchstart'
  ]),
  Oe = new Set([
    'altGlyph',
    'altGlyphDef',
    'altGlyphItem',
    'animate',
    'animateColor',
    'animateMotion',
    'animateTransform',
    'circle',
    'clipPath',
    'color-profile',
    'cursor',
    'defs',
    'desc',
    'ellipse',
    'feBlend',
    'feColorMatrix',
    'feComponentTransfer',
    'feComposite',
    'feConvolveMatrix',
    'feDiffuseLighting',
    'feDisplacementMap',
    'feDistantLight',
    'feDropShadow',
    'feFlood',
    'feFuncA',
    'feFuncB',
    'feFuncG',
    'feFuncR',
    'feGaussianBlur',
    'feImage',
    'feMerge',
    'feMergeNode',
    'feMorphology',
    'feOffset',
    'fePointLight',
    'feSpecularLighting',
    'feSpotLight',
    'feTile',
    'feTurbulence',
    'filter',
    'font',
    'font-face',
    'font-face-format',
    'font-face-name',
    'font-face-src',
    'font-face-uri',
    'foreignObject',
    'g',
    'glyph',
    'glyphRef',
    'hkern',
    'image',
    'line',
    'linearGradient',
    'marker',
    'mask',
    'metadata',
    'missing-glyph',
    'mpath',
    'path',
    'pattern',
    'polygon',
    'polyline',
    'radialGradient',
    'rect',
    'set',
    'stop',
    'svg',
    'switch',
    'symbol',
    'text',
    'textPath',
    'tref',
    'tspan',
    'use',
    'view',
    'vkern'
  ]),
  _e = {
    xlink: 'http://www.w3.org/1999/xlink',
    xml: 'http://www.w3.org/XML/1998/namespace'
  }
function Be (e, t, o) {
  let r = o.length,
    s = t.length,
    n = r,
    l = 0,
    i = 0,
    a = t[s - 1].nextSibling,
    c = null
  for (; l < s || i < n; ) {
    if (t[l] === o[i]) {
      l++, i++
      continue
    }
    for (; t[s - 1] === o[n - 1]; ) s--, n--
    if (s === l) {
      const d = n < r ? (i ? o[i - 1].nextSibling : o[n - i]) : a
      for (; i < n; ) e.insertBefore(o[i++], d)
    } else if (n === i)
      for (; l < s; ) (!c || !c.has(t[l])) && t[l].remove(), l++
    else if (t[l] === o[n - 1] && o[i] === t[s - 1]) {
      const d = t[--s].nextSibling
      e.insertBefore(o[i++], t[l++].nextSibling),
        e.insertBefore(o[--n], d),
        (t[s] = o[n])
    } else {
      if (!c) {
        c = new Map()
        let g = i
        for (; g < n; ) c.set(o[g], g++)
      }
      const d = c.get(t[l])
      if (d != null)
        if (i < d && d < n) {
          let g = l,
            f = 1,
            y
          for (
            ;
            ++g < s && g < n && !((y = c.get(t[g])) == null || y !== d + f);

          )
            f++
          if (f > d - i) {
            const w = t[l]
            for (; i < d; ) e.insertBefore(o[i++], w)
          } else e.replaceChild(o[i++], t[l++])
        } else l++
      else t[l++].remove()
    }
  }
}
const ce = '_$DX_DELEGATE'
function oo (e, t, o, r = {}) {
  let s
  return (
    Te(n => {
      ;(s = n),
        t === document ? e() : Ye(t, e(), t.firstChild ? null : void 0, o)
    }, r.owner),
    () => {
      s(), (t.textContent = '')
    }
  )
}
function ro (e, t, o) {
  let r
  const s = () => {
      const l = document.createElement('template')
      return (l.innerHTML = e), l.content.firstChild
    },
    n = () => (r || (r = s())).cloneNode(!0)
  return (n.cloneNode = n), n
}
function Ve (e, t = window.document) {
  const o = t[ce] || (t[ce] = new Set())
  for (let r = 0, s = e.length; r < s; r++) {
    const n = e[r]
    o.has(n) || (o.add(n), t.addEventListener(n, et))
  }
}
function Y (e, t, o) {
  T(e) || (o == null ? e.removeAttribute(t) : e.setAttribute(t, o))
}
function Ue (e, t, o, r) {
  T(e) || (r == null ? e.removeAttributeNS(t, o) : e.setAttributeNS(t, o, r))
}
function We (e, t, o) {
  T(e) || (o ? e.setAttribute(t, '') : e.removeAttribute(t))
}
function De (e, t) {
  T(e) || (t == null ? e.removeAttribute('class') : (e.className = t))
}
function Fe (e, t, o, r) {
  if (r)
    Array.isArray(o)
      ? ((e[`$$${t}`] = o[0]), (e[`$$${t}Data`] = o[1]))
      : (e[`$$${t}`] = o)
  else if (Array.isArray(o)) {
    const s = o[0]
    e.addEventListener(t, (o[0] = n => s.call(e, o[1], n)))
  } else e.addEventListener(t, o, typeof o != 'function' && o)
}
function He (e, t, o = {}) {
  const r = Object.keys(t || {}),
    s = Object.keys(o)
  let n, l
  for (n = 0, l = s.length; n < l; n++) {
    const i = s[n]
    !i || i === 'undefined' || t[i] || (de(e, i, !1), delete o[i])
  }
  for (n = 0, l = r.length; n < l; n++) {
    const i = r[n],
      a = !!t[i]
    !i || i === 'undefined' || o[i] === a || !a || (de(e, i, !0), (o[i] = a))
  }
  return o
}
function qe (e, t, o) {
  if (!t) return o ? Y(e, 'style') : t
  const r = e.style
  if (typeof t == 'string') return (r.cssText = t)
  typeof o == 'string' && (r.cssText = o = void 0), o || (o = {}), t || (t = {})
  let s, n
  for (n in o) t[n] == null && r.removeProperty(n), delete o[n]
  for (n in t) (s = t[n]), s !== o[n] && (r.setProperty(n, s), (o[n] = s))
  return o
}
function Xe (e, t = {}, o, r) {
  const s = {}
  return (
    r || L(() => (s.children = _(e, t.children, s.children))),
    L(() => typeof t.ref == 'function' && Je(t.ref, e)),
    L(() => Ze(e, t, o, !0, s, !0)),
    s
  )
}
function Je (e, t, o) {
  return xe(() => e(t, o))
}
function Ye (e, t, o, r) {
  if ((o !== void 0 && !r && (r = []), typeof t != 'function'))
    return _(e, t, r, o)
  L(s => _(e, t(), s, o), r)
}
function Ze (e, t, o, r, s = {}, n = !1) {
  t || (t = {})
  for (const l in s)
    if (!(l in t)) {
      if (l === 'children') continue
      s[l] = ue(e, l, null, s[l], o, n, t)
    }
  for (const l in t) {
    if (l === 'children') continue
    const i = t[l]
    s[l] = ue(e, l, i, s[l], o, n, t)
  }
}
function Qe (e) {
  let t, o
  return !T() || !(t = k.registry.get((o = tt())))
    ? e()
    : (k.completed && k.completed.add(t), k.registry.delete(o), t)
}
function T (e) {
  return !!k.context && !k.done && (!e || e.isConnected)
}
function Ke (e) {
  return e.toLowerCase().replace(/-([a-z])/g, (t, o) => o.toUpperCase())
}
function de (e, t, o) {
  const r = t.trim().split(/\s+/)
  for (let s = 0, n = r.length; s < n; s++) e.classList.toggle(r[s], o)
}
function ue (e, t, o, r, s, n, l) {
  let i, a, c, d, g
  if (t === 'style') return qe(e, o, r)
  if (t === 'classList') return He(e, o, r)
  if (o === r) return r
  if (t === 'ref') n || o(e)
  else if (t.slice(0, 3) === 'on:') {
    const f = t.slice(3)
    r && e.removeEventListener(f, r, typeof r != 'function' && r),
      o && e.addEventListener(f, o, typeof o != 'function' && o)
  } else if (t.slice(0, 10) === 'oncapture:') {
    const f = t.slice(10)
    r && e.removeEventListener(f, r, !0), o && e.addEventListener(f, o, !0)
  } else if (t.slice(0, 2) === 'on') {
    const f = t.slice(2).toLowerCase(),
      y = Re.has(f)
    if (!y && r) {
      const w = Array.isArray(r) ? r[0] : r
      e.removeEventListener(f, w)
    }
    ;(y || o) && (Fe(e, f, o, y), y && Ve([f]))
  } else if (t.slice(0, 5) === 'attr:') Y(e, t.slice(5), o)
  else if (t.slice(0, 5) === 'bool:') We(e, t.slice(5), o)
  else if (
    (g = t.slice(0, 5) === 'prop:') ||
    (c = Ge.has(t)) ||
    (!s && ((d = je(t, e.tagName)) || (a = Me.has(t)))) ||
    (i = e.nodeName.includes('-') || 'is' in l)
  ) {
    if (g) (t = t.slice(5)), (a = !0)
    else if (T(e)) return o
    t === 'class' || t === 'className'
      ? De(e, o)
      : i && !a && !c
      ? (e[Ke(t)] = o)
      : (e[d || t] = o)
  } else {
    const f = s && t.indexOf(':') > -1 && _e[t.split(':')[0]]
    f ? Ue(e, f, t, o) : Y(e, $e[t] || t, o)
  }
  return o
}
function et (e) {
  let t = e.target
  const o = `$$${e.type}`,
    r = e.target,
    s = e.currentTarget,
    n = a => Object.defineProperty(e, 'target', { configurable: !0, value: a }),
    l = () => {
      const a = t[o]
      if (a && !t.disabled) {
        const c = t[`${o}Data`]
        if ((c !== void 0 ? a.call(t, c, e) : a.call(t, e), e.cancelBubble))
          return
      }
      return (
        t.host &&
          typeof t.host != 'string' &&
          !t.host._$host &&
          t.contains(e.target) &&
          n(t.host),
        !0
      )
    },
    i = () => {
      for (; l() && (t = t._$host || t.parentNode || t.host); );
    }
  if (
    (Object.defineProperty(e, 'currentTarget', {
      configurable: !0,
      get () {
        return t || document
      }
    }),
    e.composedPath)
  ) {
    const a = e.composedPath()
    n(a[0])
    for (let c = 0; c < a.length - 2 && ((t = a[c]), !!l()); c++) {
      if (t._$host) {
        ;(t = t._$host), i()
        break
      }
      if (t.parentNode === s) break
    }
  } else i()
  n(r)
}
function _ (e, t, o, r, s) {
  const n = T(e)
  if (n) {
    !o && (o = [...e.childNodes])
    let a = []
    for (let c = 0; c < o.length; c++) {
      const d = o[c]
      d.nodeType === 8 && d.data.slice(0, 2) === '!$' ? d.remove() : a.push(d)
    }
    o = a
  }
  for (; typeof o == 'function'; ) o = o()
  if (t === o) return o
  const l = typeof t,
    i = r !== void 0
  if (
    ((e = (i && o[0] && o[0].parentNode) || e),
    l === 'string' || l === 'number')
  ) {
    if (n || (l === 'number' && ((t = t.toString()), t === o))) return o
    if (i) {
      let a = o[0]
      a && a.nodeType === 3
        ? a.data !== t && (a.data = t)
        : (a = document.createTextNode(t)),
        (o = E(e, o, r, a))
    } else
      o !== '' && typeof o == 'string'
        ? (o = e.firstChild.data = t)
        : (o = e.textContent = t)
  } else if (t == null || l === 'boolean') {
    if (n) return o
    o = E(e, o, r)
  } else {
    if (l === 'function')
      return (
        L(() => {
          let a = t()
          for (; typeof a == 'function'; ) a = a()
          o = _(e, a, o, r)
        }),
        () => o
      )
    if (Array.isArray(t)) {
      const a = [],
        c = o && Array.isArray(o)
      if (Z(a, t, o, s)) return L(() => (o = _(e, a, o, r, !0))), () => o
      if (n) {
        if (!a.length) return o
        if (r === void 0) return (o = [...e.childNodes])
        let d = a[0]
        if (d.parentNode !== e) return o
        const g = [d]
        for (; (d = d.nextSibling) !== r; ) g.push(d)
        return (o = g)
      }
      if (a.length === 0) {
        if (((o = E(e, o, r)), i)) return o
      } else
        c ? (o.length === 0 ? fe(e, a, r) : Be(e, o, a)) : (o && E(e), fe(e, a))
      o = a
    } else if (t.nodeType) {
      if (n && t.parentNode) return (o = i ? [t] : t)
      if (Array.isArray(o)) {
        if (i) return (o = E(e, o, r, t))
        E(e, o, null, t)
      } else
        o == null || o === '' || !e.firstChild
          ? e.appendChild(t)
          : e.replaceChild(t, e.firstChild)
      o = t
    }
  }
  return o
}
function Z (e, t, o, r) {
  let s = !1
  for (let n = 0, l = t.length; n < l; n++) {
    let i = t[n],
      a = o && o[e.length],
      c
    if (!(i == null || i === !0 || i === !1))
      if ((c = typeof i) == 'object' && i.nodeType) e.push(i)
      else if (Array.isArray(i)) s = Z(e, i, a) || s
      else if (c === 'function')
        if (r) {
          for (; typeof i == 'function'; ) i = i()
          s = Z(e, Array.isArray(i) ? i : [i], Array.isArray(a) ? a : [a]) || s
        } else e.push(i), (s = !0)
      else {
        const d = String(i)
        a && a.nodeType === 3 && a.data === d
          ? e.push(a)
          : e.push(document.createTextNode(d))
      }
  }
  return s
}
function fe (e, t, o = null) {
  for (let r = 0, s = t.length; r < s; r++) e.insertBefore(t[r], o)
}
function E (e, t, o, r) {
  if (o === void 0) return (e.textContent = '')
  const s = r || document.createTextNode('')
  if (t.length) {
    let n = !1
    for (let l = t.length - 1; l >= 0; l--) {
      const i = t[l]
      if (s !== i) {
        const a = i.parentNode === e
        !n && !l
          ? a
            ? e.replaceChild(s, i)
            : e.insertBefore(s, o)
          : a && i.remove()
      } else n = !0
    }
  } else e.insertBefore(s, o)
  return [s]
}
function tt () {
  return k.getNextContextId()
}
const ot = 'http://www.w3.org/2000/svg'
function rt (e, t = !1) {
  return t ? document.createElementNS(ot, e) : document.createElement(e)
}
function nt (e) {
  const [t, o] = W(e, ['component']),
    r = O(() => t.component)
  return O(() => {
    const s = r()
    switch (typeof s) {
      case 'function':
        return xe(() => s(o))
      case 'string':
        const n = Oe.has(s),
          l = k.context ? Qe() : rt(s, n)
        return Xe(l, o, n), l
    }
  })
}
function no (e) {
  var t
  return typeof ((t = chrome == null ? void 0 : chrome.runtime) == null
    ? void 0
    : t.getURL) != 'function'
    ? e
    : chrome.runtime.getURL(e)
}
function st (e) {
  return (...t) => {
    for (const o of e) o && o(...t)
  }
}
var so = e => (typeof e == 'function' && !e.length ? e() : e)
function io (e, ...t) {
  return typeof e == 'function' ? e(...t) : e
}
function it (...e) {
  return st(e)
}
function lt (e) {
  return Object.prototype.toString.call(e) === '[object String]'
}
function at (e) {
  return typeof e == 'function'
}
function lo (e) {
  return t => `${e()}-${t}`
}
var ct = (e => (
  (e.Escape = 'Escape'),
  (e.Enter = 'Enter'),
  (e.Tab = 'Tab'),
  (e.Space = ' '),
  (e.ArrowDown = 'ArrowDown'),
  (e.ArrowLeft = 'ArrowLeft'),
  (e.ArrowRight = 'ArrowRight'),
  (e.ArrowUp = 'ArrowUp'),
  (e.End = 'End'),
  (e.Home = 'Home'),
  (e.PageDown = 'PageDown'),
  (e.PageUp = 'PageUp'),
  e
))(ct || {})
function dt (e, t) {
  return (
    t && (at(t) ? t(e) : t[0](t[1], e)), e == null ? void 0 : e.defaultPrevented
  )
}
function ao (e) {
  return t => {
    for (const o of e) dt(t, o)
  }
}
function ut (e, t) {
  return D(e, t)
}
var I = new Map(),
  ge = new Set()
function pe () {
  if (typeof window > 'u') return
  const e = o => {
      if (!o.target) return
      let r = I.get(o.target)
      r ||
        ((r = new Set()),
        I.set(o.target, r),
        o.target.addEventListener('transitioncancel', t)),
        r.add(o.propertyName)
    },
    t = o => {
      if (!o.target) return
      const r = I.get(o.target)
      if (
        r &&
        (r.delete(o.propertyName),
        r.size === 0 &&
          (o.target.removeEventListener('transitioncancel', t),
          I.delete(o.target)),
        I.size === 0)
      ) {
        for (const s of ge) s()
        ge.clear()
      }
    }
  document.body.addEventListener('transitionrun', e),
    document.body.addEventListener('transitionend', t)
}
typeof document < 'u' &&
  (document.readyState !== 'loading'
    ? pe()
    : document.addEventListener('DOMContentLoaded', pe))
var co = {
  border: '0',
  clip: 'rect(0 0 0 0)',
  'clip-path': 'inset(50%)',
  height: '1px',
  margin: '0 -1px -1px 0',
  overflow: 'hidden',
  padding: '0',
  position: 'absolute',
  width: '1px',
  'white-space': 'nowrap'
}
function ft (e, t) {
  const [o, r] = Ee(be(t == null ? void 0 : t()))
  return (
    Le(() => {
      var s
      r(
        ((s = e()) == null ? void 0 : s.tagName.toLowerCase()) ||
          be(t == null ? void 0 : t())
      )
    }),
    o
  )
}
function be (e) {
  return lt(e) ? e : void 0
}
function gt (e) {
  const [t, o] = W(e, ['as'])
  if (!t.as)
    throw new Error('[kobalte]: Polymorphic is missing the required `as` prop.')
  return K(
    nt,
    D(o, {
      get component () {
        return t.as
      }
    })
  )
}
var pt = Object.defineProperty,
  bt = (e, t) => {
    for (var o in t) pt(e, o, { get: t[o], enumerable: !0 })
  },
  mt = {}
bt(mt, { Button: () => wt, Root: () => ee })
var ht = ['button', 'color', 'file', 'image', 'reset', 'submit']
function yt (e) {
  const t = e.tagName.toLowerCase()
  return t === 'button'
    ? !0
    : t === 'input' && e.type
    ? ht.indexOf(e.type) !== -1
    : !1
}
function ee (e) {
  let t
  const o = ut({ type: 'button' }, e),
    [r, s] = W(o, ['ref', 'type', 'disabled']),
    n = ft(
      () => t,
      () => 'button'
    ),
    l = O(() => {
      const c = n()
      return c == null ? !1 : yt({ tagName: c, type: r.type })
    }),
    i = O(() => n() === 'input'),
    a = O(
      () => n() === 'a' && (t == null ? void 0 : t.getAttribute('href')) != null
    )
  return K(
    gt,
    D(
      {
        as: 'button',
        ref (c) {
          var d = it(g => (t = g), r.ref)
          typeof d == 'function' && d(c)
        },
        get type () {
          return l() || i() ? r.type : void 0
        },
        get role () {
          return !l() && !a() ? 'button' : void 0
        },
        get tabIndex () {
          return !l() && !a() && !r.disabled ? 0 : void 0
        },
        get disabled () {
          return l() || i() ? r.disabled : void 0
        },
        get 'aria-disabled' () {
          return !l() && !i() && r.disabled ? !0 : void 0
        },
        get 'data-disabled' () {
          return r.disabled ? '' : void 0
        }
      },
      s
    )
  )
}
var wt = ee
function ve (e) {
  var t,
    o,
    r = ''
  if (typeof e == 'string' || typeof e == 'number') r += e
  else if (typeof e == 'object')
    if (Array.isArray(e)) {
      var s = e.length
      for (t = 0; t < s; t++)
        e[t] && (o = ve(e[t])) && (r && (r += ' '), (r += o))
    } else for (o in e) e[o] && (r && (r += ' '), (r += o))
  return r
}
function Ce () {
  for (var e, t, o = 0, r = '', s = arguments.length; o < s; o++)
    (e = arguments[o]) && (t = ve(e)) && (r && (r += ' '), (r += t))
  return r
}
const me = e => (typeof e == 'boolean' ? `${e}` : e === 0 ? '0' : e),
  he = Ce,
  xt = (e, t) => o => {
    var r
    if ((t == null ? void 0 : t.variants) == null)
      return he(
        e,
        o == null ? void 0 : o.class,
        o == null ? void 0 : o.className
      )
    const { variants: s, defaultVariants: n } = t,
      l = Object.keys(s).map(c => {
        const d = o == null ? void 0 : o[c],
          g = n == null ? void 0 : n[c]
        if (d === null) return null
        const f = me(d) || me(g)
        return s[c][f]
      }),
      i =
        o &&
        Object.entries(o).reduce((c, d) => {
          let [g, f] = d
          return f === void 0 || (c[g] = f), c
        }, {}),
      a =
        t == null || (r = t.compoundVariants) === null || r === void 0
          ? void 0
          : r.reduce((c, d) => {
              let { class: g, className: f, ...y } = d
              return Object.entries(y).every(w => {
                let [h, p] = w
                return Array.isArray(p)
                  ? p.includes({ ...n, ...i }[h])
                  : { ...n, ...i }[h] === p
              })
                ? [...c, g, f]
                : c
            }, [])
    return he(
      e,
      l,
      a,
      o == null ? void 0 : o.class,
      o == null ? void 0 : o.className
    )
  },
  te = '-',
  vt = e => {
    const t = At(e),
      { conflictingClassGroups: o, conflictingClassGroupModifiers: r } = e
    return {
      getClassGroupId: l => {
        const i = l.split(te)
        return i[0] === '' && i.length !== 1 && i.shift(), Ae(i, t) || Ct(l)
      },
      getConflictingClassGroupIds: (l, i) => {
        const a = o[l] || []
        return i && r[l] ? [...a, ...r[l]] : a
      }
    }
  },
  Ae = (e, t) => {
    var l
    if (e.length === 0) return t.classGroupId
    const o = e[0],
      r = t.nextPart.get(o),
      s = r ? Ae(e.slice(1), r) : void 0
    if (s) return s
    if (t.validators.length === 0) return
    const n = e.join(te)
    return (l = t.validators.find(({ validator: i }) => i(n))) == null
      ? void 0
      : l.classGroupId
  },
  ye = /^\[(.+)\]$/,
  Ct = e => {
    if (ye.test(e)) {
      const t = ye.exec(e)[1],
        o = t == null ? void 0 : t.substring(0, t.indexOf(':'))
      if (o) return 'arbitrary..' + o
    }
  },
  At = e => {
    const { theme: t, prefix: o } = e,
      r = { nextPart: new Map(), validators: [] }
    return (
      Nt(Object.entries(e.classGroups), o).forEach(([n, l]) => {
        Q(l, r, n, t)
      }),
      r
    )
  },
  Q = (e, t, o, r) => {
    e.forEach(s => {
      if (typeof s == 'string') {
        const n = s === '' ? t : we(t, s)
        n.classGroupId = o
        return
      }
      if (typeof s == 'function') {
        if (St(s)) {
          Q(s(r), t, o, r)
          return
        }
        t.validators.push({ validator: s, classGroupId: o })
        return
      }
      Object.entries(s).forEach(([n, l]) => {
        Q(l, we(t, n), o, r)
      })
    })
  },
  we = (e, t) => {
    let o = e
    return (
      t.split(te).forEach(r => {
        o.nextPart.has(r) ||
          o.nextPart.set(r, { nextPart: new Map(), validators: [] }),
          (o = o.nextPart.get(r))
      }),
      o
    )
  },
  St = e => e.isThemeGetter,
  Nt = (e, t) =>
    t
      ? e.map(([o, r]) => {
          const s = r.map(n =>
            typeof n == 'string'
              ? t + n
              : typeof n == 'object'
              ? Object.fromEntries(
                  Object.entries(n).map(([l, i]) => [t + l, i])
                )
              : n
          )
          return [o, s]
        })
      : e,
  kt = e => {
    if (e < 1) return { get: () => {}, set: () => {} }
    let t = 0,
      o = new Map(),
      r = new Map()
    const s = (n, l) => {
      o.set(n, l), t++, t > e && ((t = 0), (r = o), (o = new Map()))
    }
    return {
      get (n) {
        let l = o.get(n)
        if (l !== void 0) return l
        if ((l = r.get(n)) !== void 0) return s(n, l), l
      },
      set (n, l) {
        o.has(n) ? o.set(n, l) : s(n, l)
      }
    }
  },
  Se = '!',
  Pt = e => {
    const { separator: t, experimentalParseClassName: o } = e,
      r = t.length === 1,
      s = t[0],
      n = t.length,
      l = i => {
        const a = []
        let c = 0,
          d = 0,
          g
        for (let p = 0; p < i.length; p++) {
          let x = i[p]
          if (c === 0) {
            if (x === s && (r || i.slice(p, p + n) === t)) {
              a.push(i.slice(d, p)), (d = p + n)
              continue
            }
            if (x === '/') {
              g = p
              continue
            }
          }
          x === '[' ? c++ : x === ']' && c--
        }
        const f = a.length === 0 ? i : i.substring(d),
          y = f.startsWith(Se),
          w = y ? f.substring(1) : f,
          h = g && g > d ? g - d : void 0
        return {
          modifiers: a,
          hasImportantModifier: y,
          baseClassName: w,
          maybePostfixModifierPosition: h
        }
      }
    return o ? i => o({ className: i, parseClassName: l }) : l
  },
  Tt = e => {
    if (e.length <= 1) return e
    const t = []
    let o = []
    return (
      e.forEach(r => {
        r[0] === '[' ? (t.push(...o.sort(), r), (o = [])) : o.push(r)
      }),
      t.push(...o.sort()),
      t
    )
  },
  Et = e => ({ cache: kt(e.cacheSize), parseClassName: Pt(e), ...vt(e) }),
  Lt = /\s+/,
  zt = (e, t) => {
    const {
        parseClassName: o,
        getClassGroupId: r,
        getConflictingClassGroupIds: s
      } = t,
      n = [],
      l = e.trim().split(Lt)
    let i = ''
    for (let a = l.length - 1; a >= 0; a -= 1) {
      const c = l[a],
        {
          modifiers: d,
          hasImportantModifier: g,
          baseClassName: f,
          maybePostfixModifierPosition: y
        } = o(c)
      let w = !!y,
        h = r(w ? f.substring(0, y) : f)
      if (!h) {
        if (!w) {
          i = c + (i.length > 0 ? ' ' + i : i)
          continue
        }
        if (((h = r(f)), !h)) {
          i = c + (i.length > 0 ? ' ' + i : i)
          continue
        }
        w = !1
      }
      const p = Tt(d).join(':'),
        x = g ? p + Se : p,
        v = x + h
      if (n.includes(v)) continue
      n.push(v)
      const G = s(h, w)
      for (let P = 0; P < G.length; ++P) {
        const B = G[P]
        n.push(x + B)
      }
      i = c + (i.length > 0 ? ' ' + i : i)
    }
    return i
  }
function Mt () {
  let e = 0,
    t,
    o,
    r = ''
  for (; e < arguments.length; )
    (t = arguments[e++]) && (o = Ne(t)) && (r && (r += ' '), (r += o))
  return r
}
const Ne = e => {
  if (typeof e == 'string') return e
  let t,
    o = ''
  for (let r = 0; r < e.length; r++)
    e[r] && (t = Ne(e[r])) && (o && (o += ' '), (o += t))
  return o
}
function Gt (e, ...t) {
  let o,
    r,
    s,
    n = l
  function l (a) {
    const c = t.reduce((d, g) => g(d), e())
    return (o = Et(c)), (r = o.cache.get), (s = o.cache.set), (n = i), i(a)
  }
  function i (a) {
    const c = r(a)
    if (c) return c
    const d = zt(a, o)
    return s(a, d), d
  }
  return function () {
    return n(Mt.apply(null, arguments))
  }
}
const b = e => {
    const t = o => o[e] || []
    return (t.isThemeGetter = !0), t
  },
  ke = /^\[(?:([a-z-]+):)?(.+)\]$/i,
  $t = /^\d+\/\d+$/,
  It = new Set(['px', 'full', 'screen']),
  jt = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
  Rt =
    /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
  Ot = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,
  _t = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
  Bt =
    /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
  A = e => z(e) || It.has(e) || $t.test(e),
  S = e => M(e, 'length', Xt),
  z = e => !!e && !Number.isNaN(Number(e)),
  J = e => M(e, 'number', z),
  j = e => !!e && Number.isInteger(Number(e)),
  Vt = e => e.endsWith('%') && z(e.slice(0, -1)),
  u = e => ke.test(e),
  N = e => jt.test(e),
  Ut = new Set(['length', 'size', 'percentage']),
  Wt = e => M(e, Ut, Pe),
  Dt = e => M(e, 'position', Pe),
  Ft = new Set(['image', 'url']),
  Ht = e => M(e, Ft, Yt),
  qt = e => M(e, '', Jt),
  R = () => !0,
  M = (e, t, o) => {
    const r = ke.exec(e)
    return r
      ? r[1]
        ? typeof t == 'string'
          ? r[1] === t
          : t.has(r[1])
        : o(r[2])
      : !1
  },
  Xt = e => Rt.test(e) && !Ot.test(e),
  Pe = () => !1,
  Jt = e => _t.test(e),
  Yt = e => Bt.test(e),
  Zt = () => {
    const e = b('colors'),
      t = b('spacing'),
      o = b('blur'),
      r = b('brightness'),
      s = b('borderColor'),
      n = b('borderRadius'),
      l = b('borderSpacing'),
      i = b('borderWidth'),
      a = b('contrast'),
      c = b('grayscale'),
      d = b('hueRotate'),
      g = b('invert'),
      f = b('gap'),
      y = b('gradientColorStops'),
      w = b('gradientColorStopPositions'),
      h = b('inset'),
      p = b('margin'),
      x = b('opacity'),
      v = b('padding'),
      G = b('saturate'),
      P = b('scale'),
      B = b('sepia'),
      oe = b('skew'),
      re = b('space'),
      ne = b('translate'),
      F = () => ['auto', 'contain', 'none'],
      H = () => ['auto', 'hidden', 'clip', 'visible', 'scroll'],
      q = () => ['auto', u, t],
      m = () => [u, t],
      se = () => ['', A, S],
      V = () => ['auto', z, u],
      ie = () => [
        'bottom',
        'center',
        'left',
        'left-bottom',
        'left-top',
        'right',
        'right-bottom',
        'right-top',
        'top'
      ],
      U = () => ['solid', 'dashed', 'dotted', 'double', 'none'],
      le = () => [
        'normal',
        'multiply',
        'screen',
        'overlay',
        'darken',
        'lighten',
        'color-dodge',
        'color-burn',
        'hard-light',
        'soft-light',
        'difference',
        'exclusion',
        'hue',
        'saturation',
        'color',
        'luminosity'
      ],
      X = () => [
        'start',
        'end',
        'center',
        'between',
        'around',
        'evenly',
        'stretch'
      ],
      $ = () => ['', '0', u],
      ae = () => [
        'auto',
        'avoid',
        'all',
        'avoid-page',
        'page',
        'left',
        'right',
        'column'
      ],
      C = () => [z, u]
    return {
      cacheSize: 500,
      separator: ':',
      theme: {
        colors: [R],
        spacing: [A, S],
        blur: ['none', '', N, u],
        brightness: C(),
        borderColor: [e],
        borderRadius: ['none', '', 'full', N, u],
        borderSpacing: m(),
        borderWidth: se(),
        contrast: C(),
        grayscale: $(),
        hueRotate: C(),
        invert: $(),
        gap: m(),
        gradientColorStops: [e],
        gradientColorStopPositions: [Vt, S],
        inset: q(),
        margin: q(),
        opacity: C(),
        padding: m(),
        saturate: C(),
        scale: C(),
        sepia: $(),
        skew: C(),
        space: m(),
        translate: m()
      },
      classGroups: {
        aspect: [{ aspect: ['auto', 'square', 'video', u] }],
        container: ['container'],
        columns: [{ columns: [N] }],
        'break-after': [{ 'break-after': ae() }],
        'break-before': [{ 'break-before': ae() }],
        'break-inside': [
          { 'break-inside': ['auto', 'avoid', 'avoid-page', 'avoid-column'] }
        ],
        'box-decoration': [{ 'box-decoration': ['slice', 'clone'] }],
        box: [{ box: ['border', 'content'] }],
        display: [
          'block',
          'inline-block',
          'inline',
          'flex',
          'inline-flex',
          'table',
          'inline-table',
          'table-caption',
          'table-cell',
          'table-column',
          'table-column-group',
          'table-footer-group',
          'table-header-group',
          'table-row-group',
          'table-row',
          'flow-root',
          'grid',
          'inline-grid',
          'contents',
          'list-item',
          'hidden'
        ],
        float: [{ float: ['right', 'left', 'none', 'start', 'end'] }],
        clear: [{ clear: ['left', 'right', 'both', 'none', 'start', 'end'] }],
        isolation: ['isolate', 'isolation-auto'],
        'object-fit': [
          { object: ['contain', 'cover', 'fill', 'none', 'scale-down'] }
        ],
        'object-position': [{ object: [...ie(), u] }],
        overflow: [{ overflow: H() }],
        'overflow-x': [{ 'overflow-x': H() }],
        'overflow-y': [{ 'overflow-y': H() }],
        overscroll: [{ overscroll: F() }],
        'overscroll-x': [{ 'overscroll-x': F() }],
        'overscroll-y': [{ 'overscroll-y': F() }],
        position: ['static', 'fixed', 'absolute', 'relative', 'sticky'],
        inset: [{ inset: [h] }],
        'inset-x': [{ 'inset-x': [h] }],
        'inset-y': [{ 'inset-y': [h] }],
        start: [{ start: [h] }],
        end: [{ end: [h] }],
        top: [{ top: [h] }],
        right: [{ right: [h] }],
        bottom: [{ bottom: [h] }],
        left: [{ left: [h] }],
        visibility: ['visible', 'invisible', 'collapse'],
        z: [{ z: ['auto', j, u] }],
        basis: [{ basis: q() }],
        'flex-direction': [
          { flex: ['row', 'row-reverse', 'col', 'col-reverse'] }
        ],
        'flex-wrap': [{ flex: ['wrap', 'wrap-reverse', 'nowrap'] }],
        flex: [{ flex: ['1', 'auto', 'initial', 'none', u] }],
        grow: [{ grow: $() }],
        shrink: [{ shrink: $() }],
        order: [{ order: ['first', 'last', 'none', j, u] }],
        'grid-cols': [{ 'grid-cols': [R] }],
        'col-start-end': [{ col: ['auto', { span: ['full', j, u] }, u] }],
        'col-start': [{ 'col-start': V() }],
        'col-end': [{ 'col-end': V() }],
        'grid-rows': [{ 'grid-rows': [R] }],
        'row-start-end': [{ row: ['auto', { span: [j, u] }, u] }],
        'row-start': [{ 'row-start': V() }],
        'row-end': [{ 'row-end': V() }],
        'grid-flow': [
          { 'grid-flow': ['row', 'col', 'dense', 'row-dense', 'col-dense'] }
        ],
        'auto-cols': [{ 'auto-cols': ['auto', 'min', 'max', 'fr', u] }],
        'auto-rows': [{ 'auto-rows': ['auto', 'min', 'max', 'fr', u] }],
        gap: [{ gap: [f] }],
        'gap-x': [{ 'gap-x': [f] }],
        'gap-y': [{ 'gap-y': [f] }],
        'justify-content': [{ justify: ['normal', ...X()] }],
        'justify-items': [
          { 'justify-items': ['start', 'end', 'center', 'stretch'] }
        ],
        'justify-self': [
          { 'justify-self': ['auto', 'start', 'end', 'center', 'stretch'] }
        ],
        'align-content': [{ content: ['normal', ...X(), 'baseline'] }],
        'align-items': [
          { items: ['start', 'end', 'center', 'baseline', 'stretch'] }
        ],
        'align-self': [
          { self: ['auto', 'start', 'end', 'center', 'stretch', 'baseline'] }
        ],
        'place-content': [{ 'place-content': [...X(), 'baseline'] }],
        'place-items': [
          { 'place-items': ['start', 'end', 'center', 'baseline', 'stretch'] }
        ],
        'place-self': [
          { 'place-self': ['auto', 'start', 'end', 'center', 'stretch'] }
        ],
        p: [{ p: [v] }],
        px: [{ px: [v] }],
        py: [{ py: [v] }],
        ps: [{ ps: [v] }],
        pe: [{ pe: [v] }],
        pt: [{ pt: [v] }],
        pr: [{ pr: [v] }],
        pb: [{ pb: [v] }],
        pl: [{ pl: [v] }],
        m: [{ m: [p] }],
        mx: [{ mx: [p] }],
        my: [{ my: [p] }],
        ms: [{ ms: [p] }],
        me: [{ me: [p] }],
        mt: [{ mt: [p] }],
        mr: [{ mr: [p] }],
        mb: [{ mb: [p] }],
        ml: [{ ml: [p] }],
        'space-x': [{ 'space-x': [re] }],
        'space-x-reverse': ['space-x-reverse'],
        'space-y': [{ 'space-y': [re] }],
        'space-y-reverse': ['space-y-reverse'],
        w: [{ w: ['auto', 'min', 'max', 'fit', 'svw', 'lvw', 'dvw', u, t] }],
        'min-w': [{ 'min-w': [u, t, 'min', 'max', 'fit'] }],
        'max-w': [
          {
            'max-w': [
              u,
              t,
              'none',
              'full',
              'min',
              'max',
              'fit',
              'prose',
              { screen: [N] },
              N
            ]
          }
        ],
        h: [{ h: [u, t, 'auto', 'min', 'max', 'fit', 'svh', 'lvh', 'dvh'] }],
        'min-h': [
          { 'min-h': [u, t, 'min', 'max', 'fit', 'svh', 'lvh', 'dvh'] }
        ],
        'max-h': [
          { 'max-h': [u, t, 'min', 'max', 'fit', 'svh', 'lvh', 'dvh'] }
        ],
        size: [{ size: [u, t, 'auto', 'min', 'max', 'fit'] }],
        'font-size': [{ text: ['base', N, S] }],
        'font-smoothing': ['antialiased', 'subpixel-antialiased'],
        'font-style': ['italic', 'not-italic'],
        'font-weight': [
          {
            font: [
              'thin',
              'extralight',
              'light',
              'normal',
              'medium',
              'semibold',
              'bold',
              'extrabold',
              'black',
              J
            ]
          }
        ],
        'font-family': [{ font: [R] }],
        'fvn-normal': ['normal-nums'],
        'fvn-ordinal': ['ordinal'],
        'fvn-slashed-zero': ['slashed-zero'],
        'fvn-figure': ['lining-nums', 'oldstyle-nums'],
        'fvn-spacing': ['proportional-nums', 'tabular-nums'],
        'fvn-fraction': ['diagonal-fractions', 'stacked-fractions'],
        tracking: [
          {
            tracking: [
              'tighter',
              'tight',
              'normal',
              'wide',
              'wider',
              'widest',
              u
            ]
          }
        ],
        'line-clamp': [{ 'line-clamp': ['none', z, J] }],
        leading: [
          {
            leading: [
              'none',
              'tight',
              'snug',
              'normal',
              'relaxed',
              'loose',
              A,
              u
            ]
          }
        ],
        'list-image': [{ 'list-image': ['none', u] }],
        'list-style-type': [{ list: ['none', 'disc', 'decimal', u] }],
        'list-style-position': [{ list: ['inside', 'outside'] }],
        'placeholder-color': [{ placeholder: [e] }],
        'placeholder-opacity': [{ 'placeholder-opacity': [x] }],
        'text-alignment': [
          { text: ['left', 'center', 'right', 'justify', 'start', 'end'] }
        ],
        'text-color': [{ text: [e] }],
        'text-opacity': [{ 'text-opacity': [x] }],
        'text-decoration': [
          'underline',
          'overline',
          'line-through',
          'no-underline'
        ],
        'text-decoration-style': [{ decoration: [...U(), 'wavy'] }],
        'text-decoration-thickness': [
          { decoration: ['auto', 'from-font', A, S] }
        ],
        'underline-offset': [{ 'underline-offset': ['auto', A, u] }],
        'text-decoration-color': [{ decoration: [e] }],
        'text-transform': [
          'uppercase',
          'lowercase',
          'capitalize',
          'normal-case'
        ],
        'text-overflow': ['truncate', 'text-ellipsis', 'text-clip'],
        'text-wrap': [{ text: ['wrap', 'nowrap', 'balance', 'pretty'] }],
        indent: [{ indent: m() }],
        'vertical-align': [
          {
            align: [
              'baseline',
              'top',
              'middle',
              'bottom',
              'text-top',
              'text-bottom',
              'sub',
              'super',
              u
            ]
          }
        ],
        whitespace: [
          {
            whitespace: [
              'normal',
              'nowrap',
              'pre',
              'pre-line',
              'pre-wrap',
              'break-spaces'
            ]
          }
        ],
        break: [{ break: ['normal', 'words', 'all', 'keep'] }],
        hyphens: [{ hyphens: ['none', 'manual', 'auto'] }],
        content: [{ content: ['none', u] }],
        'bg-attachment': [{ bg: ['fixed', 'local', 'scroll'] }],
        'bg-clip': [{ 'bg-clip': ['border', 'padding', 'content', 'text'] }],
        'bg-opacity': [{ 'bg-opacity': [x] }],
        'bg-origin': [{ 'bg-origin': ['border', 'padding', 'content'] }],
        'bg-position': [{ bg: [...ie(), Dt] }],
        'bg-repeat': [
          { bg: ['no-repeat', { repeat: ['', 'x', 'y', 'round', 'space'] }] }
        ],
        'bg-size': [{ bg: ['auto', 'cover', 'contain', Wt] }],
        'bg-image': [
          {
            bg: [
              'none',
              { 'gradient-to': ['t', 'tr', 'r', 'br', 'b', 'bl', 'l', 'tl'] },
              Ht
            ]
          }
        ],
        'bg-color': [{ bg: [e] }],
        'gradient-from-pos': [{ from: [w] }],
        'gradient-via-pos': [{ via: [w] }],
        'gradient-to-pos': [{ to: [w] }],
        'gradient-from': [{ from: [y] }],
        'gradient-via': [{ via: [y] }],
        'gradient-to': [{ to: [y] }],
        rounded: [{ rounded: [n] }],
        'rounded-s': [{ 'rounded-s': [n] }],
        'rounded-e': [{ 'rounded-e': [n] }],
        'rounded-t': [{ 'rounded-t': [n] }],
        'rounded-r': [{ 'rounded-r': [n] }],
        'rounded-b': [{ 'rounded-b': [n] }],
        'rounded-l': [{ 'rounded-l': [n] }],
        'rounded-ss': [{ 'rounded-ss': [n] }],
        'rounded-se': [{ 'rounded-se': [n] }],
        'rounded-ee': [{ 'rounded-ee': [n] }],
        'rounded-es': [{ 'rounded-es': [n] }],
        'rounded-tl': [{ 'rounded-tl': [n] }],
        'rounded-tr': [{ 'rounded-tr': [n] }],
        'rounded-br': [{ 'rounded-br': [n] }],
        'rounded-bl': [{ 'rounded-bl': [n] }],
        'border-w': [{ border: [i] }],
        'border-w-x': [{ 'border-x': [i] }],
        'border-w-y': [{ 'border-y': [i] }],
        'border-w-s': [{ 'border-s': [i] }],
        'border-w-e': [{ 'border-e': [i] }],
        'border-w-t': [{ 'border-t': [i] }],
        'border-w-r': [{ 'border-r': [i] }],
        'border-w-b': [{ 'border-b': [i] }],
        'border-w-l': [{ 'border-l': [i] }],
        'border-opacity': [{ 'border-opacity': [x] }],
        'border-style': [{ border: [...U(), 'hidden'] }],
        'divide-x': [{ 'divide-x': [i] }],
        'divide-x-reverse': ['divide-x-reverse'],
        'divide-y': [{ 'divide-y': [i] }],
        'divide-y-reverse': ['divide-y-reverse'],
        'divide-opacity': [{ 'divide-opacity': [x] }],
        'divide-style': [{ divide: U() }],
        'border-color': [{ border: [s] }],
        'border-color-x': [{ 'border-x': [s] }],
        'border-color-y': [{ 'border-y': [s] }],
        'border-color-s': [{ 'border-s': [s] }],
        'border-color-e': [{ 'border-e': [s] }],
        'border-color-t': [{ 'border-t': [s] }],
        'border-color-r': [{ 'border-r': [s] }],
        'border-color-b': [{ 'border-b': [s] }],
        'border-color-l': [{ 'border-l': [s] }],
        'divide-color': [{ divide: [s] }],
        'outline-style': [{ outline: ['', ...U()] }],
        'outline-offset': [{ 'outline-offset': [A, u] }],
        'outline-w': [{ outline: [A, S] }],
        'outline-color': [{ outline: [e] }],
        'ring-w': [{ ring: se() }],
        'ring-w-inset': ['ring-inset'],
        'ring-color': [{ ring: [e] }],
        'ring-opacity': [{ 'ring-opacity': [x] }],
        'ring-offset-w': [{ 'ring-offset': [A, S] }],
        'ring-offset-color': [{ 'ring-offset': [e] }],
        shadow: [{ shadow: ['', 'inner', 'none', N, qt] }],
        'shadow-color': [{ shadow: [R] }],
        opacity: [{ opacity: [x] }],
        'mix-blend': [
          { 'mix-blend': [...le(), 'plus-lighter', 'plus-darker'] }
        ],
        'bg-blend': [{ 'bg-blend': le() }],
        filter: [{ filter: ['', 'none'] }],
        blur: [{ blur: [o] }],
        brightness: [{ brightness: [r] }],
        contrast: [{ contrast: [a] }],
        'drop-shadow': [{ 'drop-shadow': ['', 'none', N, u] }],
        grayscale: [{ grayscale: [c] }],
        'hue-rotate': [{ 'hue-rotate': [d] }],
        invert: [{ invert: [g] }],
        saturate: [{ saturate: [G] }],
        sepia: [{ sepia: [B] }],
        'backdrop-filter': [{ 'backdrop-filter': ['', 'none'] }],
        'backdrop-blur': [{ 'backdrop-blur': [o] }],
        'backdrop-brightness': [{ 'backdrop-brightness': [r] }],
        'backdrop-contrast': [{ 'backdrop-contrast': [a] }],
        'backdrop-grayscale': [{ 'backdrop-grayscale': [c] }],
        'backdrop-hue-rotate': [{ 'backdrop-hue-rotate': [d] }],
        'backdrop-invert': [{ 'backdrop-invert': [g] }],
        'backdrop-opacity': [{ 'backdrop-opacity': [x] }],
        'backdrop-saturate': [{ 'backdrop-saturate': [G] }],
        'backdrop-sepia': [{ 'backdrop-sepia': [B] }],
        'border-collapse': [{ border: ['collapse', 'separate'] }],
        'border-spacing': [{ 'border-spacing': [l] }],
        'border-spacing-x': [{ 'border-spacing-x': [l] }],
        'border-spacing-y': [{ 'border-spacing-y': [l] }],
        'table-layout': [{ table: ['auto', 'fixed'] }],
        caption: [{ caption: ['top', 'bottom'] }],
        transition: [
          {
            transition: [
              'none',
              'all',
              '',
              'colors',
              'opacity',
              'shadow',
              'transform',
              u
            ]
          }
        ],
        duration: [{ duration: C() }],
        ease: [{ ease: ['linear', 'in', 'out', 'in-out', u] }],
        delay: [{ delay: C() }],
        animate: [{ animate: ['none', 'spin', 'ping', 'pulse', 'bounce', u] }],
        transform: [{ transform: ['', 'gpu', 'none'] }],
        scale: [{ scale: [P] }],
        'scale-x': [{ 'scale-x': [P] }],
        'scale-y': [{ 'scale-y': [P] }],
        rotate: [{ rotate: [j, u] }],
        'translate-x': [{ 'translate-x': [ne] }],
        'translate-y': [{ 'translate-y': [ne] }],
        'skew-x': [{ 'skew-x': [oe] }],
        'skew-y': [{ 'skew-y': [oe] }],
        'transform-origin': [
          {
            origin: [
              'center',
              'top',
              'top-right',
              'right',
              'bottom-right',
              'bottom',
              'bottom-left',
              'left',
              'top-left',
              u
            ]
          }
        ],
        accent: [{ accent: ['auto', e] }],
        appearance: [{ appearance: ['none', 'auto'] }],
        cursor: [
          {
            cursor: [
              'auto',
              'default',
              'pointer',
              'wait',
              'text',
              'move',
              'help',
              'not-allowed',
              'none',
              'context-menu',
              'progress',
              'cell',
              'crosshair',
              'vertical-text',
              'alias',
              'copy',
              'no-drop',
              'grab',
              'grabbing',
              'all-scroll',
              'col-resize',
              'row-resize',
              'n-resize',
              'e-resize',
              's-resize',
              'w-resize',
              'ne-resize',
              'nw-resize',
              'se-resize',
              'sw-resize',
              'ew-resize',
              'ns-resize',
              'nesw-resize',
              'nwse-resize',
              'zoom-in',
              'zoom-out',
              u
            ]
          }
        ],
        'caret-color': [{ caret: [e] }],
        'pointer-events': [{ 'pointer-events': ['none', 'auto'] }],
        resize: [{ resize: ['none', 'y', 'x', ''] }],
        'scroll-behavior': [{ scroll: ['auto', 'smooth'] }],
        'scroll-m': [{ 'scroll-m': m() }],
        'scroll-mx': [{ 'scroll-mx': m() }],
        'scroll-my': [{ 'scroll-my': m() }],
        'scroll-ms': [{ 'scroll-ms': m() }],
        'scroll-me': [{ 'scroll-me': m() }],
        'scroll-mt': [{ 'scroll-mt': m() }],
        'scroll-mr': [{ 'scroll-mr': m() }],
        'scroll-mb': [{ 'scroll-mb': m() }],
        'scroll-ml': [{ 'scroll-ml': m() }],
        'scroll-p': [{ 'scroll-p': m() }],
        'scroll-px': [{ 'scroll-px': m() }],
        'scroll-py': [{ 'scroll-py': m() }],
        'scroll-ps': [{ 'scroll-ps': m() }],
        'scroll-pe': [{ 'scroll-pe': m() }],
        'scroll-pt': [{ 'scroll-pt': m() }],
        'scroll-pr': [{ 'scroll-pr': m() }],
        'scroll-pb': [{ 'scroll-pb': m() }],
        'scroll-pl': [{ 'scroll-pl': m() }],
        'snap-align': [{ snap: ['start', 'end', 'center', 'align-none'] }],
        'snap-stop': [{ snap: ['normal', 'always'] }],
        'snap-type': [{ snap: ['none', 'x', 'y', 'both'] }],
        'snap-strictness': [{ snap: ['mandatory', 'proximity'] }],
        touch: [{ touch: ['auto', 'none', 'manipulation'] }],
        'touch-x': [{ 'touch-pan': ['x', 'left', 'right'] }],
        'touch-y': [{ 'touch-pan': ['y', 'up', 'down'] }],
        'touch-pz': ['touch-pinch-zoom'],
        select: [{ select: ['none', 'text', 'all', 'auto'] }],
        'will-change': [
          { 'will-change': ['auto', 'scroll', 'contents', 'transform', u] }
        ],
        fill: [{ fill: [e, 'none'] }],
        'stroke-w': [{ stroke: [A, S, J] }],
        stroke: [{ stroke: [e, 'none'] }],
        sr: ['sr-only', 'not-sr-only'],
        'forced-color-adjust': [{ 'forced-color-adjust': ['auto', 'none'] }]
      },
      conflictingClassGroups: {
        overflow: ['overflow-x', 'overflow-y'],
        overscroll: ['overscroll-x', 'overscroll-y'],
        inset: [
          'inset-x',
          'inset-y',
          'start',
          'end',
          'top',
          'right',
          'bottom',
          'left'
        ],
        'inset-x': ['right', 'left'],
        'inset-y': ['top', 'bottom'],
        flex: ['basis', 'grow', 'shrink'],
        gap: ['gap-x', 'gap-y'],
        p: ['px', 'py', 'ps', 'pe', 'pt', 'pr', 'pb', 'pl'],
        px: ['pr', 'pl'],
        py: ['pt', 'pb'],
        m: ['mx', 'my', 'ms', 'me', 'mt', 'mr', 'mb', 'ml'],
        mx: ['mr', 'ml'],
        my: ['mt', 'mb'],
        size: ['w', 'h'],
        'font-size': ['leading'],
        'fvn-normal': [
          'fvn-ordinal',
          'fvn-slashed-zero',
          'fvn-figure',
          'fvn-spacing',
          'fvn-fraction'
        ],
        'fvn-ordinal': ['fvn-normal'],
        'fvn-slashed-zero': ['fvn-normal'],
        'fvn-figure': ['fvn-normal'],
        'fvn-spacing': ['fvn-normal'],
        'fvn-fraction': ['fvn-normal'],
        'line-clamp': ['display', 'overflow'],
        rounded: [
          'rounded-s',
          'rounded-e',
          'rounded-t',
          'rounded-r',
          'rounded-b',
          'rounded-l',
          'rounded-ss',
          'rounded-se',
          'rounded-ee',
          'rounded-es',
          'rounded-tl',
          'rounded-tr',
          'rounded-br',
          'rounded-bl'
        ],
        'rounded-s': ['rounded-ss', 'rounded-es'],
        'rounded-e': ['rounded-se', 'rounded-ee'],
        'rounded-t': ['rounded-tl', 'rounded-tr'],
        'rounded-r': ['rounded-tr', 'rounded-br'],
        'rounded-b': ['rounded-br', 'rounded-bl'],
        'rounded-l': ['rounded-tl', 'rounded-bl'],
        'border-spacing': ['border-spacing-x', 'border-spacing-y'],
        'border-w': [
          'border-w-s',
          'border-w-e',
          'border-w-t',
          'border-w-r',
          'border-w-b',
          'border-w-l'
        ],
        'border-w-x': ['border-w-r', 'border-w-l'],
        'border-w-y': ['border-w-t', 'border-w-b'],
        'border-color': [
          'border-color-s',
          'border-color-e',
          'border-color-t',
          'border-color-r',
          'border-color-b',
          'border-color-l'
        ],
        'border-color-x': ['border-color-r', 'border-color-l'],
        'border-color-y': ['border-color-t', 'border-color-b'],
        'scroll-m': [
          'scroll-mx',
          'scroll-my',
          'scroll-ms',
          'scroll-me',
          'scroll-mt',
          'scroll-mr',
          'scroll-mb',
          'scroll-ml'
        ],
        'scroll-mx': ['scroll-mr', 'scroll-ml'],
        'scroll-my': ['scroll-mt', 'scroll-mb'],
        'scroll-p': [
          'scroll-px',
          'scroll-py',
          'scroll-ps',
          'scroll-pe',
          'scroll-pt',
          'scroll-pr',
          'scroll-pb',
          'scroll-pl'
        ],
        'scroll-px': ['scroll-pr', 'scroll-pl'],
        'scroll-py': ['scroll-pt', 'scroll-pb'],
        touch: ['touch-x', 'touch-y', 'touch-pz'],
        'touch-x': ['touch'],
        'touch-y': ['touch'],
        'touch-pz': ['touch']
      },
      conflictingClassGroupModifiers: { 'font-size': ['leading'] }
    }
  },
  Qt = Gt(Zt)
function Kt (...e) {
  return Qt(Ce(e))
}
const eo = xt(
    'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0',
    {
      variants: {
        variant: {
          default:
            'bg-primary text-primary-foreground shadow hover:bg-primary/90',
          destructive:
            'bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90',
          success:
            'bg-success text-success-foreground shadow-sm hover:bg-success/90',
          outline:
            'border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground',
          secondary:
            'bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80',
          ghost: 'hover:bg-accent hover:text-accent-foreground',
          link: 'text-primary underline-offset-4 hover:underline'
        },
        size: {
          default: 'h-9 px-4 py-2',
          sm: 'h-8 rounded-md px-3 text-xs',
          lg: 'h-10 rounded-md px-8',
          icon: 'h-9 w-9'
        }
      },
      defaultVariants: { variant: 'default', size: 'default' }
    }
  ),
  uo = e => {
    const [t, o] = W(e, ['variant', 'size', 'class'])
    return K(
      ee,
      D(
        {
          get class () {
            return Kt(eo({ variant: t.variant, size: t.size }), t.class)
          }
        },
        o
      )
    )
  }
export {
  uo as B,
  nt as D,
  ct as E,
  gt as P,
  bt as _,
  no as a,
  Y as b,
  De as c,
  Ve as d,
  Kt as e,
  xt as f,
  so as g,
  ft as h,
  Ye as i,
  it as j,
  lo as k,
  io as l,
  ut as m,
  at as n,
  dt as o,
  ao as p,
  qe as q,
  oo as r,
  Xe as s,
  ro as t,
  Je as u,
  co as v,
  Fe as w
}
