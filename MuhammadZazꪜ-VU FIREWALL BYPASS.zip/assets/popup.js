import {
  s as et,
  t as C,
  e as D,
  f as tt,
  m as k,
  g as y,
  P as M,
  h as nt,
  j as G,
  k as se,
  l as rt,
  _ as oe,
  v as at,
  n as it,
  o as z,
  E as st,
  p as Te,
  u as ot,
  i as m,
  a as ut,
  B as A,
  c as Ce,
  r as ct
} from './chunks/cIluDXEb.js'
import {
  p as S,
  m as v,
  n as ue,
  c as P,
  f as _,
  x as U,
  y as Z,
  g as F,
  o as L,
  b as o,
  S as E,
  z as ce,
  h as dt,
  B as lt,
  D as ft,
  u as gt,
  i as ht,
  k as N,
  M as X,
  d as Pe,
  v as mt,
  j as bt,
  a as yt,
  C as vt
} from './chunks/D_rTIZ-0.js'
import {
  c as wt,
  T as xt,
  S as ie,
  u as pt,
  t as te
} from './chunks/Be1X0ANG.js'
const Ee = 6048e5,
  St = 864e5,
  ke = Symbol.for('constructDateFrom')
function W (e, t) {
  return typeof e == 'function'
    ? e(t)
    : e && typeof e == 'object' && ke in e
    ? e[ke](t)
    : e instanceof Date
    ? new e.constructor(t)
    : new Date(t)
}
function I (e, t) {
  return W(t || e, e)
}
let Ct = {}
function ee () {
  return Ct
}
function Q (e, t) {
  var u, s, d, l
  const n = ee(),
    r =
      (t == null ? void 0 : t.weekStartsOn) ??
      ((s = (u = t == null ? void 0 : t.locale) == null ? void 0 : u.options) ==
      null
        ? void 0
        : s.weekStartsOn) ??
      n.weekStartsOn ??
      ((l = (d = n.locale) == null ? void 0 : d.options) == null
        ? void 0
        : l.weekStartsOn) ??
      0,
    a = I(e, t == null ? void 0 : t.in),
    i = a.getDay(),
    c = (i < r ? 7 : 0) + i - r
  return a.setDate(a.getDate() - c), a.setHours(0, 0, 0, 0), a
}
function J (e, t) {
  return Q(e, { ...t, weekStartsOn: 1 })
}
function We (e, t) {
  const n = I(e, t == null ? void 0 : t.in),
    r = n.getFullYear(),
    a = W(n, 0)
  a.setFullYear(r + 1, 0, 4), a.setHours(0, 0, 0, 0)
  const i = J(a),
    c = W(n, 0)
  c.setFullYear(r, 0, 4), c.setHours(0, 0, 0, 0)
  const u = J(c)
  return n.getTime() >= i.getTime()
    ? r + 1
    : n.getTime() >= u.getTime()
    ? r
    : r - 1
}
function Me (e) {
  const t = I(e),
    n = new Date(
      Date.UTC(
        t.getFullYear(),
        t.getMonth(),
        t.getDate(),
        t.getHours(),
        t.getMinutes(),
        t.getSeconds(),
        t.getMilliseconds()
      )
    )
  return n.setUTCFullYear(t.getFullYear()), +e - +n
}
function Pt (e, ...t) {
  const n = W.bind(
    null,
    t.find(r => typeof r == 'object')
  )
  return t.map(n)
}
function Oe (e, t) {
  const n = I(e, t == null ? void 0 : t.in)
  return n.setHours(0, 0, 0, 0), n
}
function kt (e, t, n) {
  const [r, a] = Pt(n == null ? void 0 : n.in, e, t),
    i = Oe(r),
    c = Oe(a),
    u = +i - Me(i),
    s = +c - Me(c)
  return Math.round((u - s) / St)
}
function Mt (e, t) {
  const n = We(e, t),
    r = W(e, 0)
  return r.setFullYear(n, 0, 4), r.setHours(0, 0, 0, 0), J(r)
}
function Ot (e) {
  return (
    e instanceof Date ||
    (typeof e == 'object' &&
      Object.prototype.toString.call(e) === '[object Date]')
  )
}
function Dt (e) {
  return !((!Ot(e) && typeof e != 'number') || isNaN(+I(e)))
}
function _t (e, t) {
  const n = I(e, t == null ? void 0 : t.in)
  return n.setFullYear(n.getFullYear(), 0, 1), n.setHours(0, 0, 0, 0), n
}
const It = {
    lessThanXSeconds: {
      one: 'less than a second',
      other: 'less than {{count}} seconds'
    },
    xSeconds: { one: '1 second', other: '{{count}} seconds' },
    halfAMinute: 'half a minute',
    lessThanXMinutes: {
      one: 'less than a minute',
      other: 'less than {{count}} minutes'
    },
    xMinutes: { one: '1 minute', other: '{{count}} minutes' },
    aboutXHours: { one: 'about 1 hour', other: 'about {{count}} hours' },
    xHours: { one: '1 hour', other: '{{count}} hours' },
    xDays: { one: '1 day', other: '{{count}} days' },
    aboutXWeeks: { one: 'about 1 week', other: 'about {{count}} weeks' },
    xWeeks: { one: '1 week', other: '{{count}} weeks' },
    aboutXMonths: { one: 'about 1 month', other: 'about {{count}} months' },
    xMonths: { one: '1 month', other: '{{count}} months' },
    aboutXYears: { one: 'about 1 year', other: 'about {{count}} years' },
    xYears: { one: '1 year', other: '{{count}} years' },
    overXYears: { one: 'over 1 year', other: 'over {{count}} years' },
    almostXYears: { one: 'almost 1 year', other: 'almost {{count}} years' }
  },
  Ft = (e, t, n) => {
    let r
    const a = It[e]
    return (
      typeof a == 'string'
        ? (r = a)
        : t === 1
        ? (r = a.one)
        : (r = a.other.replace('{{count}}', t.toString())),
      n != null && n.addSuffix
        ? n.comparison && n.comparison > 0
          ? 'in ' + r
          : r + ' ago'
        : r
    )
  }
function ne (e) {
  return (t = {}) => {
    const n = t.width ? String(t.width) : e.defaultWidth
    return e.formats[n] || e.formats[e.defaultWidth]
  }
}
const Tt = {
    full: 'EEEE, MMMM do, y',
    long: 'MMMM do, y',
    medium: 'MMM d, y',
    short: 'MM/dd/yyyy'
  },
  Et = {
    full: 'h:mm:ss a zzzz',
    long: 'h:mm:ss a z',
    medium: 'h:mm:ss a',
    short: 'h:mm a'
  },
  Wt = {
    full: "{{date}} 'at' {{time}}",
    long: "{{date}} 'at' {{time}}",
    medium: '{{date}}, {{time}}',
    short: '{{date}}, {{time}}'
  },
  Lt = {
    date: ne({ formats: Tt, defaultWidth: 'full' }),
    time: ne({ formats: Et, defaultWidth: 'full' }),
    dateTime: ne({ formats: Wt, defaultWidth: 'full' })
  },
  $t = {
    lastWeek: "'last' eeee 'at' p",
    yesterday: "'yesterday at' p",
    today: "'today at' p",
    tomorrow: "'tomorrow at' p",
    nextWeek: "eeee 'at' p",
    other: 'P'
  },
  Rt = (e, t, n, r) => $t[e]
function V (e) {
  return (t, n) => {
    const r = n != null && n.context ? String(n.context) : 'standalone'
    let a
    if (r === 'formatting' && e.formattingValues) {
      const c = e.defaultFormattingWidth || e.defaultWidth,
        u = n != null && n.width ? String(n.width) : c
      a = e.formattingValues[u] || e.formattingValues[c]
    } else {
      const c = e.defaultWidth,
        u = n != null && n.width ? String(n.width) : e.defaultWidth
      a = e.values[u] || e.values[c]
    }
    const i = e.argumentCallback ? e.argumentCallback(t) : t
    return a[i]
  }
}
const Yt = {
    narrow: ['B', 'A'],
    abbreviated: ['BC', 'AD'],
    wide: ['Before Christ', 'Anno Domini']
  },
  qt = {
    narrow: ['1', '2', '3', '4'],
    abbreviated: ['Q1', 'Q2', 'Q3', 'Q4'],
    wide: ['1st quarter', '2nd quarter', '3rd quarter', '4th quarter']
  },
  At = {
    narrow: ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'],
    abbreviated: [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ],
    wide: [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ]
  },
  Bt = {
    narrow: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],
    short: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
    abbreviated: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    wide: [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ]
  },
  Nt = {
    narrow: {
      am: 'a',
      pm: 'p',
      midnight: 'mi',
      noon: 'n',
      morning: 'morning',
      afternoon: 'afternoon',
      evening: 'evening',
      night: 'night'
    },
    abbreviated: {
      am: 'AM',
      pm: 'PM',
      midnight: 'midnight',
      noon: 'noon',
      morning: 'morning',
      afternoon: 'afternoon',
      evening: 'evening',
      night: 'night'
    },
    wide: {
      am: 'a.m.',
      pm: 'p.m.',
      midnight: 'midnight',
      noon: 'noon',
      morning: 'morning',
      afternoon: 'afternoon',
      evening: 'evening',
      night: 'night'
    }
  },
  zt = {
    narrow: {
      am: 'a',
      pm: 'p',
      midnight: 'mi',
      noon: 'n',
      morning: 'in the morning',
      afternoon: 'in the afternoon',
      evening: 'in the evening',
      night: 'at night'
    },
    abbreviated: {
      am: 'AM',
      pm: 'PM',
      midnight: 'midnight',
      noon: 'noon',
      morning: 'in the morning',
      afternoon: 'in the afternoon',
      evening: 'in the evening',
      night: 'at night'
    },
    wide: {
      am: 'a.m.',
      pm: 'p.m.',
      midnight: 'midnight',
      noon: 'noon',
      morning: 'in the morning',
      afternoon: 'in the afternoon',
      evening: 'in the evening',
      night: 'at night'
    }
  },
  Ht = (e, t) => {
    const n = Number(e),
      r = n % 100
    if (r > 20 || r < 10)
      switch (r % 10) {
        case 1:
          return n + 'st'
        case 2:
          return n + 'nd'
        case 3:
          return n + 'rd'
      }
    return n + 'th'
  },
  Vt = {
    ordinalNumber: Ht,
    era: V({ values: Yt, defaultWidth: 'wide' }),
    quarter: V({
      values: qt,
      defaultWidth: 'wide',
      argumentCallback: e => e - 1
    }),
    month: V({ values: At, defaultWidth: 'wide' }),
    day: V({ values: Bt, defaultWidth: 'wide' }),
    dayPeriod: V({
      values: Nt,
      defaultWidth: 'wide',
      formattingValues: zt,
      defaultFormattingWidth: 'wide'
    })
  }
function j (e) {
  return (t, n = {}) => {
    const r = n.width,
      a = (r && e.matchPatterns[r]) || e.matchPatterns[e.defaultMatchWidth],
      i = t.match(a)
    if (!i) return null
    const c = i[0],
      u = (r && e.parsePatterns[r]) || e.parsePatterns[e.defaultParseWidth],
      s = Array.isArray(u) ? Qt(u, f => f.test(c)) : jt(u, f => f.test(c))
    let d
    ;(d = e.valueCallback ? e.valueCallback(s) : s),
      (d = n.valueCallback ? n.valueCallback(d) : d)
    const l = t.slice(c.length)
    return { value: d, rest: l }
  }
}
function jt (e, t) {
  for (const n in e)
    if (Object.prototype.hasOwnProperty.call(e, n) && t(e[n])) return n
}
function Qt (e, t) {
  for (let n = 0; n < e.length; n++) if (t(e[n])) return n
}
function Gt (e) {
  return (t, n = {}) => {
    const r = t.match(e.matchPattern)
    if (!r) return null
    const a = r[0],
      i = t.match(e.parsePattern)
    if (!i) return null
    let c = e.valueCallback ? e.valueCallback(i[0]) : i[0]
    c = n.valueCallback ? n.valueCallback(c) : c
    const u = t.slice(a.length)
    return { value: c, rest: u }
  }
}
const Xt = /^(\d+)(th|st|nd|rd)?/i,
  Kt = /\d+/i,
  Jt = {
    narrow: /^(b|a)/i,
    abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
    wide: /^(before christ|before common era|anno domini|common era)/i
  },
  Ut = { any: [/^b/i, /^(a|c)/i] },
  Zt = {
    narrow: /^[1234]/i,
    abbreviated: /^q[1234]/i,
    wide: /^[1234](th|st|nd|rd)? quarter/i
  },
  en = { any: [/1/i, /2/i, /3/i, /4/i] },
  tn = {
    narrow: /^[jfmasond]/i,
    abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
    wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
  },
  nn = {
    narrow: [
      /^j/i,
      /^f/i,
      /^m/i,
      /^a/i,
      /^m/i,
      /^j/i,
      /^j/i,
      /^a/i,
      /^s/i,
      /^o/i,
      /^n/i,
      /^d/i
    ],
    any: [
      /^ja/i,
      /^f/i,
      /^mar/i,
      /^ap/i,
      /^may/i,
      /^jun/i,
      /^jul/i,
      /^au/i,
      /^s/i,
      /^o/i,
      /^n/i,
      /^d/i
    ]
  },
  rn = {
    narrow: /^[smtwf]/i,
    short: /^(su|mo|tu|we|th|fr|sa)/i,
    abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
    wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
  },
  an = {
    narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
    any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
  },
  sn = {
    narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
    any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
  },
  on = {
    any: {
      am: /^a/i,
      pm: /^p/i,
      midnight: /^mi/i,
      noon: /^no/i,
      morning: /morning/i,
      afternoon: /afternoon/i,
      evening: /evening/i,
      night: /night/i
    }
  },
  un = {
    ordinalNumber: Gt({
      matchPattern: Xt,
      parsePattern: Kt,
      valueCallback: e => parseInt(e, 10)
    }),
    era: j({
      matchPatterns: Jt,
      defaultMatchWidth: 'wide',
      parsePatterns: Ut,
      defaultParseWidth: 'any'
    }),
    quarter: j({
      matchPatterns: Zt,
      defaultMatchWidth: 'wide',
      parsePatterns: en,
      defaultParseWidth: 'any',
      valueCallback: e => e + 1
    }),
    month: j({
      matchPatterns: tn,
      defaultMatchWidth: 'wide',
      parsePatterns: nn,
      defaultParseWidth: 'any'
    }),
    day: j({
      matchPatterns: rn,
      defaultMatchWidth: 'wide',
      parsePatterns: an,
      defaultParseWidth: 'any'
    }),
    dayPeriod: j({
      matchPatterns: sn,
      defaultMatchWidth: 'any',
      parsePatterns: on,
      defaultParseWidth: 'any'
    })
  },
  cn = {
    code: 'en-US',
    formatDistance: Ft,
    formatLong: Lt,
    formatRelative: Rt,
    localize: Vt,
    match: un,
    options: { weekStartsOn: 0, firstWeekContainsDate: 1 }
  }
function dn (e, t) {
  const n = I(e, t == null ? void 0 : t.in)
  return kt(n, _t(n)) + 1
}
function ln (e, t) {
  const n = I(e, t == null ? void 0 : t.in),
    r = +J(n) - +Mt(n)
  return Math.round(r / Ee) + 1
}
function Le (e, t) {
  var l, f, g, x
  const n = I(e, t == null ? void 0 : t.in),
    r = n.getFullYear(),
    a = ee(),
    i =
      (t == null ? void 0 : t.firstWeekContainsDate) ??
      ((f = (l = t == null ? void 0 : t.locale) == null ? void 0 : l.options) ==
      null
        ? void 0
        : f.firstWeekContainsDate) ??
      a.firstWeekContainsDate ??
      ((x = (g = a.locale) == null ? void 0 : g.options) == null
        ? void 0
        : x.firstWeekContainsDate) ??
      1,
    c = W((t == null ? void 0 : t.in) || e, 0)
  c.setFullYear(r + 1, 0, i), c.setHours(0, 0, 0, 0)
  const u = Q(c, t),
    s = W((t == null ? void 0 : t.in) || e, 0)
  s.setFullYear(r, 0, i), s.setHours(0, 0, 0, 0)
  const d = Q(s, t)
  return +n >= +u ? r + 1 : +n >= +d ? r : r - 1
}
function fn (e, t) {
  var u, s, d, l
  const n = ee(),
    r =
      (t == null ? void 0 : t.firstWeekContainsDate) ??
      ((s = (u = t == null ? void 0 : t.locale) == null ? void 0 : u.options) ==
      null
        ? void 0
        : s.firstWeekContainsDate) ??
      n.firstWeekContainsDate ??
      ((l = (d = n.locale) == null ? void 0 : d.options) == null
        ? void 0
        : l.firstWeekContainsDate) ??
      1,
    a = Le(e, t),
    i = W((t == null ? void 0 : t.in) || e, 0)
  return i.setFullYear(a, 0, r), i.setHours(0, 0, 0, 0), Q(i, t)
}
function gn (e, t) {
  const n = I(e, t == null ? void 0 : t.in),
    r = +Q(n, t) - +fn(n, t)
  return Math.round(r / Ee) + 1
}
function b (e, t) {
  const n = e < 0 ? '-' : '',
    r = Math.abs(e).toString().padStart(t, '0')
  return n + r
}
const T = {
    y (e, t) {
      const n = e.getFullYear(),
        r = n > 0 ? n : 1 - n
      return b(t === 'yy' ? r % 100 : r, t.length)
    },
    M (e, t) {
      const n = e.getMonth()
      return t === 'M' ? String(n + 1) : b(n + 1, 2)
    },
    d (e, t) {
      return b(e.getDate(), t.length)
    },
    a (e, t) {
      const n = e.getHours() / 12 >= 1 ? 'pm' : 'am'
      switch (t) {
        case 'a':
        case 'aa':
          return n.toUpperCase()
        case 'aaa':
          return n
        case 'aaaaa':
          return n[0]
        case 'aaaa':
        default:
          return n === 'am' ? 'a.m.' : 'p.m.'
      }
    },
    h (e, t) {
      return b(e.getHours() % 12 || 12, t.length)
    },
    H (e, t) {
      return b(e.getHours(), t.length)
    },
    m (e, t) {
      return b(e.getMinutes(), t.length)
    },
    s (e, t) {
      return b(e.getSeconds(), t.length)
    },
    S (e, t) {
      const n = t.length,
        r = e.getMilliseconds(),
        a = Math.trunc(r * Math.pow(10, n - 3))
      return b(a, t.length)
    }
  },
  B = {
    am: 'am',
    pm: 'pm',
    midnight: 'midnight',
    noon: 'noon',
    morning: 'morning',
    afternoon: 'afternoon',
    evening: 'evening',
    night: 'night'
  },
  De = {
    G: function (e, t, n) {
      const r = e.getFullYear() > 0 ? 1 : 0
      switch (t) {
        case 'G':
        case 'GG':
        case 'GGG':
          return n.era(r, { width: 'abbreviated' })
        case 'GGGGG':
          return n.era(r, { width: 'narrow' })
        case 'GGGG':
        default:
          return n.era(r, { width: 'wide' })
      }
    },
    y: function (e, t, n) {
      if (t === 'yo') {
        const r = e.getFullYear(),
          a = r > 0 ? r : 1 - r
        return n.ordinalNumber(a, { unit: 'year' })
      }
      return T.y(e, t)
    },
    Y: function (e, t, n, r) {
      const a = Le(e, r),
        i = a > 0 ? a : 1 - a
      if (t === 'YY') {
        const c = i % 100
        return b(c, 2)
      }
      return t === 'Yo' ? n.ordinalNumber(i, { unit: 'year' }) : b(i, t.length)
    },
    R: function (e, t) {
      const n = We(e)
      return b(n, t.length)
    },
    u: function (e, t) {
      const n = e.getFullYear()
      return b(n, t.length)
    },
    Q: function (e, t, n) {
      const r = Math.ceil((e.getMonth() + 1) / 3)
      switch (t) {
        case 'Q':
          return String(r)
        case 'QQ':
          return b(r, 2)
        case 'Qo':
          return n.ordinalNumber(r, { unit: 'quarter' })
        case 'QQQ':
          return n.quarter(r, { width: 'abbreviated', context: 'formatting' })
        case 'QQQQQ':
          return n.quarter(r, { width: 'narrow', context: 'formatting' })
        case 'QQQQ':
        default:
          return n.quarter(r, { width: 'wide', context: 'formatting' })
      }
    },
    q: function (e, t, n) {
      const r = Math.ceil((e.getMonth() + 1) / 3)
      switch (t) {
        case 'q':
          return String(r)
        case 'qq':
          return b(r, 2)
        case 'qo':
          return n.ordinalNumber(r, { unit: 'quarter' })
        case 'qqq':
          return n.quarter(r, { width: 'abbreviated', context: 'standalone' })
        case 'qqqqq':
          return n.quarter(r, { width: 'narrow', context: 'standalone' })
        case 'qqqq':
        default:
          return n.quarter(r, { width: 'wide', context: 'standalone' })
      }
    },
    M: function (e, t, n) {
      const r = e.getMonth()
      switch (t) {
        case 'M':
        case 'MM':
          return T.M(e, t)
        case 'Mo':
          return n.ordinalNumber(r + 1, { unit: 'month' })
        case 'MMM':
          return n.month(r, { width: 'abbreviated', context: 'formatting' })
        case 'MMMMM':
          return n.month(r, { width: 'narrow', context: 'formatting' })
        case 'MMMM':
        default:
          return n.month(r, { width: 'wide', context: 'formatting' })
      }
    },
    L: function (e, t, n) {
      const r = e.getMonth()
      switch (t) {
        case 'L':
          return String(r + 1)
        case 'LL':
          return b(r + 1, 2)
        case 'Lo':
          return n.ordinalNumber(r + 1, { unit: 'month' })
        case 'LLL':
          return n.month(r, { width: 'abbreviated', context: 'standalone' })
        case 'LLLLL':
          return n.month(r, { width: 'narrow', context: 'standalone' })
        case 'LLLL':
        default:
          return n.month(r, { width: 'wide', context: 'standalone' })
      }
    },
    w: function (e, t, n, r) {
      const a = gn(e, r)
      return t === 'wo' ? n.ordinalNumber(a, { unit: 'week' }) : b(a, t.length)
    },
    I: function (e, t, n) {
      const r = ln(e)
      return t === 'Io' ? n.ordinalNumber(r, { unit: 'week' }) : b(r, t.length)
    },
    d: function (e, t, n) {
      return t === 'do'
        ? n.ordinalNumber(e.getDate(), { unit: 'date' })
        : T.d(e, t)
    },
    D: function (e, t, n) {
      const r = dn(e)
      return t === 'Do'
        ? n.ordinalNumber(r, { unit: 'dayOfYear' })
        : b(r, t.length)
    },
    E: function (e, t, n) {
      const r = e.getDay()
      switch (t) {
        case 'E':
        case 'EE':
        case 'EEE':
          return n.day(r, { width: 'abbreviated', context: 'formatting' })
        case 'EEEEE':
          return n.day(r, { width: 'narrow', context: 'formatting' })
        case 'EEEEEE':
          return n.day(r, { width: 'short', context: 'formatting' })
        case 'EEEE':
        default:
          return n.day(r, { width: 'wide', context: 'formatting' })
      }
    },
    e: function (e, t, n, r) {
      const a = e.getDay(),
        i = (a - r.weekStartsOn + 8) % 7 || 7
      switch (t) {
        case 'e':
          return String(i)
        case 'ee':
          return b(i, 2)
        case 'eo':
          return n.ordinalNumber(i, { unit: 'day' })
        case 'eee':
          return n.day(a, { width: 'abbreviated', context: 'formatting' })
        case 'eeeee':
          return n.day(a, { width: 'narrow', context: 'formatting' })
        case 'eeeeee':
          return n.day(a, { width: 'short', context: 'formatting' })
        case 'eeee':
        default:
          return n.day(a, { width: 'wide', context: 'formatting' })
      }
    },
    c: function (e, t, n, r) {
      const a = e.getDay(),
        i = (a - r.weekStartsOn + 8) % 7 || 7
      switch (t) {
        case 'c':
          return String(i)
        case 'cc':
          return b(i, t.length)
        case 'co':
          return n.ordinalNumber(i, { unit: 'day' })
        case 'ccc':
          return n.day(a, { width: 'abbreviated', context: 'standalone' })
        case 'ccccc':
          return n.day(a, { width: 'narrow', context: 'standalone' })
        case 'cccccc':
          return n.day(a, { width: 'short', context: 'standalone' })
        case 'cccc':
        default:
          return n.day(a, { width: 'wide', context: 'standalone' })
      }
    },
    i: function (e, t, n) {
      const r = e.getDay(),
        a = r === 0 ? 7 : r
      switch (t) {
        case 'i':
          return String(a)
        case 'ii':
          return b(a, t.length)
        case 'io':
          return n.ordinalNumber(a, { unit: 'day' })
        case 'iii':
          return n.day(r, { width: 'abbreviated', context: 'formatting' })
        case 'iiiii':
          return n.day(r, { width: 'narrow', context: 'formatting' })
        case 'iiiiii':
          return n.day(r, { width: 'short', context: 'formatting' })
        case 'iiii':
        default:
          return n.day(r, { width: 'wide', context: 'formatting' })
      }
    },
    a: function (e, t, n) {
      const a = e.getHours() / 12 >= 1 ? 'pm' : 'am'
      switch (t) {
        case 'a':
        case 'aa':
          return n.dayPeriod(a, { width: 'abbreviated', context: 'formatting' })
        case 'aaa':
          return n
            .dayPeriod(a, { width: 'abbreviated', context: 'formatting' })
            .toLowerCase()
        case 'aaaaa':
          return n.dayPeriod(a, { width: 'narrow', context: 'formatting' })
        case 'aaaa':
        default:
          return n.dayPeriod(a, { width: 'wide', context: 'formatting' })
      }
    },
    b: function (e, t, n) {
      const r = e.getHours()
      let a
      switch (
        (r === 12
          ? (a = B.noon)
          : r === 0
          ? (a = B.midnight)
          : (a = r / 12 >= 1 ? 'pm' : 'am'),
        t)
      ) {
        case 'b':
        case 'bb':
          return n.dayPeriod(a, { width: 'abbreviated', context: 'formatting' })
        case 'bbb':
          return n
            .dayPeriod(a, { width: 'abbreviated', context: 'formatting' })
            .toLowerCase()
        case 'bbbbb':
          return n.dayPeriod(a, { width: 'narrow', context: 'formatting' })
        case 'bbbb':
        default:
          return n.dayPeriod(a, { width: 'wide', context: 'formatting' })
      }
    },
    B: function (e, t, n) {
      const r = e.getHours()
      let a
      switch (
        (r >= 17
          ? (a = B.evening)
          : r >= 12
          ? (a = B.afternoon)
          : r >= 4
          ? (a = B.morning)
          : (a = B.night),
        t)
      ) {
        case 'B':
        case 'BB':
        case 'BBB':
          return n.dayPeriod(a, { width: 'abbreviated', context: 'formatting' })
        case 'BBBBB':
          return n.dayPeriod(a, { width: 'narrow', context: 'formatting' })
        case 'BBBB':
        default:
          return n.dayPeriod(a, { width: 'wide', context: 'formatting' })
      }
    },
    h: function (e, t, n) {
      if (t === 'ho') {
        let r = e.getHours() % 12
        return r === 0 && (r = 12), n.ordinalNumber(r, { unit: 'hour' })
      }
      return T.h(e, t)
    },
    H: function (e, t, n) {
      return t === 'Ho'
        ? n.ordinalNumber(e.getHours(), { unit: 'hour' })
        : T.H(e, t)
    },
    K: function (e, t, n) {
      const r = e.getHours() % 12
      return t === 'Ko' ? n.ordinalNumber(r, { unit: 'hour' }) : b(r, t.length)
    },
    k: function (e, t, n) {
      let r = e.getHours()
      return (
        r === 0 && (r = 24),
        t === 'ko' ? n.ordinalNumber(r, { unit: 'hour' }) : b(r, t.length)
      )
    },
    m: function (e, t, n) {
      return t === 'mo'
        ? n.ordinalNumber(e.getMinutes(), { unit: 'minute' })
        : T.m(e, t)
    },
    s: function (e, t, n) {
      return t === 'so'
        ? n.ordinalNumber(e.getSeconds(), { unit: 'second' })
        : T.s(e, t)
    },
    S: function (e, t) {
      return T.S(e, t)
    },
    X: function (e, t, n) {
      const r = e.getTimezoneOffset()
      if (r === 0) return 'Z'
      switch (t) {
        case 'X':
          return Ie(r)
        case 'XXXX':
        case 'XX':
          return Y(r)
        case 'XXXXX':
        case 'XXX':
        default:
          return Y(r, ':')
      }
    },
    x: function (e, t, n) {
      const r = e.getTimezoneOffset()
      switch (t) {
        case 'x':
          return Ie(r)
        case 'xxxx':
        case 'xx':
          return Y(r)
        case 'xxxxx':
        case 'xxx':
        default:
          return Y(r, ':')
      }
    },
    O: function (e, t, n) {
      const r = e.getTimezoneOffset()
      switch (t) {
        case 'O':
        case 'OO':
        case 'OOO':
          return 'GMT' + _e(r, ':')
        case 'OOOO':
        default:
          return 'GMT' + Y(r, ':')
      }
    },
    z: function (e, t, n) {
      const r = e.getTimezoneOffset()
      switch (t) {
        case 'z':
        case 'zz':
        case 'zzz':
          return 'GMT' + _e(r, ':')
        case 'zzzz':
        default:
          return 'GMT' + Y(r, ':')
      }
    },
    t: function (e, t, n) {
      const r = Math.trunc(+e / 1e3)
      return b(r, t.length)
    },
    T: function (e, t, n) {
      return b(+e, t.length)
    }
  }
function _e (e, t = '') {
  const n = e > 0 ? '-' : '+',
    r = Math.abs(e),
    a = Math.trunc(r / 60),
    i = r % 60
  return i === 0 ? n + String(a) : n + String(a) + t + b(i, 2)
}
function Ie (e, t) {
  return e % 60 === 0 ? (e > 0 ? '-' : '+') + b(Math.abs(e) / 60, 2) : Y(e, t)
}
function Y (e, t = '') {
  const n = e > 0 ? '-' : '+',
    r = Math.abs(e),
    a = b(Math.trunc(r / 60), 2),
    i = b(r % 60, 2)
  return n + a + t + i
}
const Fe = (e, t) => {
    switch (e) {
      case 'P':
        return t.date({ width: 'short' })
      case 'PP':
        return t.date({ width: 'medium' })
      case 'PPP':
        return t.date({ width: 'long' })
      case 'PPPP':
      default:
        return t.date({ width: 'full' })
    }
  },
  $e = (e, t) => {
    switch (e) {
      case 'p':
        return t.time({ width: 'short' })
      case 'pp':
        return t.time({ width: 'medium' })
      case 'ppp':
        return t.time({ width: 'long' })
      case 'pppp':
      default:
        return t.time({ width: 'full' })
    }
  },
  hn = (e, t) => {
    const n = e.match(/(P+)(p+)?/) || [],
      r = n[1],
      a = n[2]
    if (!a) return Fe(e, t)
    let i
    switch (r) {
      case 'P':
        i = t.dateTime({ width: 'short' })
        break
      case 'PP':
        i = t.dateTime({ width: 'medium' })
        break
      case 'PPP':
        i = t.dateTime({ width: 'long' })
        break
      case 'PPPP':
      default:
        i = t.dateTime({ width: 'full' })
        break
    }
    return i.replace('{{date}}', Fe(r, t)).replace('{{time}}', $e(a, t))
  },
  mn = { p: $e, P: hn },
  bn = /^D+$/,
  yn = /^Y+$/,
  vn = ['D', 'DD', 'YY', 'YYYY']
function wn (e) {
  return bn.test(e)
}
function xn (e) {
  return yn.test(e)
}
function pn (e, t, n) {
  const r = Sn(e, t, n)
  if ((console.warn(r), vn.includes(e))) throw new RangeError(r)
}
function Sn (e, t, n) {
  const r = e[0] === 'Y' ? 'years' : 'days of the month'
  return `Use \`${e.toLowerCase()}\` instead of \`${e}\` (in \`${t}\`) for formatting ${r} to the input \`${n}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`
}
const Cn = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,
  Pn = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,
  kn = /^'([^]*?)'?$/,
  Mn = /''/g,
  On = /[a-zA-Z]/
function Re (e, t, n) {
  var l, f, g, x
  const r = ee(),
    a = r.locale ?? cn,
    i =
      r.firstWeekContainsDate ??
      ((f = (l = r.locale) == null ? void 0 : l.options) == null
        ? void 0
        : f.firstWeekContainsDate) ??
      1,
    c =
      r.weekStartsOn ??
      ((x = (g = r.locale) == null ? void 0 : g.options) == null
        ? void 0
        : x.weekStartsOn) ??
      0,
    u = I(e, n == null ? void 0 : n.in)
  if (!Dt(u)) throw new RangeError('Invalid time value')
  let s = t
    .match(Pn)
    .map(h => {
      const w = h[0]
      if (w === 'p' || w === 'P') {
        const p = mn[w]
        return p(h, a.formatLong)
      }
      return h
    })
    .join('')
    .match(Cn)
    .map(h => {
      if (h === "''") return { isToken: !1, value: "'" }
      const w = h[0]
      if (w === "'") return { isToken: !1, value: Dn(h) }
      if (De[w]) return { isToken: !0, value: h }
      if (w.match(On))
        throw new RangeError(
          'Format string contains an unescaped latin alphabet character `' +
            w +
            '`'
        )
      return { isToken: !1, value: h }
    })
  a.localize.preprocessor && (s = a.localize.preprocessor(u, s))
  const d = { firstWeekContainsDate: i, weekStartsOn: c, locale: a }
  return s
    .map(h => {
      if (!h.isToken) return h.value
      const w = h.value
      ;(xn(w) || wn(w)) && pn(w, t, String(e))
      const p = De[w[0]]
      return p(u, w, a.localize, d)
    })
    .join('')
}
function Dn (e) {
  const t = e.match(kn)
  return t ? t[1].replace(Mn, "'") : e
}
var _n = C('<div>')
const In = tt(
    'inline-flex items-center border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2',
    {
      variants: {
        variant: {
          default:
            'border-transparent bg-primary text-primary-foreground hover:bg-primary/80',
          secondary:
            'border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80',
          destructive:
            'border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80',
          outline: 'text-foreground'
        }
      },
      defaultVariants: { variant: 'default' }
    }
  ),
  Fn = e => {
    const [t, n] = S(e, ['class', 'variant', 'round'])
    return (() => {
      var r = _n()
      return (
        et(
          r,
          v(
            {
              get class () {
                return D(
                  In({ variant: t.variant }),
                  t.round ? 'rounded-full' : 'rounded-md',
                  t.class
                )
              }
            },
            n
          ),
          !1,
          !1
        ),
        r
      )
    })()
  }
function K (e) {
  return t => (e(t), () => e(void 0))
}
var Ye = ['id', 'name', 'validationState', 'required', 'disabled', 'readOnly']
function qe (e) {
  const t = `form-control-${ue()}`,
    n = k({ id: t }, e),
    [r, a] = P(),
    [i, c] = P(),
    [u, s] = P(),
    [d, l] = P(),
    f = (w, p, O) => {
      const q = O != null || r() != null
      return (
        [O, r(), q && p != null ? w : void 0].filter(Boolean).join(' ') ||
        void 0
      )
    },
    g = w => [u(), d(), w].filter(Boolean).join(' ') || void 0,
    x = _(() => ({
      'data-valid': y(n.validationState) === 'valid' ? '' : void 0,
      'data-invalid': y(n.validationState) === 'invalid' ? '' : void 0,
      'data-required': y(n.required) ? '' : void 0,
      'data-disabled': y(n.disabled) ? '' : void 0,
      'data-readonly': y(n.readOnly) ? '' : void 0
    }))
  return {
    formControlContext: {
      name: () => y(n.name) ?? y(n.id),
      dataset: x,
      validationState: () => y(n.validationState),
      isRequired: () => y(n.required),
      isDisabled: () => y(n.disabled),
      isReadOnly: () => y(n.readOnly),
      labelId: r,
      fieldId: i,
      descriptionId: u,
      errorMessageId: d,
      getAriaLabelledBy: f,
      getAriaDescribedBy: g,
      generateId: se(() => y(n.id)),
      registerLabel: K(a),
      registerField: K(c),
      registerDescription: K(s),
      registerErrorMessage: K(l)
    }
  }
}
var de = U()
function $ () {
  const e = Z(de)
  if (e === void 0)
    throw new Error(
      '[kobalte]: `useFormControlContext` must be used within a `FormControlContext.Provider` component'
    )
  return e
}
function le (e) {
  const t = $(),
    n = k({ id: t.generateId('description') }, e)
  return (
    F(() => L(t.registerDescription(n.id))),
    o(
      M,
      v({ as: 'div' }, () => t.dataset(), n)
    )
  )
}
function fe (e) {
  const t = $(),
    n = k({ id: t.generateId('error-message') }, e),
    [r, a] = S(n, ['forceMount']),
    i = () => t.validationState() === 'invalid'
  return (
    F(() => {
      i() && L(t.registerErrorMessage(a.id))
    }),
    o(E, {
      get when () {
        return r.forceMount || i()
      },
      get children () {
        return o(
          M,
          v({ as: 'div' }, () => t.dataset(), a)
        )
      }
    })
  )
}
function ge (e) {
  let t
  const n = $(),
    r = k({ id: n.generateId('label') }, e),
    [a, i] = S(r, ['ref']),
    c = nt(
      () => t,
      () => 'label'
    )
  return (
    F(() => L(n.registerLabel(i.id))),
    o(
      M,
      v(
        {
          as: 'label',
          ref (u) {
            var s = G(d => (t = d), a.ref)
            typeof s == 'function' && s(u)
          },
          get for () {
            return _(() => c() === 'label')() ? n.fieldId() : void 0
          }
        },
        () => n.dataset(),
        i
      )
    )
  )
}
var Ae = ['id', 'aria-label', 'aria-labelledby', 'aria-describedby']
function Be (e) {
  const t = $(),
    n = k({ id: t.generateId('field') }, e)
  return (
    F(() => L(t.registerField(y(n.id)))),
    {
      fieldProps: {
        id: () => y(n.id),
        ariaLabel: () => y(n['aria-label']),
        ariaLabelledBy: () =>
          t.getAriaLabelledBy(
            y(n.id),
            y(n['aria-label']),
            y(n['aria-labelledby'])
          ),
        ariaDescribedBy: () => t.getAriaDescribedBy(y(n['aria-describedby']))
      }
    }
  )
}
function Ne (e, t) {
  F(
    ce(e, n => {
      if (n == null) return
      const r = Tn(n)
      r != null &&
        (r.addEventListener('reset', t, { passive: !0 }),
        L(() => {
          r.removeEventListener('reset', t)
        }))
    })
  )
}
function Tn (e) {
  return En(e) ? e.form : e.closest('form')
}
function En (e) {
  return e.matches('textarea, input, select, button')
}
function ze (e) {
  var c
  const [t, n] = P((c = e.defaultValue) == null ? void 0 : c.call(e)),
    r = _(() => {
      var u
      return ((u = e.value) == null ? void 0 : u.call(e)) !== void 0
    }),
    a = _(() => {
      var u
      return r() ? ((u = e.value) == null ? void 0 : u.call(e)) : t()
    })
  return [
    a,
    u => {
      dt(() => {
        var d
        const s = rt(u, a())
        return (
          Object.is(s, a()) ||
            (r() || n(s), (d = e.onChange) == null || d.call(e, s)),
          s
        )
      })
    }
  ]
}
function Wn (e) {
  const [t, n] = ze(e)
  return [() => t() ?? !1, n]
}
function Ln (e = {}) {
  const [t, n] = Wn({
    value: () => y(e.isSelected),
    defaultValue: () => !!y(e.defaultIsSelected),
    onChange: i => {
      var c
      return (c = e.onSelectedChange) == null ? void 0 : c.call(e, i)
    }
  })
  return {
    isSelected: t,
    setIsSelected: i => {
      !y(e.isReadOnly) && !y(e.isDisabled) && n(i)
    },
    toggle: () => {
      !y(e.isReadOnly) && !y(e.isDisabled) && n(!t())
    }
  }
}
var $n = {}
oe($n, {
  Control: () => he,
  Description: () => Ve,
  ErrorMessage: () => je,
  Input: () => me,
  Label: () => be,
  Root: () => ye,
  Switch: () => Yn,
  Thumb: () => ve
})
var He = U()
function H () {
  const e = Z(He)
  if (e === void 0)
    throw new Error(
      '[kobalte]: `useSwitchContext` must be used within a `Switch` component'
    )
  return e
}
function he (e) {
  const t = $(),
    n = H(),
    r = k({ id: n.generateId('control') }, e),
    [a, i] = S(r, ['onClick', 'onKeyDown'])
  return o(
    M,
    v(
      {
        as: 'div',
        onClick: s => {
          var d
          z(s, a.onClick), n.toggle(), (d = n.inputRef()) == null || d.focus()
        },
        onKeyDown: s => {
          var d
          z(s, a.onKeyDown),
            s.key === st.Space &&
              (n.toggle(), (d = n.inputRef()) == null || d.focus())
        }
      },
      () => t.dataset(),
      () => n.dataset(),
      i
    )
  )
}
function Ve (e) {
  const t = H()
  return o(
    le,
    v(() => t.dataset(), e)
  )
}
function je (e) {
  const t = H()
  return o(
    fe,
    v(() => t.dataset(), e)
  )
}
function me (e) {
  const t = $(),
    n = H(),
    r = k({ id: n.generateId('input') }, e),
    [a, i, c] = S(r, ['ref', 'style', 'onChange', 'onFocus', 'onBlur'], Ae),
    { fieldProps: u } = Be(i)
  return o(
    M,
    v(
      {
        as: 'input',
        ref (f) {
          var g = G(n.setInputRef, a.ref)
          typeof g == 'function' && g(f)
        },
        type: 'checkbox',
        role: 'switch',
        get id () {
          return u.id()
        },
        get name () {
          return t.name()
        },
        get value () {
          return n.value()
        },
        get checked () {
          return n.checked()
        },
        get required () {
          return t.isRequired()
        },
        get disabled () {
          return t.isDisabled()
        },
        get readonly () {
          return t.isReadOnly()
        },
        get style () {
          return wt({ ...at }, a.style)
        },
        get 'aria-checked' () {
          return n.checked()
        },
        get 'aria-label' () {
          return u.ariaLabel()
        },
        get 'aria-labelledby' () {
          return u.ariaLabelledBy()
        },
        get 'aria-describedby' () {
          return u.ariaDescribedBy()
        },
        get 'aria-invalid' () {
          return t.validationState() === 'invalid' || void 0
        },
        get 'aria-required' () {
          return t.isRequired() || void 0
        },
        get 'aria-disabled' () {
          return t.isDisabled() || void 0
        },
        get 'aria-readonly' () {
          return t.isReadOnly() || void 0
        },
        onChange: f => {
          z(f, a.onChange), f.stopPropagation()
          const g = f.target
          n.setIsChecked(g.checked), (g.checked = n.checked())
        },
        onFocus: f => {
          z(f, a.onFocus), n.setIsFocused(!0)
        },
        onBlur: f => {
          z(f, a.onBlur), n.setIsFocused(!1)
        }
      },
      () => t.dataset(),
      () => n.dataset(),
      c
    )
  )
}
function be (e) {
  const t = H()
  return o(
    ge,
    v(() => t.dataset(), e)
  )
}
function ye (e) {
  let t
  const n = `switch-${ue()}`,
    r = k({ value: 'on', id: n }, e),
    [a, i, c] = S(
      r,
      [
        'ref',
        'children',
        'value',
        'checked',
        'defaultChecked',
        'onChange',
        'onPointerDown'
      ],
      Ye
    ),
    [u, s] = P(),
    [d, l] = P(!1),
    { formControlContext: f } = qe(i),
    g = Ln({
      isSelected: () => a.checked,
      defaultIsSelected: () => a.defaultChecked,
      onSelectedChange: p => {
        var O
        return (O = a.onChange) == null ? void 0 : O.call(a, p)
      },
      isDisabled: () => f.isDisabled(),
      isReadOnly: () => f.isReadOnly()
    })
  Ne(
    () => t,
    () => g.setIsSelected(a.defaultChecked ?? !1)
  )
  const x = p => {
      z(p, a.onPointerDown), d() && p.preventDefault()
    },
    h = _(() => ({ 'data-checked': g.isSelected() ? '' : void 0 })),
    w = {
      value: () => a.value,
      dataset: h,
      checked: () => g.isSelected(),
      inputRef: u,
      generateId: se(() => y(i.id)),
      toggle: () => g.toggle(),
      setIsChecked: p => g.setIsSelected(p),
      setIsFocused: l,
      setInputRef: s
    }
  return o(de.Provider, {
    value: f,
    get children () {
      return o(He.Provider, {
        value: w,
        get children () {
          return o(
            M,
            v(
              {
                as: 'div',
                ref (p) {
                  var O = G(q => (t = q), a.ref)
                  typeof O == 'function' && O(p)
                },
                role: 'group',
                get id () {
                  return y(i.id)
                },
                onPointerDown: x
              },
              () => f.dataset(),
              h,
              c,
              {
                get children () {
                  return o(Rn, {
                    state: w,
                    get children () {
                      return a.children
                    }
                  })
                }
              }
            )
          )
        }
      })
    }
  })
}
function Rn (e) {
  const t = lt(() => {
    const n = e.children
    return it(n) ? n(e.state) : n
  })
  return _(t)
}
function ve (e) {
  const t = $(),
    n = H(),
    r = k({ id: n.generateId('thumb') }, e)
  return o(
    M,
    v(
      { as: 'div' },
      () => t.dataset(),
      () => n.dataset(),
      r
    )
  )
}
var Yn = Object.assign(ye, {
  Control: he,
  Description: Ve,
  ErrorMessage: je,
  Input: me,
  Label: be,
  Thumb: ve
})
const qn = ye,
  An = e => {
    const [t, n] = S(e, ['class', 'children'])
    return [
      o(me, {
        get class () {
          return D(
            '[&:focus-visible+div]:outline-none [&:focus-visible+div]:ring-2 [&:focus-visible+div]:ring-ring [&:focus-visible+div]:ring-offset-2 [&:focus-visible+div]:ring-offset-background',
            t.class
          )
        }
      }),
      o(
        he,
        v(
          {
            get class () {
              return D(
                'inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent bg-input transition-[color,background-color,box-shadow] data-[disabled]:cursor-not-allowed data-[checked]:bg-primary data-[disabled]:opacity-50',
                t.class
              )
            }
          },
          n,
          {
            get children () {
              return t.children
            }
          }
        )
      )
    ]
  },
  Bn = e => {
    const [t, n] = S(e, ['class'])
    return o(
      ve,
      v(
        {
          get class () {
            return D(
              'pointer-events-none block size-4 translate-x-0 rounded-full bg-background shadow-lg ring-0 transition-transform data-[checked]:translate-x-4',
              t.class
            )
          }
        },
        n
      )
    )
  },
  Nn = e => {
    const [t, n] = S(e, ['class'])
    return o(
      be,
      v(
        {
          get class () {
            return D(
              'text-sm font-medium leading-none data-[disabled]:cursor-not-allowed',
              t.class
            )
          }
        },
        n
      )
    )
  }
var zn = {}
oe(zn, { Fallback: () => Xe, Image: () => Hn, Img: () => we, Root: () => xe })
var Qe = U()
function Ge () {
  const e = Z(Qe)
  if (e === void 0)
    throw new Error(
      '[kobalte]: `useImageContext` must be used within an `Image.Root` component'
    )
  return e
}
function Xe (e) {
  const t = Ge(),
    [n, r] = P(t.fallbackDelay() === void 0)
  return (
    F(() => {
      const a = t.fallbackDelay()
      if (a !== void 0) {
        const i = window.setTimeout(() => r(!0), a)
        L(() => window.clearTimeout(i))
      }
    }),
    o(E, {
      get when () {
        return _(() => !!n())() && t.imageLoadingStatus() !== 'loaded'
      },
      get children () {
        return o(M, v({ as: 'span' }, e))
      }
    })
  )
}
function we (e) {
  const t = Ge(),
    [n, r] = P('idle')
  return (
    F(
      ce(
        () => e.src,
        a => {
          if (!a) {
            r('error')
            return
          }
          let i = !0
          const c = new window.Image(),
            u = s => () => {
              i && r(s)
            }
          r('loading'),
            (c.onload = u('loaded')),
            (c.onerror = u('error')),
            (c.src = a),
            L(() => {
              i = !1
            })
        }
      )
    ),
    F(() => {
      const a = n()
      a !== 'idle' && t.onImageLoadingStatusChange(a)
    }),
    o(E, {
      get when () {
        return n() === 'loaded'
      },
      get children () {
        return o(M, v({ as: 'img' }, e))
      }
    })
  )
}
function xe (e) {
  const [t, n] = S(e, ['fallbackDelay', 'onLoadingStatusChange']),
    [r, a] = P('idle'),
    i = {
      fallbackDelay: () => t.fallbackDelay,
      imageLoadingStatus: r,
      onImageLoadingStatusChange: c => {
        var u
        a(c), (u = t.onLoadingStatusChange) == null || u.call(t, c)
      }
    }
  return o(Qe.Provider, {
    value: i,
    get children () {
      return o(M, v({ as: 'span' }, n))
    }
  })
}
var Hn = Object.assign(xe, { Fallback: Xe, Img: we })
const re = e => {
    const [t, n] = S(e, ['class'])
    return o(
      xe,
      v(
        {
          get class () {
            return D(
              'relative flex size-10 shrink-0 overflow-hidden rounded-full',
              t.class
            )
          }
        },
        n
      )
    )
  },
  ae = e => {
    const [t, n] = S(e, ['class'])
    return o(
      we,
      v(
        {
          get class () {
            return D('aspect-square size-full', t.class)
          }
        },
        n
      )
    )
  },
  Vn = window
function jn (e, t, n = {}) {
  const { window: r = Vn, ...a } = n
  let i
  const c = () => r && 'ResizeObserver' in r,
    u = () => {
      i && (i.disconnect(), (i = void 0))
    },
    s = _(() => {
      const l = e()
      return Array.isArray(l) ? l : [l]
    })
  ft(() => {
    const l = s()
    if ((u(), c() && r)) {
      i = new ResizeObserver(t)
      for (const f of l) f && i.observe(f, a)
    }
  })
  const d = () => {
    u()
  }
  return L(d), { stop: d }
}
var Qn = {}
oe(Qn, {
  Description: () => le,
  ErrorMessage: () => fe,
  Input: () => pe,
  Label: () => ge,
  Root: () => Se,
  TextArea: () => Ze,
  TextField: () => Xn
})
var Ke = U()
function Je () {
  const e = Z(Ke)
  if (e === void 0)
    throw new Error(
      '[kobalte]: `useTextFieldContext` must be used within a `TextField` component'
    )
  return e
}
function pe (e) {
  return o(Ue, v({ type: 'text' }, e))
}
function Ue (e) {
  const t = $(),
    n = Je(),
    r = k({ id: n.generateId('input') }, e),
    [a, i, c] = S(r, ['onInput'], Ae),
    { fieldProps: u } = Be(i)
  return o(
    M,
    v(
      {
        as: 'input',
        get id () {
          return u.id()
        },
        get name () {
          return t.name()
        },
        get value () {
          return n.value()
        },
        get required () {
          return t.isRequired()
        },
        get disabled () {
          return t.isDisabled()
        },
        get readonly () {
          return t.isReadOnly()
        },
        get 'aria-label' () {
          return u.ariaLabel()
        },
        get 'aria-labelledby' () {
          return u.ariaLabelledBy()
        },
        get 'aria-describedby' () {
          return u.ariaDescribedBy()
        },
        get 'aria-invalid' () {
          return t.validationState() === 'invalid' || void 0
        },
        get 'aria-required' () {
          return t.isRequired() || void 0
        },
        get 'aria-disabled' () {
          return t.isDisabled() || void 0
        },
        get 'aria-readonly' () {
          return t.isReadOnly() || void 0
        },
        get onInput () {
          return Te([a.onInput, n.onInput])
        }
      },
      () => t.dataset(),
      c
    )
  )
}
function Se (e) {
  let t
  const n = `textfield-${ue()}`,
    r = k({ id: n }, e),
    [a, i, c] = S(r, ['ref', 'value', 'defaultValue', 'onChange'], Ye),
    u = a.value,
    [s, d] = ze({
      value: () => (u === void 0 ? void 0 : a.value ?? ''),
      defaultValue: () => a.defaultValue,
      onChange: x => {
        var h
        return (h = a.onChange) == null ? void 0 : h.call(a, x)
      }
    }),
    { formControlContext: l } = qe(i)
  Ne(
    () => t,
    () => d(a.defaultValue ?? '')
  )
  const f = x => {
      if (l.isReadOnly() || l.isDisabled()) return
      const h = x.target
      d(h.value), (h.value = s() ?? '')
    },
    g = { value: s, generateId: se(() => y(i.id)), onInput: f }
  return o(de.Provider, {
    value: l,
    get children () {
      return o(Ke.Provider, {
        value: g,
        get children () {
          return o(
            M,
            v(
              {
                as: 'div',
                ref (x) {
                  var h = G(w => (t = w), a.ref)
                  typeof h == 'function' && h(x)
                },
                role: 'group',
                get id () {
                  return y(i.id)
                }
              },
              () => l.dataset(),
              c
            )
          )
        }
      })
    }
  })
}
function Ze (e) {
  let t
  const n = Je(),
    r = k({ id: n.generateId('textarea') }, e),
    [a, i] = S(r, ['ref', 'autoResize', 'submitOnEnter', 'onKeyPress'])
  F(
    ce([() => t, () => a.autoResize, () => n.value()], ([u, s]) => {
      !u || !s || Gn(u)
    })
  )
  const c = u => {
    t &&
      a.submitOnEnter &&
      u.key === 'Enter' &&
      !u.shiftKey &&
      t.form &&
      (t.form.requestSubmit(), u.preventDefault())
  }
  return o(
    Ue,
    v(
      {
        as: 'textarea',
        get 'aria-multiline' () {
          return a.submitOnEnter ? 'false' : void 0
        },
        get onKeyPress () {
          return Te([a.onKeyPress, c])
        },
        ref (u) {
          var s = G(d => (t = d), a.ref)
          typeof s == 'function' && s(u)
        }
      },
      i
    )
  )
}
function Gn (e) {
  const t = e.style.alignSelf,
    n = e.style.overflow
  'MozAppearance' in e.style || (e.style.overflow = 'hidden'),
    (e.style.alignSelf = 'start'),
    (e.style.height = 'auto'),
    (e.style.height = `${
      e.scrollHeight + (e.offsetHeight - e.clientHeight)
    }px`),
    (e.style.overflow = n),
    (e.style.alignSelf = t)
}
var Xn = Object.assign(Se, {
  Description: le,
  ErrorMessage: fe,
  Input: pe,
  Label: ge,
  TextArea: Ze
})
const Kn = e => {
    const [t, n] = S(e, ['class'])
    return o(
      Se,
      v(
        {
          get class () {
            return D('flex flex-col gap-1', t.class)
          }
        },
        n
      )
    )
  },
  Jn = e => {
    const t = v({ type: 'text' }, e),
      [n, r] = S(t, ['type', 'class'])
    return o(
      pe,
      v(
        {
          get type () {
            return n.type
          },
          get class () {
            return D(
              'flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[invalid]:border-error-foreground data-[invalid]:text-error-foreground',
              n.class
            )
          }
        },
        r
      )
    )
  }
var Un = C(
    '<main class="max-h-fit w-full max-w-[350px] overflow-auto bg-background">'
  ),
  Zn = C('<div class="flex h-[350px] w-full items-center justify-center">'),
  er = C(
    '<header class="flex w-full items-center justify-between border-b border-border px-5 py-2.5"><h1 class="text-base text-foreground">MuhammadZaz❤️ CodeCracker⚡'
  ),
  tr = C(
    '<footer class="border-t border-border px-5 pb-4 pt-2.5 text-center text-xs text-muted-foreground">'
  ),
  nr = C('<span class="text-xs text-success-foreground">Active'),
  rr = C(
    '<div class="flex items-center gap-1 border-b border-border px-5 py-2.5"><span class="mr-auto text-xs text-muted-foreground">'
  ),
  ar = C(
    '<div class="flex flex-col items-center gap-1.5 border-b border-border px-5 py-6 text-center [&amp;>picture]:size-10 [&amp;>h2]:text-sm [&amp;>h2]:leading-none [&amp;>h2]:text-foreground [&amp;>p]:text-xs [&amp;>p]:font-medium [&amp;>p]:leading-5 [&amp;>p]:text-muted-foreground"><h2>Login Account</h2><p>In order to use the extension, please log in to your vulms account.'
  ),
  ir = C(
    '<div class="flex flex-col items-center gap-1.5 border-b border-border px-5 py-6 text-center [&amp;>picture]:size-10 [&amp;>h2]:text-sm [&amp;>h2]:leading-none [&amp;>h2]:text-foreground [&amp;>p]:text-xs [&amp;>p]:font-medium [&amp;>p]:leading-5 [&amp;>p]:text-muted-foreground"><h2>Login Detected</h2><p> - '
  ),
  sr = C('<span>Activate'),
  or = C(
    '<div class="flex flex-col items-center gap-1.5 border-b border-border px-5 py-6 text-center [&amp;>picture]:size-10 [&amp;>h2]:text-sm [&amp;>h2]:leading-none [&amp;>h2]:text-foreground [&amp;>p]:text-xs [&amp;>p]:font-medium [&amp;>p]:leading-5 [&amp;>p]:text-muted-foreground"><h2>Activate License</h2><div class="flex items-center gap-1.5">'
  ),
  ur = C('<span>Buy License'),
  cr = C(
    '<div class="flex flex-col items-center gap-1.5 border-b border-border px-5 py-6 text-center [&amp;>picture]:size-10 [&amp;>h2]:text-sm [&amp;>h2]:leading-none [&amp;>h2]:text-foreground [&amp;>p]:text-xs [&amp;>p]:font-medium [&amp;>p]:leading-5 [&amp;>p]:text-muted-foreground"><h2>$<!> / Semester</h2><p>This subscription covers only the <!> semester and will expire on <!>.</p><div class="flex items-center gap-1.5">'
  ),
  dr = C(
    '<span class="text-xs text-error-foreground">Non-Active - <span class=text-primary>Buy Plan'
  ),
  lr = C('<div class="pb-8 pt-1.5">')
function fr () {
  const {
      status: e,
      user: t,
      semester: n,
      continueAs: r,
      processing: a,
      loginAs: i,
      checkLogin: c,
      activateLicense: u
    } = gt(!0),
    [s, d] = P()
  return (
    jn(s, () => {
      requestIdleCallback(() => {
        const l = `${s().scrollHeight}px`
        ;(document.body.style.height = l),
          (document.documentElement.style.height = l)
      })
    }),
    ht(() => {
      c()
    }),
    (() => {
      var l = Un()
      return (
        ot(d, l),
        m(
          l,
          o(E, {
            get when () {
              return !a()
            },
            get fallback () {
              return o(gr, {})
            },
            get children () {
              return [
                o(hr, {
                  get semesterName () {
                    var f
                    return (f = n()) == null ? void 0 : f.name
                  }
                }),
                o(br, {
                  get status () {
                    return e()
                  },
                  get user () {
                    return t()
                  },
                  get continueAs () {
                    return r()
                  },
                  get processing () {
                    return a()
                  },
                  loginAs: i,
                  get semester () {
                    return n()
                  },
                  activateLicense: u
                }),
                o(yr, {
                  get disabled () {
                    return !t()
                  }
                }),
                o(mr, {
                  get expireDate () {
                    return _(() => e() !== N.Subscribed)()
                      ? void 0
                      : n().end_date
                  }
                })
              ]
            }
          }),
          null
        ),
        m(l, o(xt, {}), null),
        l
      )
    })()
  )
}
function gr () {
  return (() => {
    var e = Zn()
    return m(e, o(ie, { class: 'size-8 text-primary' })), e
  })()
}
function hr (e) {
  return (() => {
    var t = er()
    return (
      t.firstChild,
      m(
        t,
        o(Fn, {
          variant: 'outline',
          class: 'font-medium',
          get children () {
            return e.semesterName ?? 'No Semester'
          }
        }),
        null
      ),
      t
    )
  })()
}
function mr (e) {
  return (() => {
    var t = tr()
    return (
      m(
        t,
        (() => {
          var n = _(() => !!e.expireDate)
          return () =>
            n()
              ? `Subscription will expire on ${Re(
                  e.expireDate,
                  'dd MMMM yyyy'
                )}`
              : 'No active subscription found'
        })()
      ),
      t
    )
  })()
}
function br (e) {
  const [t, n] = P(!1),
    [r, a] = P(!1),
    [i, c] = P('')
  async function u () {
    if (e.activateLicense)
      try {
        n(!0)
        const s = await e.activateLicense(i())
        s.success ? te.success(s.message) : te.error(s.message)
      } catch (s) {
        console.error(s), te.error((s == null ? void 0 : s.message) ?? s)
      } finally {
        n(!1)
      }
  }
  return [
    o(E, {
      get when () {
        return e.user
      },
      get children () {
        var s = rr(),
          d = s.firstChild
        return (
          m(
            s,
            o(re, {
              class: 'size-4',
              get children () {
                return o(ae, {
                  get alt () {
                    return e.user.name
                  },
                  src: 'https://vulms.vu.edu.pk/Profile/GridImageTemplate.aspx',
                  referrerpolicy: 'no-referrer',
                  class: 'scale-y-120'
                })
              }
            }),
            d
          ),
          m(d, () => e.user.id),
          m(
            s,
            o(E, {
              get when () {
                return e.status === N.Subscribed
              },
              get fallback () {
                return dr()
              },
              get children () {
                return nr()
              }
            }),
            null
          ),
          s
        )
      }
    }),
    o(bt, {
      get children () {
        return [
          o(X, {
            get when () {
              return e.status === N.LoggedOut
            },
            get children () {
              var s = ar(),
                d = s.firstChild
              return (
                d.nextSibling,
                m(
                  s,
                  o(re, {
                    as: 'picture',
                    get children () {
                      return o(ae, {
                        alt: 'Default Avatar',
                        get src () {
                          return ut('/assets/default-avatar.jpeg')
                        }
                      })
                    }
                  }),
                  d
                ),
                m(
                  s,
                  o(A, {
                    as: 'a',
                    variant: 'secondary',
                    size: 'sm',
                    href: 'https://vulms.vu.edu.pk',
                    target: '_blank',
                    referrerpolicy: 'no-referrer',
                    get disabled () {
                      return e.processing
                    },
                    children: 'Open VULMS'
                  }),
                  null
                ),
                s
              )
            }
          }),
          o(X, {
            get when () {
              return e.status === N.ContinueAs
            },
            get children () {
              var s = ir(),
                d = s.firstChild,
                l = d.nextSibling,
                f = l.firstChild
              return (
                m(
                  s,
                  o(re, {
                    as: 'picture',
                    get children () {
                      return o(ae, {
                        get alt () {
                          return e.continueAs.name
                        },
                        src: 'https://vulms.vu.edu.pk/Profile/GridImageTemplate.aspx',
                        referrerpolicy: 'no-referrer',
                        class: 'scale-y-120'
                      })
                    }
                  }),
                  d
                ),
                m(l, () => e.continueAs.name, f),
                m(l, () => e.continueAs.id, null),
                m(
                  s,
                  o(A, {
                    variant: 'secondary',
                    size: 'sm',
                    onClick: () => {
                      var g
                      return (g = e.loginAs) == null
                        ? void 0
                        : g.call(e, e.continueAs)
                    },
                    get disabled () {
                      return e.processing
                    },
                    children: 'Yes, Continue'
                  }),
                  null
                ),
                s
              )
            }
          }),
          o(X, {
            get when () {
              return _(() => !!(e.status === N.LoggedIn && e.semester))() && r()
            },
            get children () {
              var s = or(),
                d = s.firstChild,
                l = d.nextSibling
              return (
                m(
                  s,
                  o(Kn, {
                    get value () {
                      return i()
                    },
                    onChange: c,
                    class: 'my-2 w-full',
                    get children () {
                      return o(Jn, { placeholder: 'Enter your License key...' })
                    }
                  }),
                  l
                ),
                m(
                  l,
                  o(A, {
                    class: 'relative',
                    variant: 'secondary',
                    size: 'sm',
                    onClick: u,
                    get disabled () {
                      return t() || !i().length
                    },
                    get children () {
                      return [
                        o(E, {
                          get when () {
                            return t()
                          },
                          get children () {
                            return o(ie, { class: 'absolute m-auto size-3.5' })
                          }
                        }),
                        (() => {
                          var f = sr()
                          return Pe(() => Ce(f, D(t() && 'opacity-0'))), f
                        })()
                      ]
                    }
                  }),
                  null
                ),
                m(
                  l,
                  o(A, {
                    variant: 'link',
                    size: 'sm',
                    onClick: () => a(!1),
                    get disabled () {
                      return t()
                    },
                    children: 'Back'
                  }),
                  null
                ),
                s
              )
            }
          }),
          o(X, {
            get when () {
              return e.status === N.LoggedIn && e.semester
            },
            get children () {
              var s = cr(),
                d = s.firstChild,
                l = d.firstChild,
                f = l.nextSibling
              f.nextSibling
              var g = d.nextSibling,
                x = g.firstChild,
                h = x.nextSibling,
                w = h.nextSibling,
                p = w.nextSibling
              p.nextSibling
              var O = g.nextSibling
              return (
                m(d, () => e.semester.price, f),
                m(g, () => e.semester.name, h),
                m(g, () => Re(e.semester.end_date, 'dd MMMM yyyy'), p),
                m(
                  O,
                  o(A, {
                    as: 'a',
                    class: 'relative',
                    variant: 'secondary',
                    size: 'sm',
                    href: mt + '/license/purchase',
                    target: '_blank',
                    get disabled () {
                      return t() || e.processing
                    },
                    get children () {
                      return [
                        o(E, {
                          get when () {
                            return t()
                          },
                          get children () {
                            return o(ie, { class: 'absolute m-auto size-3.5' })
                          }
                        }),
                        (() => {
                          var q = ur()
                          return Pe(() => Ce(q, D(t() && 'opacity-0'))), q
                        })()
                      ]
                    }
                  }),
                  null
                ),
                m(
                  O,
                  o(A, {
                    variant: 'link',
                    size: 'sm',
                    onClick: () => a(!0),
                    children: 'Activate'
                  }),
                  null
                ),
                s
              )
            }
          })
        ]
      }
    })
  ]
}
function yr (e) {
  const t = pt(),
    n = r => a => {
      t.set({ [r]: a })
    }
  return (() => {
    var r = lr()
    return (
      m(
        r,
        o(R, {
          value: !0,
          disabled: !0,
          children: 'Bypass VU Firewall Extension'
        }),
        null
      ),
      m(
        r,
        o(R, {
          get value () {
            return t().quizSolver
          },
          get onChange () {
            return n('quizSolver')
          },
          get disabled () {
            return e.disabled
          },
          children: 'A.I Quiz Solver'
        }),
        null
      ),
      m(
        r,
        o(R, {
          get value () {
            return t().mathLatex
          },
          get onChange () {
            return n('mathLatex')
          },
          get disabled () {
            return e.disabled
          },
          children: 'Math Latex Support'
        }),
        null
      ),
      m(
        r,
        o(R, {
          get value () {
            return t().lectureSkip
          },
          get onChange () {
            return n('lectureSkip')
          },
          get disabled () {
            return e.disabled
          },
          children: 'One-click Lecture Skip'
        }),
        null
      ),
      m(
        r,
        o(R, {
          get value () {
            return t().printQuiz
          },
          get onChange () {
            return n('printQuiz')
          },
          get disabled () {
            return e.disabled
          },
          children: 'Print Quiz PDFs'
        }),
        null
      ),
      m(
        r,
        o(R, {
          get value () {
            return t().quizCopyPaste
          },
          get onChange () {
            return n('quizCopyPaste')
          },
          get disabled () {
            return e.disabled
          },
          children: 'Allow Quiz Copy/Paste'
        }),
        null
      ),
      m(
        r,
        o(R, {
          get value () {
            return t().gdbCopyPaste
          },
          get onChange () {
            return n('gdbCopyPaste')
          },
          get disabled () {
            return e.disabled
          },
          children: 'Allow GDB Copy/Paste'
        }),
        null
      ),
      r
    )
  })()
}
function R (e) {
  return o(qn, {
    class: 'flex items-center px-5 py-1.5',
    get checked () {
      return e.value
    },
    get onChange () {
      return e.onChange
    },
    get disabled () {
      return e.disabled
    },
    get children () {
      return [
        o(Nn, {
          class: 'grow text-sm font-normal',
          get children () {
            return e.children
          }
        }),
        o(An, {
          get children () {
            return o(Bn, {})
          }
        })
      ]
    }
  })
}
yt(vt.Popup)
ct(fr, document.getElementById('app'))
