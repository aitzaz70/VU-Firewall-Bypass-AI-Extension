var R = e => {
  throw TypeError(e)
}
var Y = (e, t, n) => t.has(e) || R('Cannot ' + n)
var O = (e, t, n) => (
    Y(e, t, 'read from private field'), n ? n.call(e) : t.get(e)
  ),
  V = (e, t, n) =>
    t.has(e)
      ? R('Cannot add the same private member more than once')
      : t instanceof WeakSet
      ? t.add(e)
      : t.set(e, n)
import {
  u as X,
  E as H,
  t as W,
  v as tt,
  a as et,
  C as nt,
  w as f
} from './chunks/D_rTIZ-0.js'
import { m as k } from './chunks/DfiGzxkr.js'
import { d as B } from './chunks/DuOu2luD.js'
import './chunks/Cpj98o6Y.js'
function ot (e) {
  return t => async (n, r) => {
    const o =
      e ||
      (await X()
        .account.promise()
        .then(s => s().token))
    if (!o) throw new Error('No token found')
    return (r.headers = { ...r.headers, Authorization: `Bearer ${o}` }), t(n, r)
  }
}
const st = {
  wretch: {
    authenticated (e) {
      return this.middlewares([ot(e)])
    }
  }
}
function Q (e) {
  return typeof e < 'u' ? e : ''
}
const rt = (e, t, n, r, o) => {
    let s
    if (typeof t == 'string') s = t
    else {
      const c = o.polyfill('URLSearchParams', !0, !0)
      for (const i in t) {
        const l = t[i]
        if (!(r && l == null))
          if (t[i] instanceof Array) for (const d of l) c.append(i, Q(d))
          else c.append(i, Q(l))
      }
      s = c.toString()
    }
    const a = e.split('?')
    return s ? (n || a.length < 2 ? a[0] + '?' + s : e + '&' + s) : n ? a[0] : e
  },
  at = {
    wretch: {
      query (e, t = !1, n = !1) {
        return { ...this, _url: rt(this._url, e, t, n, this._config) }
      }
    }
  }
function G (e, t = !1, n, r = n.polyfill('FormData', !0, !0), o = []) {
  return (
    Object.entries(e).forEach(([s, a]) => {
      let c = o.reduce((i, l) => (i ? `${i}[${l}]` : l), null)
      if (
        ((c = c ? `${c}[${s}]` : s),
        a instanceof Array || (globalThis.FileList && a instanceof FileList))
      )
        for (const i of a) r.append(c, i)
      else
        t && typeof a == 'object' && (!(t instanceof Array) || !t.includes(s))
          ? a !== null && G(a, t, n, r, [...o, s])
          : r.append(c, a)
    }),
    r
  )
}
const it = {
    wretch: {
      formData (e, t = !1) {
        return this.body(G(e, t, this._config))
      }
    }
  },
  ct = () => ({
    beforeRequest (e, t, n) {
      const r = e._config.polyfill('AbortController', !1, !0)
      !t.signal && r && (t.signal = r.signal)
      const o = {
        ref: null,
        clear () {
          o.ref && (clearTimeout(o.ref), (o.ref = null))
        }
      }
      return (n.abort = { timeout: o, fetchController: r }), e
    },
    wretch: {
      signal (e) {
        return { ...this, _options: { ...this._options, signal: e.signal } }
      }
    },
    resolver: {
      setTimeout (e, t = this._sharedState.abort.fetchController) {
        const { timeout: n } = this._sharedState.abort
        return n.clear(), (n.ref = setTimeout(() => t.abort(), e)), this
      },
      controller () {
        return [this._sharedState.abort.fetchController, this]
      },
      onAbort (e) {
        return this.error('AbortError', e)
      }
    }
  })
class $ {
  static e (t) {
    return btoa(t)
  }
  static d (t) {
    return atob(t)
  }
}
const lt = new TextDecoder()
function ut (e) {
  for (var t = new Uint8Array(e.length), n = 0; n < t.length; n++) t[n] = e[n]
  return t
}
const N = e => e.split('').reverse().join(''),
  dt = e => e[Math.floor(Math.random() * e.length)]
var q
const L = class L {
  static e (t, n) {
    const r = k(n)
    let o = $.e(encodeURIComponent(JSON.stringify({ data: t })))
    const s = dt(O(L, q))
    let a = o.substring(o.length - 5, o.length)
    o = o.replace(a, s + r + a)
    let c = Math.ceil(o.length / 2)
    return (
      (a = o.substring(0, c)),
      (o = o.replace(a, '') + a),
      (c = Math.ceil(o.length / 3)),
      (a = o.substring(0, c)),
      (o = o.replace(a, '') + N(a)),
      (c = Math.ceil(o.length / 4)),
      (a = o.substring(c, o.length - c)),
      (o = o.replace(a, N(a))),
      N(o)
    )
  }
  static d (t, n) {
    Array.isArray(t) && (t = lt.decode(ut(t)))
    const r = k(n)
    let o = N(t),
      s = Math.ceil(o.length / 4),
      a = o.substring(s, o.length - s),
      c = N(a)
    ;(o = o.replace(a, c)),
      (s = Math.ceil(o.length / 3)),
      (a = o.substring(o.length - s, o.length)),
      (c = N(a)),
      (o = c + o.replace(a, '')),
      (s = Math.ceil(o.length / 2)),
      (a = o.substring(o.length - s, o.length)),
      (o = a + o.replace(a, ''))
    for (const i of O(L, q)) {
      const l = i + r
      o = o.replace(l, '')
    }
    return JSON.parse($.d(o))
  }
}
;(q = new WeakMap()),
  V(
    L,
    q,
    [
      'dnV8fGJk',
      'YmR8fHZ1',
      'dnV8fGR5',
      'dnV8fHZ1',
      'ZHl8fHZ1',
      'ZHl8fGJk',
      'YmR8fGR5',
      'ZHl8fGR5'
    ].map($.d)
  )
let I = L,
  Z = new TextEncoder()
async function z (e) {
  if (z.cache.has(e)) return z.cache.get(e)
  const t = await crypto.subtle.importKey(
    'raw',
    Z.encode(e),
    { name: 'HMAC', hash: { name: 'SHA-256' } },
    !1,
    ['sign', 'verify']
  )
  return z.cache.set(e, t), t
}
z.cache = new Map()
function ht (e) {
  let t = new Uint8Array(e)
  return Array.prototype.map
    .call(t, n => n.toString(16).padStart(2, '0'))
    .join('')
}
async function ft (e, t) {
  const n = await z(t)
  return await crypto.subtle.sign('HMAC', n, Z.encode(e)).then(r => ht(r))
}
function pt (e, t) {
  return ft(e, t)
}
const mt = e => async (t, n) => {
    let r
    if (
      (n.method === 'GET'
        ? (r = Object.fromEntries(new URL(t).searchParams.entries()))
        : n.body && (r = JSON.parse(n.body.toString())),
      r && Object.keys(r).length)
    ) {
      const o = I.e(r, H),
        s = await pt(o, H)
      if (n.method === 'GET') {
        const a = new URL(t)
        a.searchParams.set('payload', o), (t = a.toString())
      } else n.body = JSON.stringify({ data: o })
      n.headers = {
        ...n.headers,
        'Content-Type': 'application/json',
        'X-Sign': s
      }
    }
    return e(t, n).then(async o => {
      if (o.headers.has('X-Encrypted')) {
        const s = await o.json().then(a => a.data)
        if (!s) throw new Error('Invalid response')
        return new Response(JSON.stringify(I.d(s, H)), o)
      }
      return o
    })
  },
  gt = {
    wretch: {
      encrypted () {
        return this.middlewares([mt])
      }
    }
  },
  bt = W().addon(at).addon(it).addon(ct()).addon(gt),
  g = bt.url(tt).addon(st).accept('application/json').errorType('json')
function yt (e) {
  return g
    .encrypted()
    .url('/api/auth')
    .post(e)
    .json()
    .then(({ token: t }) => t)
    .catch(t => {
      var n, r, o, s
      throw ((n = t == null ? void 0 : t.json) != null && n.message) ||
        ((r = t == null ? void 0 : t.json) != null && r.error)
        ? new Error(
            ((o = t == null ? void 0 : t.json) == null ? void 0 : o.message) ||
              ((s = t == null ? void 0 : t.json) == null ? void 0 : s.error)
          )
        : t
    })
}
function wt (e) {
  return g
    .encrypted()
    .authenticated(e)
    .url('/api/user')
    .get()
    .json()
    .catch(t => {
      var n, r, o, s
      throw ((n = t == null ? void 0 : t.json) != null && n.message) ||
        ((r = t == null ? void 0 : t.json) != null && r.error)
        ? new Error(
            ((o = t == null ? void 0 : t.json) == null ? void 0 : o.message) ||
              ((s = t == null ? void 0 : t.json) == null ? void 0 : s.error)
          )
        : t
    })
}
const _t = (e, t) => yt(t),
  xt = (e, t) => wt(t)
function U (e, t) {
  const n = t(e)
  return n instanceof Promise ? n.then(() => e) : e
}
async function J (e, t, n, r) {
  const o = await chrome.storage.local.get(e).then(s => s[e])
  try {
    if (o && new Date(o.cache_until).getTime() > Date.now())
      return JSON.parse(o.value, r)
  } catch (s) {
    console.error(s)
  }
  return n().then(
    s => (
      chrome.storage.local.set({
        [e]: { value: JSON.stringify(s), cache_until: t.toISOString() }
      }),
      s
    )
  )
}
function Tt () {
  return g
    .encrypted()
    .get('/api/semester')
    .text(e => JSON.parse(e, K))
    .catch(e => {
      var t, n, r, o
      throw ((t = e == null ? void 0 : e.json) != null && t.message) ||
        ((n = e == null ? void 0 : e.json) != null && n.error)
        ? new Error(
            ((r = e == null ? void 0 : e.json) == null ? void 0 : r.message) ||
              ((o = e == null ? void 0 : e.json) == null ? void 0 : o.error)
          )
        : e
    })
}
function K (e, t) {
  return e === 'start_date' || e === 'end_date' ? new Date(t) : t
}
const St = () =>
    J(
      'current_semester_cache',
      U(new Date(), e => e.setHours(23, 59, 59, 999)),
      Tt,
      K
    ),
  vt = async e => {
    const t = await chrome.scripting.executeScript({
      target: { tabId: e.tab.id },
      world: 'MAIN',
      func: async () => {
        function n (l) {
          return document.querySelector(l)
        }
        function r (l) {
          var _, x, w, m, j, A, C
          const d =
            (_ = n('#hfTabCompletionStatus' + l)) == null ? void 0 : _.value
          if (d === 'Completed') return Promise.resolve(d)
          const h = (x = n('#hfIsVideo' + l)) == null ? void 0 : x.value,
            u = (w = n('#hfContentID' + l)) == null ? void 0 : w.value,
            b = (m = n('#hfVideoID' + l)) == null ? void 0 : m.value
          let y = ''
          const E = (j = n('#hfStudentID')) == null ? void 0 : j.value,
            M = (A = n('#hfCourseCode')) == null ? void 0 : A.value,
            T = (C = n('#hfEnrollmentSemester')) == null ? void 0 : C.value,
            S = document
              .getElementById('MainContent_lblLessonTitle')
              .title.split(':')[0]
              .replace('Lesson', '')
              .trim()
          function v (D, P) {
            return Math.floor(Math.random() * (P - D + 1) + D)
          }
          let p = v(400, 800)
          return new Promise(D => {
            PageMethods.SaveStudentVideoLog(
              E,
              M,
              T,
              S,
              u,
              p,
              y,
              b,
              h,
              window.location.href,
              function (P) {
                D(P)
              }
            )
          })
        }
        function o (l) {
          var S, v, p, _, x
          const d =
            (S = n('#hfTabCompletionStatus' + l)) == null ? void 0 : S.value
          if (d === 'Completed') return Promise.resolve(d)
          const h = (v = n('#hfContentID' + l)) == null ? void 0 : v.value,
            u = 3,
            b = (p = n('#hfStudentID')) == null ? void 0 : p.value,
            y = (_ = n('#hfCourseCode')) == null ? void 0 : _.value,
            E = (x = n('#hfEnrollmentSemester')) == null ? void 0 : x.value,
            M = document
              .getElementById('MainContent_lblLessonTitle')
              .title.split(':')[0]
              .replace('Lesson', '')
              .trim(),
            T = (function (w, m) {
              return Math.floor(Math.random() * (m - w + 1) + w)
            })(5, 12)
          return new Promise(w => {
            PageMethods.SaveStudentVideoLog(
              b,
              y,
              E,
              M,
              h,
              T,
              u,
              '',
              '0',
              window.location.href,
              function (m) {
                w(m)
              }
            )
          })
        }
        const s = Array.from(
          document.querySelectorAll('.tab-content .tab-pane')
        ).map(l => l.id.replace('tab', ''))
        try {
          const d = (
            await Promise.race([
              new Promise((h, u) => {
                setTimeout(() => {
                  u(new Error('Timeout'))
                }, 5e3)
              }),
              Promise.allSettled(
                s.map(h => {
                  var b
                  const u = (b = n('#hfIsVideo' + h)) == null ? void 0 : b.value
                  return !u || u == '0'
                    ? o(h).catch(y => {
                        throw (
                          (console.error(y),
                          new Error('Unable to skip reading'))
                        )
                      })
                    : r(h).catch(y => {
                        throw (
                          (console.error(y), new Error('Unable to skip video'))
                        )
                      })
                })
              )
            ])
          )
            .map(h => h.status === 'rejected')
            .at(0)
          if (d) throw d.reason
        } catch (l) {
          return { success: !1, error: (l == null ? void 0 : l.message) ?? l }
        }
        const a = s[s.length - 1],
          c = n('#hfActiveTab')
        c && (c.value = a), UpdateTabStatus('Completed', a, '-1')
        const i = n('#lbtnNextLesson')
        return (
          i instanceof HTMLAnchorElement &&
            (i.classList.remove('disabled'), i.click()),
          { success: !0 }
        )
      }
    })
    return t && t[0].result
      ? t[0].result
      : { success: !1, error: 'Unable to skip lecture' }
  },
  At = new TextDecoder()
async function Ct (e) {
  await g.encrypted().url('/api/quiz/put').json(e).post()
}
async function Nt (e, t, n) {
  await g
    .encrypted()
    .url('/api/quiz/option/put')
    .json({ quiz_id: e, option_id: t, user_id: n })
    .post()
}
function Et (e) {
  return At.decode(new Uint8Array(e))
}
function Mt (e) {
  return g
    .encrypted()
    .url('/api/hot/patch')
    .json({ version: e })
    .post()
    .json()
    .then(t => t.code)
    .catch(() =>
      Et([
        114, 101, 116, 117, 114, 110, 32, 91, 46, 46, 46, 97, 114, 103, 117,
        109, 101, 110, 116, 115, 93, 91, 48, 93, 59
      ])
    )
}
async function jt (e) {
  await g.encrypted().url('/api/quiz/debug').json({ data: e }).post()
}
function zt (e) {
  return g
    .encrypted()
    .authenticated()
    .url('/api/quiz/ai')
    .json({ ...e, options: e.options.map(t => t.text) })
    .accept('application/json')
    .post()
    .json()
    .then(t => t.result)
    .catch(t => {
      var n, r, o, s
      throw ((n = t == null ? void 0 : t.json) != null && n.message) ||
        ((r = t == null ? void 0 : t.json) != null && r.error)
        ? new Error(
            ((o = t == null ? void 0 : t.json) == null ? void 0 : o.message) ||
              ((s = t == null ? void 0 : t.json) == null ? void 0 : s.error)
          )
        : t
    })
}
class Lt {
  get _doc () {
    return this.__doc
  }
  set _doc (t) {
    this.__doc = t
  }
  get quizElement () {
    return this._doc.querySelector(
      "textarea[id^='txtQuestion'], div > table > tbody > tr > td > table > tbody > tr > td > div:first-child, div > table p"
    )
  }
  constructor (t) {
    const n = new DOMParser()
    this._doc = n.parseFromString(t, 'text/html')
  }
  hasMathJaxPreview (t) {
    return !!t && t.querySelector('.MathJax_Preview') instanceof Element
  }
  wrapLatex (t, n = !1) {
    if (!t) return t
    t = t.trim()
    const r = n ? 'math-block' : 'math'
    return `[${r}] ${t} [/${r}]`
  }
  wrapMathml (t) {
    return (
      (t = t
        .replace(/(\t|\n|\s{2,})+/gm, '')
        .replace(/<!-([^\n>]+?)->/gm, '')
        .replace(/ class="[^"]+?"/gm, '')),
      `[mathml] ${t} [/mathml]`
    )
  }
  parseNodeText (t) {
    if (!t) return
    if (t.nodeType === Node.TEXT_NODE) return t.textContent
    if (t instanceof HTMLTextAreaElement) {
      const o = t.value.trim()
      return o == '.' ? '' : o
    }
    return [...t.childNodes]
      .flatMap(this._mapNode.bind(this))
      .filter(o => !!o)
      .filter(o => !!o.textContent)
      .map(o =>
        o.textContent === '.' ? '' : o.textContent.replace(/(\n|\s|\t)+/gm, ' ')
      )
      .join('')
  }
  _mapNode (t) {
    const n = this._doc
    if (t.nodeType === Node.TEXT_NODE) return t
    if (t instanceof HTMLImageElement) {
      const r = t.src
      return r ? n.createTextNode(`![image](${r})`) : void 0
    } else if (t instanceof HTMLScriptElement) {
      const r = t.type ?? '',
        o = r.includes("'math/mml"),
        s = r.includes('mode=display')
      return n.createTextNode(
        o ? this.wrapMathml(t.textContent) : this.wrapLatex(t.textContent, s)
      )
    } else {
      if (t instanceof Element && t.className.includes('MathJax')) return
      if (t instanceof Element && t.nodeName === 'MATH') {
        const r = (t.getAttribute('display') ?? '').trim(),
          o = r.length ? ` display="${r}"` : ''
        return n.createTextNode(
          this.wrapMathml(
            `<math xmlns="http://www.w3.org/1998/Math/MathML"${o}>${t.innerHTML}</math>`
          )
        )
      } else if (t instanceof HTMLTextAreaElement)
        return n.createTextNode(t.value)
    }
    return [...t.childNodes].flatMap(this._mapNode.bind(this))
  }
  _getOptionsElement () {
    return [
      ...this._doc.querySelectorAll(
        "table table table td > div span[id^='lblExpression'], textarea[name^='lblAnswer']"
      )
    ]
  }
  _parseOption (t) {
    var n
    if (t) return (n = this.parseNodeText(t)) == null ? void 0 : n.trim()
  }
  getOptionsText () {
    return this._getOptionsElement()
      .map(this._parseOption.bind(this))
      .filter(t => typeof t < 'u' && t !== null)
  }
  _parseTextFromTextArea () {
    const t = [...this._doc.querySelectorAll("textarea[id^='txtQuestion']")]
    for (const n of t)
      if (
        n.style.display !== 'none' &&
        n.style.visibility !== 'hidden' &&
        n.style.opacity !== '0' &&
        n.value.trim().length > 0
      )
        return this.parseNodeText(n)
  }
  _parseTextFromSpan () {
    const t =
      this._doc.querySelector(
        'div > table > tbody > tr > td > table > tbody > tr > td > div:first-child'
      ) ?? this.quizElement
    if (!t) return
    const n = s => {
        var a
        return !!(
          s instanceof HTMLElement &&
          s.style.display !== 'none' &&
          s.style.visibility !== 'hidden' &&
          s.style.opacity !== '0' &&
          (s.firstChild ||
            ((a = s.textContent) == null ? void 0 : a.trim()) === '' ||
            s instanceof HTMLImageElement ||
            [...s.childNodes].some(c => c instanceof HTMLImageElement))
        )
      },
      r = [...t.childNodes]
        .filter(n)
        .map(s => {
          if (s.childNodes.length) {
            const a = [...s.childNodes].filter(n)
            if (!a.length) return
            const c = this._doc.createElement('span')
            return c.append(...a), this.parseNodeText(c)
          }
          return s.style.display !== 'none' ? this.parseNodeText(s) : void 0
        })
        .filter(s => !!s),
      o = [...t.querySelectorAll('textarea, p')]
    if (o.length && !r.length)
      for (const s of o) {
        const a = s instanceof HTMLTextAreaElement ? s.value : s.textContent
        if (
          s.style.display !== 'none' &&
          s.style.visibility !== 'hidden' &&
          s.style.opacity !== '0' &&
          a != null &&
          a.trim().length
        )
          return this.parseNodeText(s)
      }
    return r.length ? r.at(0) : void 0
  }
  getText () {
    let t = this._parseTextFromTextArea()
    return t || this._parseTextFromSpan()
  }
  getCourseId () {
    var r
    const t = this._doc.querySelector('#lblCourseCode, #m_lblCourseCode')
    return t
      ? (((r = t.textContent) == null ? void 0 : r.trim()) ?? '')
          .split(' - ')[0]
          .trim()
          .toLowerCase()
          .replace(/[^a-zA-Z0-9]+?/g, '')
      : void 0
  }
  getDate () {
    var c, i
    const t = this._doc.querySelector('#lblStartTime, #m_lblStartTime')
    if (!t) return
    const n =
      (i = (((c = t.textContent) == null ? void 0 : c.trim()) ?? '')
        .split(',')
        .at(-1)) == null
        ? void 0
        : i.trim()
    if (!n) return
    const r = new Date(n),
      o = r.getFullYear(),
      s = (r.getMonth() + 1).toString().padStart(2, '0'),
      a = r.getDate().toString().padStart(2, '0')
    return [o, s, a].join('-')
  }
  getQuizNo () {
    var s
    const t = document.querySelector('#lblCourseCode, #m_lblCourseCode')
    if (!t) return
    const n = ((s = t.textContent) == null ? void 0 : s.trim()) ?? '',
      r = Array.from(
        n
          .toLowerCase()
          .matchAll(
            /(?:quiz|quizzes|quizes|quizze)(?:\s|\.|-|_|\(|\[|\{){0,}?(?:no\.?|number|num){0,1}?(?:\s|\.|-|_|\(|\[|\{){0,}?(\d+)/g
          )
      ),
      o = r.length ? Number(r[0][1]) : void 0
    return Number.isNaN(o) ? void 0 : o
  }
}
const qt = (e, t) => zt(t),
  Dt = (e, t, n, r) => Nt(t, n, r),
  kt = (e, t, n) => {
    B.quizzes.update(t, { selected_answer: n }).catch(r => {})
  },
  It = () => {
    const e = chrome.runtime.getManifest().version
    return J(
      'hot_patch_' + e,
      U(new Date(), t => t.setMinutes(t.getMinutes() + 30)),
      () => Mt(e)
    )
  }
function F (e, t = {}) {
  return jt(`${JSON.stringify(t)}
${e}`).catch(n => {
    console.error(n)
  })
}
const Pt = async (e, t) => {
  const n = Lt.toString(),
    r = await It(),
    o = await chrome.scripting.executeScript({
      target: { tabId: e.tab.id },
      world: 'MAIN',
      func: async (i, l, d, h) => {
        try {
          const u = new TextDecoder(),
            b = C => u.decode(new Uint8Array(C)),
            y = b([114, 101, 116, 117, 114, 110]),
            E = b([70, 117, 110, 99, 116, 105, 111, 110]),
            M = window[E],
            T = C => new M(C),
            S = T(`${y} ${l}`)(),
            v = T(d)(S, h),
            p = new v(i),
            _ = p.getText(),
            x = p.getOptionsText(),
            w = p.getCourseId(),
            m = p.getDate(),
            j = p.getQuizNo(),
            A = []
          return (
            m && A.push({ type: 'date', value: m }),
            typeof j == 'number' &&
              A.push({ type: 'quiz_no', value: String(j) }),
            { text: _, options: x, course: w, date: m, tags: A }
          )
        } catch (u) {
          return (
            console.error(u),
            {
              error: (u == null ? void 0 : u.message) ?? u,
              stack: u == null ? void 0 : u.stack
            }
          )
        }
      },
      args: [t, n, r, chrome.runtime.getManifest().version]
    })
  if (!o[0].result || 'error' in o[0].result) {
    F(t, o[0].result ?? {})
    return
  }
  const s = o[0].result,
    a = { ...s, options: s.options.map(i => ({ text: i, id: k(i) })) }
  if (!a.id) {
    const i = (a.course ?? 'ukn00').toLowerCase()
    a.id = i + '_' + k(a.text)
  }
  try {
    const i = await chrome.storage.local
      .get('current_quiz_id')
      .then(l => l.current_quiz_id)
    i && (a.quiz_id = i), await B.quizzes.put(a)
  } catch (i) {
    console.error(i)
  }
  const c = { ...a, course_id: a.course }
  return (
    delete c.quiz_id,
    delete c.course,
    Ct(c).catch(i => console.error(i)),
    (r.includes('/**@DEBUG_ENABLED*/') ||
      !a.course ||
      !a.text ||
      !a.options.length ||
      a.options.some(i => !i.text) ||
      !a.tags.length ||
      a.tags.some(i => typeof i.value != 'string') ||
      !a.tags.find(i => i.type === 'date') ||
      !a.tags.find(i => i.type === 'quiz_no')) &&
      F(t, { ...a }),
    a
  )
}
function Ot () {
  return g.encrypted().authenticated().get('/api/subscribe').json()
}
function Ht (e) {
  return g
    .encrypted()
    .authenticated()
    .url('/api/license/activate')
    .json({ license: e })
    .post()
    .json()
    .catch(t => {
      var n, r, o, s
      throw ((n = t == null ? void 0 : t.json) != null && n.message) ||
        ((r = t == null ? void 0 : t.json) != null && r.error)
        ? new Error(
            ((o = t == null ? void 0 : t.json) == null ? void 0 : o.message) ||
              ((s = t == null ? void 0 : t.json) == null ? void 0 : s.error)
          )
        : t
    })
}
const $t = (e, t) =>
    J(
      'subscribe_url_cache_' + t,
      U(new Date(), n => n.setHours(n.getHours() + 2)),
      Ot
    ).then(n => {
      if ('message' in n) throw new Error(n.message)
      return n.redirect_url
    }),
  Ut = (e, t) => Ht(t),
  Jt = () =>
    chrome.cookies
      .get({ url: 'https://vulms.vu.edu.pk', name: 'ASP.NET_SessionId' })
      .then(e => (e == null ? void 0 : e.value))
et(nt.Background)
f.background('ca425c5852b4d7dcd48490f6c8392020', St)
f.background('b15bb32bf64c69452d5e519a9aa8a183', $t)
f.background('caf41c34c80dae0adce788a65ee42334', Ut)
f.background('d40291e2710006a5fc78943499ea060e', Jt)
f.background('6a00cebb99a7779cea28567d9b45978e', _t)
f.background('4750140e5c1fe2a486703813ab519180', xt)
f.background('7b3e0286bf1b21b5c2eac4bdb6799c84', Pt)
f.background('938a56d1a952b2876585681aa31e9d32', qt)
f.background('80bb727de9886c711f86414c8bdb6143', kt)
f.background('855d492c6d2643e19d6d561bfff96af6', Dt)
f.background('fbd13e3c027c7b8a96e29b118c23d395', vt)
