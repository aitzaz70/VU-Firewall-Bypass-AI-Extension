import {
  s as b,
  t as c,
  r as C,
  i as r,
  B as V,
  e as N,
  b as k,
  a as S
} from './chunks/cIluDXEb.js'
import {
  a as z,
  C as B,
  u as E,
  g as M,
  b as o,
  S as g,
  F as _,
  d as T
} from './chunks/D_rTIZ-0.js'
import { d as A } from './chunks/DuOu2luD.js'
import './chunks/Cpj98o6Y.js'
var q = c(
  '<svg viewBox="0 0 256 256"width=1.2em height=1.2em><g fill=currentColor><path d="M216 96v112a8 8 0 0 1-8 8H48a8 8 0 0 1-8-8V96a8 8 0 0 1 8-8h160a8 8 0 0 1 8 8"opacity=.2></path><path d="M208 80h-32V56a48 48 0 0 0-96 0v24H48a16 16 0 0 0-16 16v112a16 16 0 0 0 16 16h160a16 16 0 0 0 16-16V96a16 16 0 0 0-16-16M96 56a32 32 0 0 1 64 0v24H96Zm112 152H48V96h160zm-68-56a12 12 0 1 1-12-12a12 12 0 0 1 12 12">'
)
const I = (n = {}) =>
  (() => {
    var e = q()
    return b(e, n, !0, !0), e
  })()
var P = c(
  '<svg viewBox="0 0 256 256"width=1.2em height=1.2em><g fill=currentColor><path d="M208 88h-56V32Z"opacity=.2></path><path d="M224 152a8 8 0 0 1-8 8h-24v16h16a8 8 0 0 1 0 16h-16v16a8 8 0 0 1-16 0v-56a8 8 0 0 1 8-8h32a8 8 0 0 1 8 8M92 172a28 28 0 0 1-28 28h-8v8a8 8 0 0 1-16 0v-56a8 8 0 0 1 8-8h16a28 28 0 0 1 28 28m-16 0a12 12 0 0 0-12-12h-8v24h8a12 12 0 0 0 12-12m88 8a36 36 0 0 1-36 36h-16a8 8 0 0 1-8-8v-56a8 8 0 0 1 8-8h16a36 36 0 0 1 36 36m-16 0a20 20 0 0 0-20-20h-8v40h8a20 20 0 0 0 20-20M40 112V40a16 16 0 0 1 16-16h96a8 8 0 0 1 5.66 2.34l56 56A8 8 0 0 1 216 88v24a8 8 0 0 1-16 0V96h-48a8 8 0 0 1-8-8V40H56v72a8 8 0 0 1-16 0m120-32h28.69L160 51.31Z">'
)
const H = (n = {}) =>
  (() => {
    var e = P()
    return b(e, n, !0, !0), e
  })()
var w = c('<span class=uppercase>'),
  L = c('<span>Save PDF'),
  D = c(
    '<h1 class="text-center print:hidden">MuhammadZaz♥ - <span class=uppercase>'
  ),
  F = c(
    '<div data-pdf-viewer class="prose isolate h-fit w-screen max-w-none select-none bg-background px-5 py-6 prose-img:my-0 print:p-0"><span class="fixed inset-x-0 top-[50vh] -z-10 mt-auto hidden -translate-y-1/2 -rotate-45 whitespace-nowrap text-center text-[60px] font-bold uppercase text-muted-foreground opacity-20 print:block">MuhammadZaz♥</span><section class="hidden h-screen w-full flex-col items-center justify-center bg-background print:flex"><img alt="MuhammadZaz♥ Logo"class="!mb-8 !mt-auto size-20"><h1 class=text-center>MuhammadZaz♥</h1><footer class="mt-auto pt-8 text-center text-sm text-muted-foreground">Printed by </footer></section><ol></ol><footer class="pt-8 text-center text-sm text-muted-foreground">Printed by '
  ),
  O = c(
    '<div class="flex h-screen w-full flex-col items-center justify-center text-muted-foreground"><p class="text-center text-2xl font-semibold">Login to view content'
  ),
  Z = c('<li class=break-inside-avoid><ol class=list-lower-alpha>'),
  j = c('<li>')
z(B.ContentScript)
const R = new URLSearchParams(location.search),
  y = R.get('quiz_id')
y || window.close()
const p = await A.quizzes
  .where('quiz_id')
  .equals(y)
  .toArray()
  .then(n => n.filter(e => e.text))
function $ (n, e = '') {
  const a = document.createElement('div')
  if (((a.innerText = n), (a.className = e), !n.includes('![image]'))) return a
  const m = Array.from(a.childNodes)
    .map(function l (s) {
      if (s.nodeType === Node.TEXT_NODE) return s.textContent ? s : void 0
      if (s.nodeType !== Node.COMMENT_NODE)
        return Array.from(s.childNodes).map(l)
    })
    .flat()
    .filter(Boolean)
  for (const l of m) {
    const s = l.nodeValue.matchAll(/!\[image\]\(([^)]+)\)/gim),
      u = []
    let i = 0
    for (const h of s) {
      if (h.index > i) {
        const d = l.nodeValue.slice(i, h.index)
        u.push(document.createTextNode(d)), (i += d.length)
      }
      const t = document.createElement('img')
      ;(t.src = h[1]),
        (t.className = 'inline max-w-[520px] w-full'),
        u.push(t),
        (i += h[0].length)
    }
    i < l.nodeValue.length &&
      u.push(document.createTextNode(l.nodeValue.slice(i, l.nodeValue.length))),
      l.replaceWith(...u)
  }
  return a
}
function U () {
  const { user: n } = E()
  return (
    M(() => {
      n() &&
        requestIdleCallback(() => {
          requestIdleCallback(() => window.print())
        })
    }),
    o(g, {
      get when () {
        return n()
      },
      keyed: !0,
      get fallback () {
        return (() => {
          var e = O(),
            a = e.firstChild
          return r(e, o(I, { class: 'mb-2 size-12' }), a), e
        })()
      },
      get children () {
        var e = F(),
          a = e.firstChild
        a.firstChild
        var m = a.nextSibling,
          l = m.firstChild,
          s = l.nextSibling
        s.firstChild
        var u = s.nextSibling
        u.firstChild
        var i = m.nextSibling,
          h = i.nextSibling
        return (
          h.firstChild,
          r(
            a,
            o(g, {
              get when () {
                return p.length
              },
              get children () {
                return [
                  '- ',
                  (() => {
                    var t = w()
                    return r(t, () => p.at(0).course), t
                  })()
                ]
              }
            }),
            null
          ),
          r(
            s,
            o(g, {
              get when () {
                return p.length
              },
              get children () {
                return [
                  '- ',
                  (() => {
                    var t = w()
                    return r(t, () => p.at(0).course), t
                  })()
                ]
              }
            }),
            null
          ),
          r(u, () => n().id, null),
          r(
            e,
            o(V, {
              class: 'absolute right-4 top-4 print:hidden',
              variant: 'secondary',
              onClick: () => window.print(),
              get children () {
                return [o(H, {}), L()]
              }
            }),
            i
          ),
          r(
            e,
            o(g, {
              get when () {
                return p.length
              },
              get children () {
                var t = D(),
                  d = t.firstChild,
                  f = d.nextSibling
                return r(f, () => p.at(0).course), t
              }
            }),
            i
          ),
          r(
            i,
            o(_, {
              each: p,
              children: t =>
                (() => {
                  var d = Z(),
                    f = d.firstChild
                  return (
                    r(d, () => $(t.text, 'font-semibold'), f),
                    r(
                      f,
                      o(_, {
                        get each () {
                          return t.options
                        },
                        children: x =>
                          (() => {
                            var v = j()
                            return (
                              r(v, () =>
                                $(
                                  x.text,
                                  N(
                                    'inline-block',
                                    t.selected_answer === x.id && 'bg-green-300'
                                  )
                                )
                              ),
                              v
                            )
                          })()
                      })
                    ),
                    d
                  )
                })()
            })
          ),
          r(h, () => n().id, null),
          T(() => k(l, 'src', S('/assets/icon-128.png'))),
          e
        )
      }
    })
  )
}
C(U, document.getElementById('app'))
